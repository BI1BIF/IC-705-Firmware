// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief DMR privacy/keystream helper entrypoints.
 *
 * Declares optional key/keystream generation helpers used by CLI/UI controls.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CRYPTO_DMR_KEYSTREAM_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CRYPTO_DMR_KEYSTREAM_H_H

#include <stddef.h>
#include <stdint.h>

#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

void tyt_ep_aes_keystream_creation(dsd_state* state, const char* input, int show_keys);
void tyt_ap_pc4_keystream_creation(dsd_state* state, const char* input, int show_keys);
void retevis_rc2_keystream_creation(dsd_state* state, const char* input, int show_keys);
int retevis_rc2_apply_frame49(dsd_state* state, char ambe_d[49]);
/** Wipe (DSD_SECURE_ZERO) and free the Retevis AP RC2 key schedule the state holds, if any. */
void retevis_rc2_context_release(dsd_state* state);
/** Wipe (DSD_SECURE_ZERO) the TYT AP (PC4) and Baofeng AP (PC5) key schedules and the TYT EP keystream. They are
 * the crypto module's, one set for the process, not the state's: freeState() wipes them with the session's keys. */
void dmr_vendor_key_contexts_wipe(void);
int baofeng_ap_pc5_keystream_creation(dsd_state* state, const char* input, int show_keys);
int baofeng_pc5_apply_frame49(const dsd_state* state, char ambe_d[49]);
int connect_systems_ee72_key_creation(dsd_state* state, const char* input, int show_keys);
void ken_dmr_scrambler_keystream_creation(dsd_state* state, char* input, int show_keys);
int ken_dmr_scrambler_apply_frame49(dsd_state* state, int slot, char ambe_d[49]);
void anytone_bp_keystream_creation(dsd_state* state, char* input, int show_keys);
int anytone_bp_apply_frame49(dsd_state* state, int slot, char ambe_d[49]);
int dmr_parse_static_keystream_spec(const char* input, uint8_t out_bits[882], int* out_mod, int* out_frame_mode,
                                    int* out_frame_off, int* out_frame_step, char* err, size_t err_cap);
void straight_mod_xor_keystream_creation(dsd_state* state, const char* input, int show_keys);
void straight_mod_xor_apply_frame49(dsd_state* state, int slot, char ambe_d[49]);
int dmr_ambe49_is_default_silence(const char ambe_d[49]);
int dmr_ambe49_has_zero_tail(const char ambe_d[49]);
int dmr_ambe49_should_skip_crypto(const char ambe_d[49]);
/**
 * XOR one 49-bit AMBE frame with the next bits of a DMR voice keystream and advance @p bit_counter past the frame
 * (49 bits for Hytera Enhanced 0x02, 56 for every other ALG ID). @p ks_bit_count is how many bits of @p ks_bits
 * hold generated keystream. A default-silence frame is left as is and only advances the counter.
 *
 * @return 1 when the frame was decrypted, 0 when it was skipped as silence (or an argument is NULL), -1 when the
 *         frame's bits lie outside the generated keystream: the frame and the counter are left unchanged.
 */
int dmr_voice_stream_apply_frame49(const uint8_t* ks_bits, size_t ks_bit_count, long int* bit_counter, int algid,
                                   char ambe_d[49]);
/** Advance the DMR RC4 message indicator by one 32-bit LFSR cycle. */
uint32_t dmr_mi_advance32(uint32_t mi);
/** Expand a DMR AES 32-bit MI into 16 IV bytes; return the next superframe's MI.
 * Uses the same x^32 + x^22 + x^2 + x + 1 recurrence as live DMR AES.
 * Does not mutate decoder state. Null output leaves the MI unchanged.
 */
uint32_t dmr_aes_expand_iv(uint32_t mi, uint8_t iv[16]);
/** Expand a DMR DES 32-bit MI into the 64-bit IV (the MI, then 32 more bits of the same recurrence as AES); the next
 * superframe's MI is the IV's low 32 bits. Does not mutate decoder state. */
uint64_t dmr_des_expand_iv(uint32_t mi);
int dmr_basic_privacy_apply_frame49(unsigned long long key_id, char ambe_d[49]);
int tyt_ap_pc4_apply_frame49(const dsd_state* state, char ambe_d[49]);
int tyt_ep_aes_apply_frame49(const dsd_state* state, char ambe_d[49]);
int hytera_bp_apply_frame49(unsigned long long k1, unsigned long long k2, unsigned long long k3, unsigned long long k4,
                            int* frame_counter, char ambe_d[49]);
int vertex_key_map_apply_frame49(dsd_state* state, int slot, unsigned long long key, char ambe_d[49]);
/** As vertex_key_map_apply_frame49(), for the frame at position @p pos (0..17) of its superframe; -1 keeps the
 * slot's running counter. */
int vertex_key_map_apply_frame49_at(dsd_state* state, int slot, unsigned long long key, int pos, char ambe_d[49]);
void tyt16_ambe2_codeword_keystream(const dsd_state* state, char ambe_fr[4][24], int fnum);
void csi72_ambe2_codeword_keystream(dsd_state* state, char ambe_fr[4][24]);
void kirisun_adv_keystream_creation(dsd_state* state);
void kirisun_uni_keystream_creation(dsd_state* state);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CRYPTO_DMR_KEYSTREAM_H_H */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Analog receive channel contract shared by the CLI, config, app commands, scan rows and the demodulator.
 *
 * The channel width is the full RF passband, centred on the tuned frequency, that the analog channel filter protects:
 * the filter's cutoff sits at width/2 + DSD_ANALOG_CHANNEL_GUARD_HZ with a fixed DSD_ANALOG_CHANNEL_TRANSITION_HZ
 * Blackman transition outside it. It is neither the tuner bandwidth nor the audio bandwidth. A width of 16000 Hz
 * reproduces the WIDE profile's channel filter exactly wherever that design runs: from about 19.1 kHz, where its cutoff
 * stops being held to 0.9 x Nyquist, up to the 288-tap capacity both share at about 102.7 kHz
 * (DSD_DIGITAL_CHANNEL_MAX_RATE_HZ; 219 taps at 78,125 Hz). Above that capacity the WIDE profile runs its 63-tap
 * fallback prototype. Below about 19.1 kHz and above that capacity 16000 Hz is not realizable.
 *
 * The transition is the window-method design parameter, not a stopband guarantee: the response is about -0.3 dB at
 * width/2, about -30 dB at width/2 + 1200 Hz, and -50 dB or better only from about width/2 + 1450 Hz.
 *
 * Everything here is pure integer arithmetic so that runtime callers can validate a width without linking the DSP
 * module, which mirrors the design constants below. `src/dsp/demod_pipeline.cpp` takes its transition from
 * DSD_ANALOG_CHANNEL_TRANSITION_HZ and static-asserts the guard (half that transition) and the tap capacity. The rest
 * is pinned at run time by DSP_CHANNEL_FILTERS: the Blackman attenuation the tap count uses (firdes), the tap count at
 * every rate, and that every width the validator accepts designs while every width it rejects does not (the analog
 * design calls dsd_analog_width_realizable() itself, which holds the 9/20 cutoff ratio).
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_ANALOG_CHANNEL_H_
#define DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_ANALOG_CHANNEL_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/runtime/tetra_rate.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @brief Analog demodulator kind. Zero-initialised state means FM. */
typedef enum dsd_analog_demod {
    DSD_ANALOG_DEMOD_FM = 0, /**< Narrowband FM (phase-difference discriminator). */
    DSD_ANALOG_DEMOD_AM = 1, /**< AM envelope detection. */
} dsd_analog_demod;

/** @brief Receive family a radio front end is asked to run. */
typedef enum dsd_rx_family {
    DSD_RX_FAMILY_DIGITAL = 0, /**< Symbol/discriminator output for the digital decoders. */
    DSD_RX_FAMILY_ANALOG = 1,  /**< Analog monitor audio. */
} dsd_rx_family;

/* Per-kind channel width ranges and defaults, in Hz. */
#define DSD_ANALOG_NFM_WIDTH_MIN_HZ              8000
#define DSD_ANALOG_NFM_WIDTH_MAX_HZ              25000
#define DSD_ANALOG_NFM_WIDTH_DEFAULT_HZ          16000
#define DSD_ANALOG_AM_WIDTH_MIN_HZ               5000
#define DSD_ANALOG_AM_WIDTH_MAX_HZ               20000
#define DSD_ANALOG_AM_WIDTH_DEFAULT_HZ           6000

/* Channel filter design constants. The DSP takes the transition from here and static-asserts the guard and the tap
   capacity; DSP_CHANNEL_FILTERS checks the window attenuation and tap counts against firdes, and that the analog
   design accepts exactly the widths the validator does. */
#define DSD_ANALOG_CHANNEL_TRANSITION_HZ         1200 /**< Blackman transition width. */
#define DSD_ANALOG_CHANNEL_GUARD_HZ              600  /**< Cutoff = width/2 + guard (half the transition). */
#define DSD_ANALOG_CHANNEL_MAX_TAPS              288  /**< Analog channel-filter tap capacity. */
#define DSD_ANALOG_CHANNEL_WINDOW_ATTENUATION_DB 74   /**< GNU Radio Blackman attenuation for the tap count. */
/* The cutoff must stay at or below 9/20 of the DSP rate (0.9 x Nyquist). */
#define DSD_ANALOG_CHANNEL_CUTOFF_RATE_NUM       9
#define DSD_ANALOG_CHANNEL_CUTOFF_RATE_DEN       20

/** @brief Buffer size that always holds dsd_analog_width_format() output. */
#define DSD_ANALOG_WIDTH_TEXT_MAX                24
/** @brief Buffer size that holds every validator/parser message untruncated. */
#define DSD_ANALOG_ERROR_TEXT_MAX                256
/** @brief Longest prefix of rejected input the parser echoes (longer input is shown with a trailing "..."). */
#define DSD_ANALOG_PARSE_ECHO_MAX                32

/** @brief Return 1 for DSD_ANALOG_DEMOD_FM or DSD_ANALOG_DEMOD_AM, else 0. */
int dsd_analog_demod_is_valid(int kind);

/** @brief Short display label for a demodulator kind ("NFM", "AM"); "?" for an unknown kind. */
const char* dsd_analog_demod_label(int kind);

/** @brief Smallest accepted width for @p kind in Hz; 0 for an unknown kind. */
int dsd_analog_width_min_hz(int kind);

/** @brief Largest accepted width for @p kind in Hz; 0 for an unknown kind. */
int dsd_analog_width_max_hz(int kind);

/** @brief Default width for @p kind in Hz; 0 for an unknown kind. */
int dsd_analog_width_default_hz(int kind);

/**
 * @brief Resolve a configured width.
 *
 * @param kind          Demodulator kind.
 * @param configured_hz Explicit width in Hz, or 0 for "default, not requested".
 * @return @p configured_hz when positive, otherwise the kind's default (0 for an unknown kind).
 */
int dsd_analog_width_effective_hz(int kind, int configured_hz);

/** @brief Return 1 when @p width_hz is inside the accepted range for @p kind. 0 is never in range. */
int dsd_analog_width_in_range(int kind, int width_hz);

/**
 * @brief Strictly parse a width in whole Hz and range-check it for @p kind.
 *
 * Accepts only decimal digits: no sign, whitespace, suffix, radix prefix or fraction. Out-of-range values are
 * rejected, never clamped.
 *
 * @param kind          Demodulator kind the width is for.
 * @param text          Text to parse.
 * @param out_width_hz  Receives the width on success; untouched on failure.
 * @param err           Optional buffer for an actionable message (cleared on success).
 * @param err_size      Size of @p err in bytes.
 * @return 0 on success, -1 on invalid input.
 */
int dsd_analog_width_parse(int kind, const char* text, int* out_width_hz, char* err, size_t err_size);

/**
 * @brief Blackman tap count the channel filter needs at @p rate_hz.
 *
 * Same arithmetic as dsd_firdes_compute_ntaps() for a Blackman window and DSD_ANALOG_CHANNEL_TRANSITION_HZ.
 *
 * @return The (odd) tap count, or 0 when @p rate_hz is not positive.
 */
int dsd_analog_channel_taps_for_rate(int rate_hz);

/**
 * @brief Return 1 when a channel of @p width_hz can be designed at @p rate_hz without clamping or a fallback.
 *
 * Holds when width/2 + guard <= 0.45 x rate and the tap count fits DSD_ANALOG_CHANNEL_MAX_TAPS. This does not
 * check the per-kind range; see dsd_analog_width_check() for the full rule.
 */
int dsd_analog_width_realizable(int width_hz, int rate_hz);

/** @brief Largest width realizable at @p rate_hz in Hz, or 0 when no width fits that rate. */
int dsd_analog_width_max_for_rate(int rate_hz);

/** @brief The RTL DSP bandwidth an unset or unsupported rtl_bw_khz (or spec bandwidth field) runs at, in kHz. */
#define DSD_ANALOG_RTL_DSP_BW_DEFAULT_KHZ 48
/** @brief The widest selectable RTL DSP bandwidth, in kHz. */
#define DSD_ANALOG_RTL_DSP_BW_MAX_KHZ     72
/**
 * @brief The widest DSP bandwidth an Airspy input takes, in kHz: the widest RTL one.
 *
 * An Airspy delivers 2.5, 3, 6 or 10 MS/s, which the half-band cascade halves to 78.125 or 93.75 kHz at 48 or 72 kHz,
 * and the live rate step then takes exactly to the DSP bandwidth (issue #806), so an Airspy runs every selectable DSP
 * bandwidth an RTL-SDR runs, through the same helpers.
 */
#define DSD_ANALOG_AIRSPY_DSP_BW_MAX_KHZ  DSD_ANALOG_RTL_DSP_BW_MAX_KHZ

/**
 * @brief Return 1 when @p khz is a selectable RTL DSP bandwidth (rtl_bw_khz): 4, 6, 8, 12, 16, 24, 48 or 72 kHz.
 *
 * This is the one list of DSP bandwidths: the input specs, the config, the terminal menu, the setup wizards, the Qt
 * session and the app-control commands all read it through the helpers below.
 */
int dsd_analog_rtl_dsp_bw_is_selectable(int khz);

/** @brief @p khz when it is a selectable RTL DSP bandwidth, otherwise DSD_ANALOG_RTL_DSP_BW_DEFAULT_KHZ. */
int dsd_analog_rtl_dsp_bw_or_default(int khz);

/**
 * @brief The selectable RTL DSP bandwidth nearest @p khz among those up to @p max_khz; the narrower of two as near.
 *
 * @return The bandwidth in kHz, or 0 when no selectable bandwidth is at most @p max_khz.
 */
int dsd_analog_rtl_dsp_bw_nearest(int khz, int max_khz);

/**
 * @brief List the selectable RTL DSP bandwidths up to @p max_khz, in kHz: "4, 6, 8, 12, 16, 24, 48 or 72".
 *
 * @p out is empty when none is that narrow; a short buffer truncates and stays terminated.
 *
 * @return 0 on success, -1 on a NULL or empty buffer.
 */
int dsd_analog_rtl_dsp_bw_list(int max_khz, char* out, size_t out_size);

/**
 * @brief List the selectable RTL DSP bandwidths that filter @p width_hz, in kHz: "48 or 72", "24, 48 or 72".
 *
 * The list dsd_analog_width_check() names as the fix. @p out is empty when no bandwidth fits.
 *
 * @return 0 on success, -1 on a NULL or empty buffer.
 */
int dsd_analog_width_fitting_rtl_bandwidths(int width_hz, char* out, size_t out_size);

/**
 * @brief List the selectable RTL DSP bandwidths that give @p symbol_rate_hz a whole number of samples per symbol, at
 * least 2, in kHz: "24, 48 or 72" for 4800 sym/s, "12, 24, 48 or 72" for 6000 sym/s.
 *
 * The bandwidths symbol timing runs at for that symbol rate, which the timing warnings name as the fix. @p out is empty
 * when none does.
 *
 * @return 0 on success, -1 on a NULL or empty buffer.
 */
int dsd_analog_rtl_bandwidths_with_whole_sps(int symbol_rate_hz, char* out, size_t out_size);

/**
 * @brief Validate an explicit width for @p kind at a DSP rate.
 *
 * A width is accepted only when it is in the kind's range and realizable at @p rate_hz. The message on failure names
 * the requested width, the DSP rate, the largest width that rate fits, and the RTL DSP bandwidths that would fit the
 * request.
 *
 * @param kind     Demodulator kind.
 * @param width_hz Explicit width in Hz (0 is not a width; resolve defaults first).
 * @param rate_hz  DSP (demodulator) sample rate in Hz.
 * @param err      Optional message buffer (cleared on success).
 * @param err_size Size of @p err in bytes.
 * @return 0 when accepted, -1 otherwise.
 */
int dsd_analog_width_check(int kind, int width_hz, int rate_hz, char* err, size_t err_size);

/** @brief What sets the DSP rate an analog channel runs at, which decides the fix a rate refusal names. */
typedef enum dsd_analog_rate_source {
    DSD_ANALOG_RATE_RTL_BW = 0,  /**< An RTL-SDR or rtl_tcp input: the rate is the RTL DSP bandwidth (rtl_bw_khz). */
    DSD_ANALOG_RATE_DEVICE = 1,  /**< A SoapySDR or Airspy device: the rate is the DSP bandwidth (rtl_bw_khz), which
                                      the live rate step takes the device's capture rate to exactly (issue #806); a
                                      device that cannot deliver a rate stepped to it is refused when it opens. */
    DSD_ANALOG_RATE_CAPTURE = 2, /**< An I/Q replay: its rate plan follows the DSP bandwidth (issue #701), a bandwidth
                                      change re-planning the chain to it and resampling the capture where it must. */
    DSD_ANALOG_RATE_PLANNED = 3, /**< A raw I/Q stream (`iqtcp:` / `iqudp:`, issue #743): the general rate plan takes
                                      the stream's own rate to the DSP target, known before it opens
                                      (dsd_input_dsp_rate_planned()), a bandwidth change re-planning it. */
} dsd_analog_rate_source;

/**
 * @brief The DSP rate an input runs at, as every check that predicts it and the stream start that builds it read it.
 *
 * Every live radio runs at its DSP bandwidth (rtl_bw_khz): an RTL-SDR or rtl_tcp input's half-band cascade lands on
 * it, and a SoapySDR or Airspy device's capture rate is stepped to it exactly after the cascade (issue #806), or the
 * stream refuses to open. So an analog width is held to that bandwidth before the stream opens, on every live radio.
 * Whether a SoapySDR device can deliver a rate the step takes to the bandwidth is a separate question, known only when
 * it opens, which refuses one it cannot. An I/Q replay's rate comes from its sidecar and the plan its start makes, so
 * none is known before it starts. A raw I/Q stream records nothing: its spec names its rate, and its plan
 * (dsd_iq_plan_general_rate()) always lands on the DSP target (dsd_input_dsp_target_hz(): the DSP bandwidth, TETRA's
 * 72 kHz under TETRA) when it reaches it, so that rate is known before it opens. PCM input has no DSP rate.
 */
typedef struct dsd_input_dsp_rate {
    int source;  /**< dsd_analog_rate_source: what sets the rate, which picks the fix a width refusal names. */
    int rate_hz; /**< The DSP rate in Hz, known before the stream opens: the DSP bandwidth on every live radio
                      (saturated, never overflowed, for an out-of-range bandwidth), the planned target on a raw I/Q
                      stream (its 48 kHz default for a bandwidth of 0 or less); 0 for an I/Q replay, PCM input, a live
                      radio's bandwidth of 0 or less, or a stream whose spec does not parse or whose rate no plan
                      takes to the target. */
} dsd_input_dsp_rate;

/**
 * @brief dsd_input_dsp_rate_policy() for an input named by its device string @p audio_in_dev and @p audio_in_type,
 * classified as the stream start classifies it (detect_radio_source()): an I/Q replay spec, or @p iq_replay_active,
 * is a replay; an `iqtcp:` or `iqudp:` spec is a raw I/Q stream (PLANNED: dsd_input_dsp_rate_planned() for the
 * spec's RATE and @p rtl_bw_khz); a SoapySDR or Airspy spec is that device; an RTL-SDR or rtl_tcp spec, and any other
 * device string under AUDIO_IN_RTL, is an RTL-SDR; anything else is PCM input. @p rtl_bw_khz is the DSP bandwidth it
 * runs at.
 *
 * It plans a stream with TETRA off, so it suits the analog checks that call it. A caller that may run TETRA asks
 * dsd_input_dsp_rate_policy(), which plans with the session's TETRA setting (72 kHz where the bandwidth is not a
 * TETRA rate), or dsd_input_dsp_rate_planned() with its own.
 */
dsd_input_dsp_rate dsd_input_dsp_rate_for(const char* audio_in_dev, int audio_in_type, int iq_replay_active,
                                          int rtl_bw_khz);

/** @brief The DSP rate the input @p opts names runs at (dsd_input_dsp_rate_for(), a raw I/Q stream planned with
 * @p opts' TETRA setting); NULL reads as an RTL-SDR at no known bandwidth. */
dsd_input_dsp_rate dsd_input_dsp_rate_policy(const dsd_opts* opts);

/**
 * @brief The DSP rate D a source with no device of its own (an I/Q replay, a raw I/Q stream) is planned for
 *        (issues #701, #743).
 *
 * @p dsp_bw_khz when it is an explicit request (@p explicit_request: an input spec's field, INI rtl_bw_khz, a menu or
 * API set), else the bandwidth the source recorded (@p recorded_dsp_bw_khz: a sidecar's; 0 for a WAV or a stream,
 * which record none), else @p dsp_bw_khz as it stands (a mode preset: TETRA's 72 kHz, EDACS's and ProVoice's 24 kHz;
 * or the default), and DSD_ANALOG_RTL_DSP_BW_DEFAULT_KHZ when that is 0 or less. A mode preset does not beat a recorded
 * bandwidth, as the capture's chain is what a replay reproduces. Under TETRA (@p frame_tetra) a target TETRA cannot
 * time its symbols at (dsd_tetra_dsp_rate_runs()) becomes DSD_TETRA_DSP_BW_KHZ.
 *
 * Inline, as dsd_tetra_dsp_rate_runs() is, so the radio stream's replay open plans the same target as the input rate
 * policy without linking this library.
 *
 * @return D in Hz.
 */
static inline uint32_t
dsd_input_dsp_target_hz(int dsp_bw_khz, int explicit_request, int recorded_dsp_bw_khz, int frame_tetra) {
    int khz = dsp_bw_khz;
    if (explicit_request == 0 && recorded_dsp_bw_khz > 0) {
        khz = recorded_dsp_bw_khz;
    }
    if (khz <= 0) {
        khz = DSD_ANALOG_RTL_DSP_BW_DEFAULT_KHZ;
    }
    uint32_t target_hz = (uint32_t)khz * 1000U;
    if (frame_tetra != 0 && dsd_tetra_dsp_rate_runs((int)target_hz) == 0) {
        target_hz = (uint32_t)DSD_TETRA_DSP_BW_KHZ * 1000U;
    }
    return target_hz;
}

/**
 * @brief The DSP target a raw I/Q stream is planned for at the DSP bandwidth @p dsp_bw_khz, with TETRA on when
 *        @p frame_tetra: dsd_input_dsp_target_hz() for a source that records no bandwidth.
 *
 * @return The target in Hz, or 0 for a bandwidth whose rate in Hz an int does not hold.
 */
uint32_t dsd_input_dsp_stream_target_hz(int dsp_bw_khz, int frame_tetra);

/**
 * @brief The PLANNED policy: the DSP rate a raw I/Q stream at @p stream_rate_hz (its spec's RATE) runs at for the DSP
 *        bandwidth @p dsp_bw_khz, with TETRA on when @p frame_tetra.
 *
 * The rate is the target (dsd_input_dsp_stream_target_hz()) when the general plan (dsd_iq_plan_general_rate()) reaches
 * it from @p stream_rate_hz, else 0: the stream start refuses the same rate with the plan's reason. A bandwidth above
 * what a rate in Hz holds is no plan either.
 *
 * This function, dsd_input_dsp_stream_target_hz(), dsd_input_dsp_rate_for() and dsd_input_dsp_rate_policy() read the
 * stream spec and run the I/Q rate planner (dsd-neo_io_iq), so they are built apart from the rest of this header's
 * functions (src/runtime/input_dsp_rate.c).
 *
 * @return source DSD_ANALOG_RATE_PLANNED, with the rate.
 */
dsd_input_dsp_rate dsd_input_dsp_rate_planned(uint32_t stream_rate_hz, int dsp_bw_khz, int frame_tetra);

/**
 * @brief Whether a raw I/Q stream named by @p audio_in_dev can run at the DSP bandwidth @p dsp_bw_khz, with TETRA on
 *        when @p frame_tetra: the spec reads, and the general plan reaches the target from its RATE.
 *
 * The check a stream's start, and every change that re-plans a running stream through a restart (a mode, a DSP
 * bandwidth, a config), makes before anything stops (issue #743): the same plan the stream opens on, asked dry.
 *
 * @param audio_in_dev The `iqtcp:` or `iqudp:` spec.
 * @param dsp_bw_khz   The DSP bandwidth the stream would run at.
 * @param frame_tetra  Nonzero when TETRA would be on.
 * @param out_rate_hz  Receives the DSP rate the plan lands on (0 on failure; may be NULL).
 * @param why          Receives the spec parser's or the planner's reason on failure (may be NULL).
 * @param why_size     Capacity of @p why.
 * @return 0 when the stream can run there, -1 when it cannot.
 */
int dsd_input_dsp_stream_plan_check(const char* audio_in_dev, int dsp_bw_khz, int frame_tetra, uint32_t* out_rate_hz,
                                    char* why, size_t why_size);

/**
 * @brief dsd_analog_width_check() at a DSP rate that @p source (dsd_analog_rate_source) sets.
 *
 * Accepts exactly what dsd_analog_width_check() accepts and words every refusal the same, apart from the fix a width
 * the rate cannot filter names (dsd_analog_width_rate_fix()). DSD_ANALOG_RATE_RTL_BW is dsd_analog_width_check().
 */
int dsd_analog_width_check_at(int kind, int width_hz, int rate_hz, int source, char* err, size_t err_size);

/**
 * @brief The fix a refusal names for a width of @p width_hz the DSP rate cannot filter, where @p source sets that rate.
 *
 * Every source's rate follows the DSP bandwidth, so the fix names the DSP bandwidths that would fit: "set the RTL DSP
 * bandwidth to 24, 48 or 72 kHz" for DSD_ANALOG_RATE_RTL_BW, and "set the DSP bandwidth to 24, 48 or 72 kHz" for a
 * SoapySDR or Airspy device (DSD_ANALOG_RATE_DEVICE, stepped to it), an I/Q replay (DSD_ANALOG_RATE_CAPTURE, which
 * re-plans its rate to it) and a raw I/Q stream (DSD_ANALOG_RATE_PLANNED, likewise).
 *
 * @return 0 on success, -1 on a NULL or empty buffer.
 */
int dsd_analog_width_rate_fix(int width_hz, int source, char* out, size_t out_size);

/**
 * @brief Refuse a width the channel filter being forced off leaves unfiltered.
 *
 * DSD_NEO_CHANNEL_LPF=0 (dsdneoRuntimeConfig channel_lpf_is_set with channel_lpf_enable 0) turns off the channel filter
 * that an explicit width, and the unset AM default, need; every stream start refuses them then, at any rate. Callers
 * that commit to a width before the next start pass that state as @p channel_lpf_off and hold the width to it first.
 * The unset NFM default follows the environment and is never refused; pass it only for AM.
 *
 * @param kind              Demodulator kind.
 * @param explicit_width_hz The explicit width in Hz, or 0 for the kind's default.
 * @param channel_lpf_off   Nonzero when DSD_NEO_CHANNEL_LPF=0 forces the channel filter off.
 * @param err               Optional message buffer (cleared when the width may run): the width, the variable and the
 *                          fix.
 * @param err_size          Size of @p err in bytes.
 * @return 0 when the width may run, -1 otherwise.
 */
int dsd_analog_channel_lpf_off_check(int kind, int explicit_width_hz, int channel_lpf_off, char* err, size_t err_size);

/**
 * @brief Format a width in Hz as kHz text with trailing zeros dropped ("12.5 kHz", "16 kHz").
 *
 * @return 0 on success, -1 on a NULL/short buffer or negative width.
 */
int dsd_analog_width_format(int width_hz, char* out, size_t out_size);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_ANALOG_CHANNEL_H_ */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief CLI surface for parsing args/env into dsd_opts/dsd_state.
 *
 * For high-level startup orchestration (config discovery/one-shots/interactive
 * bootstrap decisions), see `include/dsd-neo/runtime/bootstrap.h`.
 */
#ifndef DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CLI_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CLI_H_H

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

struct dsd_fp_mode_scope;

/** Return codes for dsd_parse_args. */
#define DSD_PARSE_CONTINUE 0
#define DSD_PARSE_ONE_SHOT 1
#define DSD_PARSE_ERROR    2

/**
 * @brief Parse CLI arguments and environment into opts/state.
 *
 * Populates opts/state, compacts argv for downstream processing, and handles
 * one-shot helpers (calculators/listings). Returns DSD_PARSE_ONE_SHOT when a
 * one-shot was executed and DSD_PARSE_ERROR when an error occurred. When
 * returning ONE_SHOT or ERROR, out_exit_rc (when non-NULL) receives the desired
 * process exit code.
 *
 * @param argc Argument count.
 * @param argv Argument vector.
 * @param opts Decoder options to populate.
 * @param state Decoder state to populate.
 * @param out_argc [out] Effective argc after compaction (may be NULL).
 * @param out_exit_rc [out] Process exit code when returning ONE_SHOT or ERROR (may be NULL).
 * @return DSD_PARSE_CONTINUE to run decoder; DSD_PARSE_ONE_SHOT when handled; DSD_PARSE_ERROR on failure.
 */
int dsd_parse_args(int argc, char** argv, dsd_opts* opts, dsd_state* state, int* out_argc, int* out_exit_rc);

/**
 * @brief Compact argv in-place by removing recognized long options.
 *
 * Removes runtime long options (including `--config` and related flags) so that
 * short-option parsing can be handled by `getopt()` without tripping on unknown
 * `--*` tokens. Always keeps `argv[0]` as the program name and terminates the
 * resulting argv list with a NULL pointer.
 *
 * @param argc Argument count.
 * @param argv Argument vector (modified in-place).
 * @return New effective argc (including argv[0]).
 */
int dsd_cli_compact_args(int argc, char** argv);

/**
 * @brief Nonzero when @p arg is an option whose separate value may be any text.
 *
 * An API token (`--api-token`), its file (`--api-token-file`) or a trunk-scan
 * target id (`--trunk-scan-hold`) can read like an option of its own
 * ("--print-config", "--trunk-scan"). A pre-scan of the raw argv must step over
 * such a value, as the parser and dsd_cli_compact_args() do, instead of reading
 * it as an option.
 */
int dsd_cli_option_takes_free_value(const char* arg);

/** @brief How the parser reads a long option's value (dsd_cli_long_option_arity()). */
typedef enum {
    DSD_CLI_LONG_UNKNOWN = 0,         /**< not a long option the parser knows */
    DSD_CLI_LONG_ALONE = 1,           /**< takes no separate value: a switch, or its "--name=value" form */
    DSD_CLI_LONG_NEXT = 2,            /**< takes the next argument, whatever it is */
    DSD_CLI_LONG_NEXT_NON_OPTION = 3, /**< takes the next argument unless that starts with '-' */
} dsd_cli_long_arity;

/**
 * @brief How the parser reads the long option @p arg, from the same tables dsd_cli_compact_args() steps by.
 *
 * A frontend that builds an argv around options a user typed walks them with this and
 * dsd_cli_short_option_takes_value(), so it reads each token as an option or as a value exactly as the decoder will.
 */
dsd_cli_long_arity dsd_cli_long_option_arity(const char* arg);

/** @brief The getopt option string the parser reads short options with. */
const char* dsd_cli_short_options(void);

/** @brief Nonzero when the short option @p letter takes a value (attached, or else the next argument). */
int dsd_cli_short_option_takes_value(char letter);

/** @brief Print the CLI usage/help text. */
void dsd_cli_usage(void);

/**
 * @brief Run the DMR TIII LCN calculator one-shot utility.
 *
 * Parses frequencies from a CSV file and emits an LCN mapping to stdout.
 * Uses environment variables for optional configuration:
 *   - DSD_NEO_DMR_T3_STEP_HZ: Override inferred channel step
 *   - DSD_NEO_DMR_T3_CC_FREQ: Anchor CC frequency
 *   - DSD_NEO_DMR_T3_CC_LCN: Anchor CC LCN
 *   - DSD_NEO_DMR_T3_START_LCN: Starting LCN when no anchor
 *
 * @param path Path to CSV file containing frequencies.
 * @return 0 on success, non-zero on error.
 */
int dsd_cli_calc_dmr_t3_lcn_from_csv(const char* path);

/** @brief Resolve DSD_NEO_FTZ_DAZ into the run's floating-point mode and apply it to the calling (decoder) thread;
 * see <dsd-neo/runtime/fp_mode.h>. Called once at the start of each run, before any stream or watchdog thread.
 * @p caller (may be NULL) keeps the thread's own MXCSR: dsd_runtime_fp_mode_scope_leave() puts it back when the run
 * returns. */
void dsd_bootstrap_apply_fp_mode(struct dsd_fp_mode_scope* caller);
/** @brief Select default audio output device when not explicitly set. */
void dsd_bootstrap_choose_audio_output(dsd_opts* opts);
/** @brief Select default audio input device when not explicitly set. */
void dsd_bootstrap_choose_audio_input(dsd_opts* opts);
/** @brief Run the interactive bootstrap wizard when no CLI args/config are present. */
void dsd_bootstrap_interactive(dsd_opts* opts, dsd_state* state);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CLI_H_H */

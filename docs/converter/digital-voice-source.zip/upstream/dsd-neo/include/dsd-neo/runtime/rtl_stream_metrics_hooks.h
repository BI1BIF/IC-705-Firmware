// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Runtime hook table for optional RTL stream metrics.
 *
 * Some DSP/protocol code wants to query RTL stream metrics without directly
 * depending on IO backends. The engine installs real hook functions at
 * startup. Missing query hooks return empty metrics; missing mutating hooks
 * report that the operation is unavailable.
 */
#ifndef DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_RTL_STREAM_METRICS_HOOKS_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_RTL_STREAM_METRICS_HOOKS_H_H

#include <dsd-neo/platform/platform.h>

#include <stdint.h>

#include <dsd-neo/core/input_level.h>
#include <dsd-neo/core/power.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief What the I/Q replay batch the decoder's last RTL read took its samples from ran on.
 *
 * Under `--iq-replay` the decoder paces the demod: a read hands out samples of one demod block's output, which the
 * demod published with the stream generation and the profile it ran on (`rtl_stream_replay_batch` in
 * `<dsd-neo/io/rtl_stream_c.h>`, of which these are the fields DSP reads).
 */
typedef struct dsd_rtl_stream_replay_batch {
    uint32_t generation;        /**< The stream generation it was published under. */
    int output_kind;            /**< Output kind (dsd_rtl_stream_metrics_hook_output_kind()). */
    int channel_profile;        /**< Channel profile (dsd_rtl_stream_channel_profile). */
    int symbol_rate_hz;         /**< Symbol rate in symbols/s. */
    int levels;                 /**< Symbol levels. */
    uint64_t media_start_ns;    /**< Capture time of the batch's first sample, time a MUTE omitted included. */
    uint64_t media_duration_ns; /**< Capture time the batch spans. */
    uint32_t output_count;      /**< Samples in the batch. */
    uint32_t first_index;       /**< Index in the batch of the first sample the last read returned. */
    /** Channel centre in Hz the batch was captured on, which a recorded RETUNE moves (issue #575). */
    uint32_t center_frequency_hz;
    /** The stream's discontinuity count the batch was demodulated under
        (dsd_rtl_stream_metrics_hook_discontinuity_seq()): a recorded USB recovery or rtl_tcp reconnect moves it for the
        batches after it. */
    uint64_t boundary_seq;
} dsd_rtl_stream_replay_batch;

typedef struct {
    unsigned int (*output_rate_hz)(void);
    int (*output_kind)(void);
    int (*symbol_profile)(int* out_symbol_rate_hz, int* out_levels, int* out_channel_profile);
    uint32_t (*stream_generation)(void);
    int (*cqpsk_status)(int* out_cqpsk_enable, int* out_cqpsk_timing_active);
    int (*request_cqpsk_reacquire)(void);
    int (*cqpsk_timing_bias)(void);
    double (*snr_bias_evm)(void);
    double (*snr_c4fm_db)(void);
    double (*snr_c4fm_eye_db)(void);
    double (*snr_cqpsk_db)(void);
    double (*snr_gfsk_db)(void);
    double (*snr_gfsk_eye_db)(void);
    double (*snr_qpsk_const_db)(void);
    void (*p25p1_ber_update)(int ok_delta, int err_delta);
    void (*p25p2_err_update)(int slot, int facch_ok, int facch_err, int sacch_ok, int sacch_err, int voice_err);
    /* The decoder's proof that the carrier is P25, for the CQPSK timing loop: a tuning generation plus 1, or 0 for none
       (dsd_rtl_stream_metrics_hook_note_p25_proven(), dsd_rtl_stream_metrics_hook_forget_p25_proof()). */
    void (*p25_timing_proof)(uint64_t proof);
    int (*stream_active)(void);
    int (*input_level)(dsd_input_level_snapshot* out);
    int (*apply_demod_profile)(int cqpsk_enable, int symbol_rate_hz, int levels, int channel_profile, int ted_sps);
    /** Channel squelch threshold in mean-power units (rtl_squelch_level's); 0 switches it off. */
    void (*set_channel_squelch)(double mean_power);
    /** The whole channel squelch setting: a LEVEL threshold or an AUTO margin over the learned floor. */
    void (*set_channel_squelch_setting)(const dsd_squelch_setting* setting);
    /* Receive family / analog profile request (dsd_rx_family, dsd_analog_demod, width in Hz; 0 = default). */
    int (*apply_analog_profile)(int family, int kind, int width_hz);
    /* A digital family request that lands the digital family's landing whichever family the front end runs
       (rtl_stream_request_digital_family_landing()); cqpsk_explicit as for output_rate_for_family. */
    int (*request_digital_family_landing)(int cqpsk_explicit);
    /* Published analog profile; returns 1 while the analog family is active. */
    int (*analog_profile)(int* out_kind, int* out_width_hz, int* out_lpf_on);
    /* 1 while the front end runs the analog receive family, including under a symbol profile applied on its own. */
    int (*analog_family_active)(void);
    /* 1 while it runs the analog family, or while requests or retunes already outstanding land a family (a digital
       landing requested live included): a digital retune queued now lands on the digital family's landing
       (rtl_stream_family_landing_after_pending()). */
    int (*family_landing_after_pending)(void);
    /* Output rate the front end will have once it runs the family (dsd_rx_family); 0 when unknown. cqpsk_explicit: the
       CQPSK state is a trunk-scan target's own choice, which stands over DSD_NEO_CQPSK at the switch. */
    unsigned int (*output_rate_for_family)(int family, int cqpsk_enable, int symbol_rate_hz, int cqpsk_explicit);
    /* The batch the decoder's last read took its samples from, while the input is an I/Q replay; 1 with it filled,
       anything else when there is none (dsd_rtl_stream_metrics_hook_replay_batch()). Decoder thread only. */
    int (*replay_batch)(dsd_rtl_stream_replay_batch* out);
    /* The stream's discontinuity count (dsd_rtl_stream_metrics_hook_discontinuity_seq()). */
    uint64_t (*discontinuity_seq)(void);
    /* The gain that makes up for the monitor audio's de-emphasis at 1 kHz
       (dsd_rtl_stream_metrics_hook_monitor_deemph_gain()). */
    double (*monitor_deemph_gain)(void);
} dsd_rtl_stream_metrics_hooks;

typedef enum DSD_ATTR_PACKED dsd_rtl_stream_channel_profile {
    DSD_RTL_STREAM_CHANNEL_PROFILE_WIDE = 0,
    DSD_RTL_STREAM_CHANNEL_PROFILE_6K25 = 1,
    DSD_RTL_STREAM_CHANNEL_PROFILE_12K5 = 2,
    DSD_RTL_STREAM_CHANNEL_PROFILE_PROVOICE = 3,
    DSD_RTL_STREAM_CHANNEL_PROFILE_P25_C4FM = 4,
    DSD_RTL_STREAM_CHANNEL_PROFILE_P25_CQPSK = 5,
    DSD_RTL_STREAM_CHANNEL_PROFILE_TETRA = 6,
} dsd_rtl_stream_channel_profile;

void dsd_rtl_stream_metrics_hooks_set(const dsd_rtl_stream_metrics_hooks* hooks);

unsigned int dsd_rtl_stream_metrics_hook_output_rate_hz(void);
int dsd_rtl_stream_metrics_hook_output_kind(void);
int dsd_rtl_stream_metrics_hook_symbol_profile(int* out_symbol_rate_hz, int* out_levels, int* out_channel_profile);
uint32_t dsd_rtl_stream_metrics_hook_stream_generation(void);
/**
 * @brief The gain that makes up for the de-emphasis the RTL monitor audio ran through, at 1 kHz (issue #518): about
 * 1.105 (+0.865 dB) at the default 75 us, 4.81 (+13.65 dB) under `DSD_NEO_DEEMPH=nfm`, 1.0 where none runs (AM, the
 * FSK discriminator, CQPSK, `DSD_NEO_DEEMPH=off`).
 *
 * The analog chain multiplies the RTL monitor's gain by it, so `-n 50` plays the reference tone at the reference level
 * whatever the de-emphasis. The stream publishes it with the samples, and whatever changes it moves the stream
 * generation first: read it before dsd_rtl_stream_metrics_hook_stream_generation(), and a new gain is never read with
 * the old generation (the old gain can be read with the new one until the next block; rtl_stream_monitor_deemph_gain()
 * says when).
 *
 * @return The gain; 1.0 with no hook installed (no RTL front end: PCM input, tests, radio-off builds) or when the hook
 *         reports a gain that is not positive.
 */
double dsd_rtl_stream_metrics_hook_monitor_deemph_gain(void);
int dsd_rtl_stream_metrics_hook_stream_active(void);
int dsd_rtl_stream_metrics_hook_input_level(dsd_input_level_snapshot* out);
/**
 * @brief Synchronize the RTL demodulator family, symbol profile, and timing recovery rate.
 *
 * The engine implementation applies the family transition before updating TED timing and the
 * symbol/channel profile.
 */
int dsd_rtl_stream_metrics_hook_apply_demod_profile(int cqpsk_enable, int symbol_rate_hz, int levels,
                                                    int channel_profile, int ted_sps);
/**
 * @brief Hand the demodulator's channel squelch a new threshold.
 *
 * Scan rows and targets that override the squelch (issue #521) reach the RTL demodulator
 * only through this hook; the engine maps it to rtl_stream_set_channel_squelch(). Returns 0
 * when forwarded and -1 when no radio backend is installed.
 */
int dsd_rtl_stream_metrics_hook_set_channel_squelch(double mean_power);
/**
 * @brief Hand the demodulator a whole squelch setting (issue #518 follow-up): through set_channel_squelch_setting, or,
 * when only set_channel_squelch is installed, as a threshold (an AUTO setting is then off). Returns 0 when forwarded and
 * -1 when neither is installed or @p setting is NULL.
 */
int dsd_rtl_stream_metrics_hook_set_channel_squelch_setting(const dsd_squelch_setting* setting);
/**
 * @brief Ask the RTL front end for a receive family and, for analog, a demodulator kind and channel width.
 *
 * Queued for the demod thread; switching family re-applies that family's fresh-open defaults. Leaving analog expects
 * the digital symbol profile to follow through dsd_rtl_stream_metrics_hook_apply_demod_profile(), and the switch waits
 * for it so both land at the same demod block boundary.
 *
 * @param family   dsd_rx_family (runtime/analog_channel.h).
 * @param kind     dsd_analog_demod for the analog family.
 * @param width_hz Explicit analog channel width in Hz, 0 for the kind's default.
 * @return 0 when accepted, -1 when refused or when no RTL front end is installed.
 */
int dsd_rtl_stream_metrics_hook_apply_analog_profile(int family, int kind, int width_hz);
/**
 * @brief Ask the RTL front end for the digital family, landing where the digital family's prediction says whichever
 * family it runs where the request applies (issue #583).
 *
 * A caller that timed the decoder for that landing (dsd_rtl_stream_metrics_hook_output_rate_for_family()) because the
 * analog family runs or outstanding work lands a family (dsd_rtl_stream_metrics_hook_family_landing_after_pending())
 * asks with this rather than dsd_rtl_stream_metrics_hook_apply_analog_profile(DSD_RX_FAMILY_DIGITAL, ...), which
 * switches only a front end on the analog family: the symbol profile queued after it
 * (dsd_rtl_stream_metrics_hook_apply_demod_profile()) then lands on that prediction even where a retune that carries
 * the digital family landed first (rtl_stream_request_digital_family_landing()).
 *
 * @param cqpsk_explicit Non-zero when the CQPSK state of the symbol profile that follows is a trunk-scan target's own
 *                       choice, which stands over DSD_NEO_CQPSK; 0 lands where an open of the mode would.
 * @return 0 when accepted, -1 when refused or when no RTL front end is installed. With no hook of its own installed
 *         it asks as dsd_rtl_stream_metrics_hook_apply_analog_profile() does for the digital family.
 */
int dsd_rtl_stream_metrics_hook_request_digital_family_landing(int cqpsk_explicit);
/**
 * @brief Read the published analog receive profile.
 *
 * @return 1 while the analog family is active (outputs filled), 0 otherwise (outputs zeroed).
 */
int dsd_rtl_stream_metrics_hook_analog_profile(int* out_kind, int* out_width_hz, int* out_lpf_on);
/**
 * @brief Report whether the RTL front end runs the analog receive family.
 *
 * Stays 1 while a symbol profile applied without a family request (a CQPSK toggle, a typed digital scan row) has moved
 * the front end off the analog monitor output; a digital family request leaves the family from there too.
 *
 * @return 1 while the analog family runs, 0 otherwise or when no RTL front end is installed.
 */
int dsd_rtl_stream_metrics_hook_analog_family_active(void);
/**
 * @brief Report whether a digital retune queued now lands on a receive family's landing: the RTL front end runs the
 * analog receive family now, or the receive requests and retunes already queued or in flight land a family once they
 * have landed (issue #583).
 *
 * A digital retune queued now lands after that outstanding work: after an analog retune or request it switches the
 * front end to the digital family, and behind a retune that carries the digital family it lands where that retune does,
 * the digital family's landing, even on a front end already digital. The engine attaches the digital family to it by
 * this answer (rtl_stream_family_landing_after_pending()), so a caller timing the decoder for where that retune lands
 * (rtl_stream_output_rate_for_family(), not the live rate) reads it too, and so does a later timing of the row while
 * the row's own retune, carrying the family, is outstanding. The answer can fall between two reads, as outstanding
 * analog work fails on another thread, so a scan row's timing records the decision it made
 * (dsd_scan_mode_timed_digital_family()), and the engine attaches the family to the row's retune by that decision. A
 * live request timed by it asks for the landing (dsd_rtl_stream_metrics_hook_request_digital_family_landing()), so the
 * front end lands there whichever order that request and the outstanding work land in.
 *
 * @return 1 when the analog family runs or outstanding work lands a family, 0 otherwise. With no hook of its own
 *         installed it answers as dsd_rtl_stream_metrics_hook_analog_family_active() does, the live family alone.
 */
int dsd_rtl_stream_metrics_hook_family_landing_after_pending(void);
/**
 * @brief Predict the output rate the RTL front end will have once it runs @p family.
 *
 * A family switch lands on the demod thread after the request returns, so a caller timing the decoder for the new
 * family reads this rather than the current output rate.
 *
 * @param family         dsd_rx_family.
 * @param cqpsk_enable   Non-zero for the CQPSK symbol output (digital family only). DSD_NEO_CQPSK overrides it when
 *                       set, as it does where the switch lands, unless @p cqpsk_explicit.
 * @param symbol_rate_hz Digital symbol rate, which decides the digital resampling policy.
 * @param cqpsk_explicit Non-zero when @p cqpsk_enable is a trunk-scan target's own choice (a P25 target's
 *                       `modulation`, or a DMR/NXDN target's FSK), which stands over DSD_NEO_CQPSK where the retune
 *                       the engine queues for it lands, or the live landing a republish of the row asks for
 *                       (rtl_stream_output_rate_for_family(), issue #583).
 * @return Predicted output rate in Hz, or 0 when it is unknown or no RTL front end is installed.
 */
unsigned int dsd_rtl_stream_metrics_hook_output_rate_for_family(int family, int cqpsk_enable, int symbol_rate_hz,
                                                                int cqpsk_explicit);
/**
 * @brief Read what the I/Q replay batch the decoder's last RTL read took its samples from ran on.
 *
 * Call it on the decoder thread only, while the RTL stream is open, right after a read that returned samples: the
 * engine's hook reads the stream's state as only the thread that opens and closes the stream may
 * (rtl_stream_get_replay_batch()).
 *
 * @param out [out] The batch.
 * @return 1 with @p out filled while the input is an I/Q replay, which the decoder paces; 0 otherwise (a live input,
 *         no replay read yet, no hook installed, or a NULL @p out), with @p out zeroed.
 */
int dsd_rtl_stream_metrics_hook_replay_batch(dsd_rtl_stream_replay_batch* out);
/**
 * @brief Run the decode clock's media time to the first sample the decoder's last RTL read returned, while the input is
 * an I/Q replay, and report the centre that sample was captured on.
 *
 * For the readers that take one sample at a time (the analog monitor, M17, EDACS analog): the sample's capture time is
 * the read's batch span at its index (dsd_decode_clock_batch_media_ns()), which dsd_decode_clock_set_media_ns() takes
 * (issue #572). The symbol cache does the same for each sample it hands out. Call it on the decoder thread right after a
 * read that returned samples, as dsd_rtl_stream_metrics_hook_replay_batch(). The caller notes the centre for the
 * tuned-frequency reading (dsd_opts_note_iq_replay_center(), issue #575).
 *
 * @param center_hz_out [out] The batch's capture centre in Hz (`center_frequency_hz`), written only when this returns
 *                      1; may be NULL.
 * @return 1 when it set the media time; 0 when there is no replay batch (a live input, or no hook installed).
 */
int dsd_rtl_stream_metrics_hook_replay_advance_decode_clock(uint32_t* center_hz_out);

/**
 * @brief The radio stream's discontinuity count: how many times it has had a gap on the same carrier (a USB recovery,
 * an rtl_tcp reconnect, issue #518 D5).
 *
 * The stream moves it after the gap's purge and before any sample past the gap can be read, so a read that returned
 * such a sample sees it moved when it reads the count afterwards. It never goes back, across streams included.
 *
 * @return The count; 0 with no hook installed.
 */
uint64_t dsd_rtl_stream_metrics_hook_discontinuity_seq(void);

/**
 * @brief The discontinuity count the samples the decoder's last RTL read returned carry.
 *
 * Under an I/Q replay, the count their batch was demodulated under (dsd_rtl_stream_replay_batch::boundary_seq), so a
 * gap the capture recorded reaches the decoder at the first sample after it; on a live input, the stream's count read
 * now, after that read. While the stream's count is still @p consumed, no gap stands between the caller and those
 * samples and no batch is asked for: the cost per read is one load. Decoder thread.
 *
 * @param consumed The count the caller has taken up to (dsd_state::rtl_stream_gap_seq).
 * @return The samples' count: @p consumed when no gap came before them.
 */
uint64_t dsd_rtl_stream_metrics_hook_read_discontinuity_seq(uint64_t consumed);
int dsd_rtl_stream_metrics_hook_cqpsk_status(int* out_cqpsk_enable, int* out_cqpsk_timing_active);
int dsd_rtl_stream_metrics_hook_request_cqpsk_reacquire(void);
int dsd_rtl_stream_metrics_hook_cqpsk_timing_bias(void);
double dsd_rtl_stream_metrics_hook_snr_bias_evm(void);
double dsd_rtl_stream_metrics_hook_snr_c4fm_db(void);
double dsd_rtl_stream_metrics_hook_snr_c4fm_eye_db(void);
double dsd_rtl_stream_metrics_hook_snr_cqpsk_db(void);
double dsd_rtl_stream_metrics_hook_snr_gfsk_db(void);
double dsd_rtl_stream_metrics_hook_snr_gfsk_eye_db(void);
double dsd_rtl_stream_metrics_hook_snr_qpsk_const_db(void);
void dsd_rtl_stream_metrics_hook_p25p1_ber_update(int ok_delta, int err_delta);
void dsd_rtl_stream_metrics_hook_p25p2_err_update(int slot, int facch_ok, int facch_err, int sacch_ok, int sacch_err,
                                                  int voice_err);
/**
 * @brief Tell the CQPSK timing loop the carrier is proven P25 on tuning generation @p tune_generation.
 *
 * The decoder thread calls it when a P25 Phase 1 TSDU validates (its NID passed the rules a sync anchor needs,
 * p25p1_nid_verdict_validates()) with a TSBK that passed its CRC (never a voice or data frame), or a Phase 2 window
 * passes a MAC PDU's CRC or, opened by a tolerant sync, its verdict, with the dsd_trunk_tuning_generation() the frame
 * was synced on, and only while the stream is still the one the frame's sync was accepted on: a frame read across a
 * completed tune (its handler's grant, say), a carrier boundary or a stream flush proves nothing about the carrier
 * reached, and gives no proof. While the proof holds, the Gardner's gain steps to its P25 post-lock value once locked
 * at 4800 and 6000 sym/s (op25_gardner_cc()); a tune completed since leaves it stale, which counts as none. A no-op
 * until the engine installs the hook.
 */
void dsd_rtl_stream_metrics_hook_note_p25_proven(uint64_t tune_generation);
/**
 * @brief Withdraw the P25 proof dsd_rtl_stream_metrics_hook_note_p25_proven() gave: the decoder calls it at a tune,
 * a no-carrier exit, a symbol profile or modulation change and a decode-mode switch, so the timing loop keeps its
 * acquisition-era gains until P25 content proves the carrier again. A no-op until the engine installs the hook.
 */
void dsd_rtl_stream_metrics_hook_forget_p25_proof(void);
int dsd_rtl_stream_metrics_hook_symbol_cache_pending(void);
void dsd_rtl_stream_metrics_hook_symbol_cache_pending_delta(int delta);
void dsd_rtl_stream_metrics_hook_symbol_cache_pending_reset(void);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_RTL_STREAM_METRICS_HOOKS_H_H */

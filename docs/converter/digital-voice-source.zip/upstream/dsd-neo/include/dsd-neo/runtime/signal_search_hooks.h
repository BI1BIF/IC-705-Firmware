// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_RUNTIME_SIGNAL_SEARCH_HOOKS_H
#define DSD_NEO_RUNTIME_SIGNAL_SEARCH_HOOKS_H
#include <dsd-neo/core/state_fwd.h>
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/** What one site note says, by the message that carried it. */
typedef enum {
    /** P25 network status broadcast: wacn and sysid. */
    DSD_SEARCH_SITE_NOTE_P25_NETWORK = 1,
    /** P25 RFSS status broadcast: the sysid it advertises, rfss and site. */
    DSD_SEARCH_SITE_NOTE_P25_SITE,
    /** DMR Tier III system identity (CSBK Aloha or C/P_SYS_PARMS short LC): text. */
    DSD_SEARCH_SITE_NOTE_DMR_TIII,
    /** NXDN current-site location ID: nxdn_site and nxdn_sys. */
    DSD_SEARCH_SITE_NOTE_NXDN
} dsd_signal_search_site_note_kind;

/** The site identity decoded from one message that passed its protocol's CRC/FEC check, never a cached, user-set or
 * synthesized value. Only the fields its kind names are read. */
typedef struct {
    int kind;
    uint32_t wacn;
    uint16_t sysid;
    uint8_t rfss, site;
    char text[64];
    uint32_t nxdn_sys;
    uint16_t nxdn_site;
} dsd_signal_search_site_note;

/* The evidence: the reporting protocol's name, the synctype and slot its traffic is judged by (synctype < 0: the
   decoder's current ones), then the IDs and access text. */
typedef void (*dsd_signal_search_evidence_fn)(const dsd_state*, const char*, int, int, uint32_t, uint32_t, const char*);
typedef void (*dsd_signal_search_site_fn)(const dsd_state*, const dsd_signal_search_site_note*);
typedef void (*dsd_signal_search_call_fn)(const dsd_state*, uint8_t);
typedef int (*dsd_signal_search_active_fn)(const dsd_state*);
typedef void (*dsd_signal_search_access_fn)(const dsd_state*);
/** Decoder-thread query: during a search session the symbol readers take a failed (bounded) live read as an
 * interruption, not the end of the stream. */
void dsd_signal_search_active_set(dsd_signal_search_active_fn fn);
int dsd_signal_search_is_running(const dsd_state* state);
/** Install at engine startup; protocol code reports only CRC/FEC-confirmed observations. */
void dsd_signal_search_evidence_set(dsd_signal_search_evidence_fn fn);
void dsd_signal_search_note_evidence(const dsd_state* state, const char* protocol, uint32_t target, uint32_t source,
                                     const char* access);
/** dsd_signal_search_note_evidence() for traffic of @p sync on @p slot rather than the decoder's current ones (a P25
 * Phase 2 SACCH announces the opposite voice slot, issue #637). */
void dsd_signal_search_note_evidence_at(const dsd_state* state, const char* protocol, int sync, int slot,
                                        uint32_t target, uint32_t source, const char* access);
/** Install at engine startup. Protocol code calls dsd_signal_search_note_site() once per decoded message, after the
 * message was dispatched, with the values of that message alone; the default is a no-op. */
void dsd_signal_search_site_set(dsd_signal_search_site_fn fn);
void dsd_signal_search_note_site(const dsd_state* state, const dsd_signal_search_site_note* note);
/** Install at engine startup. Protocol code calls dsd_signal_search_note_call() after it published a checked call
 * record on @p slot (its identity, or a checked crypto-only update of it); the engine reads that slot's canonical call
 * record itself. The default is a no-op. */
void dsd_signal_search_call_set(dsd_signal_search_call_fn fn);
void dsd_signal_search_note_call(const dsd_state* state, uint8_t slot);
/** Install at engine startup. Protocol code calls dsd_signal_search_note_access() whenever a checked proof gives the
 * access code dsd_access_code_current() reads for the decoder's current protocol a new value, from none included: a
 * proof that may come after the transmission's last evidence (a P25 Phase 2 NAC, issue #802). The engine reads the code
 * itself; the default is a no-op. */
void dsd_signal_search_access_set(dsd_signal_search_access_fn fn);
void dsd_signal_search_note_access(const dsd_state* state);

/** Where a P25 Phase 2 scrambling code (WACN(20) << 24 | SYSID(12) << 12 | NAC(12)) a protocol reports came from
 * (issue #804). */
typedef enum {
    /** Recovered from the carrier's own scrambled signalling and confirmed there (p25p2_seed_recover.c). */
    DSD_P25P2_CODE_RECOVERED = 1,
    /** A Phase 2 MAC network status broadcast that passed its CRC. */
    DSD_P25P2_CODE_P2_NETWORK = 2,
    /** A Phase 1 network status that passed its CRC, with the NAC of the same frame's NID. */
    DSD_P25P2_CODE_P1_NETWORK = 3,
} dsd_p25p2_code_source;

typedef size_t (*dsd_signal_search_p25p2_codes_fn)(const dsd_state*, uint64_t*, size_t);
typedef void (*dsd_signal_search_p25p2_code_fn)(const dsd_state*, uint64_t, int);
/** Install at engine startup. Decoder-thread query: up to @p cap P25 Phase 2 scrambling codes the Signal search
 * session learned, most recently confirmed first, which code recovery tries on a carrier before it solves for one.
 * Returns how many it wrote to @p out (never more than @p cap); the default, and outside a receiving visit, is 0. */
void dsd_signal_search_p25p2_codes_set(dsd_signal_search_p25p2_codes_fn fn);
size_t dsd_signal_search_p25p2_codes(const dsd_state* state, uint64_t* out, size_t cap);
/** Install at engine startup. Protocol code calls dsd_signal_search_note_p25p2_code() with a complete scrambling code
 * that content which passed its CRC/FEC check gave it, and its dsd_p25p2_code_source; the default is a no-op. */
void dsd_signal_search_p25p2_code_set(dsd_signal_search_p25p2_code_fn fn);
void dsd_signal_search_note_p25p2_code(const dsd_state* state, uint64_t code, int source);
/** The Signal search visit on the air (issue #809), which the recorder reads at a publish to name the detection a
 * recording was received on. The engine sets it when a visit's tune lands and clears it right after the closing step
 * that ends the visit's reception; when the decoder session itself ends, it lasts through the session's final
 * recording closes and the engine clears it after them. Default clear. Any thread: a reader sees the tag clear or one
 * whole pair. A pair with a zero half names no detection and clears the tag. */
void dsd_signal_search_visit_set(uint64_t session_id, uint64_t hit_id);
void dsd_signal_search_visit_clear(void);
/** 1 with @p session_id and @p hit_id set while a visit is tagged, else 0 with both 0. Either output may be NULL. */
int dsd_signal_search_visit_get(uint64_t* session_id, uint64_t* hit_id);
#ifdef __cplusplus
}
#endif
#endif

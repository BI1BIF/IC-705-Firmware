// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/** @file Frontend-neutral signal search records and bounded frequency planning. */
#ifndef DSD_NEO_RUNTIME_SIGNAL_SEARCH_H
#define DSD_NEO_RUNTIME_SIGNAL_SEARCH_H

#include <dsd-neo/core/airspy_config.h>
#include <dsd-neo/runtime/signal_search_hooks.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    DSD_SEARCH_MAX_RANGES = 16,
    DSD_SEARCH_MAX_CHANNELS = 100000,
    DSD_SEARCH_MAX_CANDIDATES = 512,
    DSD_SEARCH_MAX_AVOIDS = 1024,
    DSD_SEARCH_HISTORY_LIMIT = 1000,
    DSD_SEARCH_MAX_FFT = 65536
};

typedef enum {
    DSD_SEARCH_STOPPED,
    DSD_SEARCH_SEARCHING,
    DSD_SEARCH_TUNING,
    DSD_SEARCH_IDENTIFYING,
    DSD_SEARCH_LISTENING,
    DSD_SEARCH_HELD,
    DSD_SEARCH_PAUSED,
    DSD_SEARCH_ERROR
} dsd_signal_search_phase;

typedef struct {
    char name[64];
    uint32_t start_hz, end_hz;
    /** Exact rational Hz, e.g. 25000/3. Frequencies are rounded once from the origin. */
    uint32_t step_num, step_den;
    uint32_t bandwidth_hz;
    int enabled;
    int am;
    /** 0: analog only; 1: explicit Auto; 2..9: scan_mode's P25..M17 plus one. */
    int digital;
    int gain_set, gain_tenth_db, gain_auto;
    int airspy_gain_set;
    dsd_airspy_config airspy;
    int sensitivity_db;
    int minimum_set, minimum_dbfs;
    int squelch_mode, squelch_margin_db, squelch_dbfs;
    int probe_ms, max_visit_ms;
} dsd_signal_search_range;

typedef struct {
    uint64_t session_id, hit_id;
    uint64_t started_ms, ended_ms;
    uint32_t frequency_hz, bandwidth_hz;
    uint32_t step_num, step_den;
    uint32_t range_index;
    float power_dbfs, noise_dbfs;
    int confirmed, ended, am, unresolved;
    int gain_tenth_db, gain_auto;
    char range_name[64];
    char protocol[24];
    char access[64];
    char tone[64];
    uint32_t target, source;
    char target_text[64], source_text[64];
    /** The visit's checked site identity (dsd_signal_search_site_format()), shown only while it belongs to the hit's
     * protocol; e.g. "WACN BEE00 · SYS 1A3 · RFSS 1 · Site 2". Persisted in history (journal version 2). */
    char site[96];
    /** The checked call tuple's timeslot: 1 or 2 on a two-slot protocol (DMR, P25 Phase 2), 0 otherwise. Persisted
     * in history (journal version 2). */
    int slot;
    /** The checked call tuple's encryption: "ALG 84 · KID 0001" with only the parts received over the air,
     * "Encrypted" when only a checked encryption indication was, "" otherwise. Persisted in history (journal
     * version 2). */
    char crypt[48];
    /** Applied source settings, copied at detection time for history and save-as-system. */
    char input_spec[1024];
    int ppm, bias_tee;
    dsd_airspy_config airspy;
} dsd_signal_search_hit;

typedef struct {
    uint64_t session_id, revision, pass;
    dsd_signal_search_phase phase;
    uint32_t range_index, channel_index, channel_count;
    uint32_t capture_rate_hz;
    int identifying;
    /** 1 while a coordinator owns the tuner; 0 for a rejected start or a stopped session. */
    int owned;
    /** Current-channel RF power while listening, on the detector's dBFS scale; detection power stays in hit. */
    int live_power_valid;
    float live_power_dbfs;
    /** Bumped by every accepted live measurement: a fresh reading of an unchanged level is still a new reading. */
    uint64_t live_seq;
    /** The range being searched, from the coordinator's own configuration (a paused edit shows only after Resume).
     * Never the retained hit's range, which can belong to an earlier range. */
    char range_name[64];
    uint32_t range_start_hz, range_end_hz;
    uint64_t measurement_latency_us;
    dsd_signal_search_hit hit;
    char message[192];
    /** 1 once a span was skipped because its measurements kept clipping (the receiver is overloaded; issue #828).
     * Cleared at the end of a pass that skipped no span, at Resume and at a paused restart with edited ranges. Never
     * written into message, so neither a refusal nor its clearing touches it. */
    int overloaded;
    /** The range of the first span skipped in the pass that set or kept the warning; later skips in that pass leave
     * it, so it changes at most once a pass. "" while not overloaded. */
    char overload_range[64];
} dsd_signal_search_status;

typedef struct {
    uint32_t tune_hz;
    uint32_t first, count, next;
    uint32_t frequencies[DSD_SEARCH_MAX_CANDIDATES];
} dsd_signal_search_span;

/** A start carries no avoids: the running search reads the permanent and session lists from
 * <dsd-neo/runtime/signal_search_avoids.h> as they stand (issue #828). */
typedef struct {
    uint64_t session_id;
    uint32_t range_count;
    dsd_signal_search_range ranges[DSD_SEARCH_MAX_RANGES];
} dsd_signal_search_config;

typedef enum {
    DSD_SEARCH_ACTION_STOP,
    DSD_SEARCH_ACTION_PAUSE,
    DSD_SEARCH_ACTION_RESUME,
    DSD_SEARCH_ACTION_HOLD,
    DSD_SEARCH_ACTION_SKIP,
    /** Avoid the hit being visited for the rest of the session, and leave it. A frequency that is a permanent avoid
     * takes no room in the session list: the action succeeds, adds nothing and drops a session copy. A full session
     * list refuses and says so in the status message; a failed search refuses every session avoid action. */
    DSD_SEARCH_ACTION_AVOID,
    /** As DSD_SEARCH_ACTION_AVOID: the app-control store has made the frequency permanent first, so the search finds it
     * in the permanent list and only leaves the visit. */
    DSD_SEARCH_ACTION_AVOID_PERMANENT,
    /** Lift a session avoid by frequency_hz; not tied to a hit. A permanent avoid stays excluded. */
    DSD_SEARCH_ACTION_UNAVOID,
    /** Avoid frequency_hz for the rest of the session (a history row: hit_id may be 0), as DSD_SEARCH_ACTION_AVOID
     * does: visiting it now leaves it. */
    DSD_SEARCH_ACTION_AVOID_FREQUENCY
} dsd_signal_search_action;

typedef struct {
    uint64_t session_id, hit_id;
    int action;
    uint32_t frequency_hz;
} dsd_signal_search_control;

/** dsd_signal_search_site.valid bits. */
enum {
    DSD_SEARCH_SITE_WACN = 1U << 0,
    DSD_SEARCH_SITE_SYSID = 1U << 1,
    DSD_SEARCH_SITE_RFSS_SITE = 1U << 2,
    DSD_SEARCH_SITE_TEXT = 1U << 3,
    DSD_SEARCH_SITE_NXDN = 1U << 4
};

/** The checked site identity of one visit, built only from site notes (dsd_signal_search_note_site()). It is separate
 * from decoder state, which keeps its own caches and seeds. */
typedef struct {
    /** "P25", "DMR", "NXDN" or "" for none. */
    char protocol[8];
    unsigned valid;
    uint32_t wacn;
    uint16_t sysid;
    uint8_t rfss, site;
    char text[64];
    uint32_t nxdn_sys;
    uint16_t nxdn_site;
} dsd_signal_search_site;

void dsd_signal_search_site_clear(dsd_signal_search_site* record);
/** Join @p note to @p record; 1 when the record changed. A P25 site note joins only a record with no SYSID or the same
 * one, giving it that SYSID; a P25 network note naming another WACN or SYSID, a note of another protocol, and every
 * DMR or NXDN note replace the record whole. */
int dsd_signal_search_site_apply(dsd_signal_search_site* record, const dsd_signal_search_site_note* note);
/** Format @p record for display ("" for an empty record); returns the length written. */
size_t dsd_signal_search_site_format(const dsd_signal_search_site* record, char* out, size_t capacity);

void dsd_signal_search_range_default(dsd_signal_search_range* range);
int dsd_signal_search_validate(const dsd_signal_search_range* range, char* error, size_t capacity);
/** Every range valid, at least one enabled, and at most DSD_SEARCH_MAX_CHANNELS enabled channels in total.
 * Shared by the engine and frontends so a start the engine would reject is refused before submission. */
int dsd_signal_search_validate_config(const dsd_signal_search_config* config, char* error, size_t capacity);
uint32_t dsd_signal_search_channel_count(const dsd_signal_search_range* range);
uint32_t dsd_signal_search_frequency(const dsd_signal_search_range* range, uint32_t index);
int dsd_signal_search_fft_size(uint32_t rate, const dsd_signal_search_range* range);
/** The smallest power-of-two transform, from 32 to DSD_SEARCH_MAX_FFT points, with at least 8 bins across
 * @p width_hz at @p rate; 0 when none has. dsd_signal_search_fft_size() sizes a valid range with it, over the
 * narrower of its step and width. */
int dsd_signal_fft_size_for_width(uint32_t rate, double width_hz);
/** Plan contiguous channels in a usable RF lobe. Hardware DC and edges are never used.
 * capture_offset is the hardware centre minus the requested frequency, including Fs/4/edge tuning.
 * Returns 1 for a span, 0 at end, -1 if the rate/offset cannot cover this range. */
int dsd_signal_search_plan(const dsd_signal_search_range* range, uint32_t first, uint32_t rate, int64_t capture_offset,
                           dsd_signal_search_span* span);

#ifdef __cplusplus
}
#endif
#endif

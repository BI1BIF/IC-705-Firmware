// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Runtime hook for pumping UI/control commands.
 *
 * Protocol/DSP code may call dsd_runtime_pump_controls() during long-running
 * loops to keep user controls responsive without depending on UI headers.
 * Never call it from code that can run under the P25 SM tick guard (processFrame()
 * does): the installed pump drains commands whose apply takes that non-recursive
 * guard (#554).
 *
 * The default behavior is a safe no-op until a control pump is registered.
 */
#ifndef DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CONTROL_PUMP_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CONTROL_PUMP_H_H

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*dsd_control_pump_fn)(dsd_opts* opts, dsd_state* state);

/**
 * @brief Register (or unregister) the global control pump.
 *
 * Passing NULL unregisters.
 */
void dsd_runtime_set_control_pump(dsd_control_pump_fn fn);

/**
 * @brief Pump pending UI/control commands if a pump is registered.
 *
 * Safe to call even when no pump is registered.
 */
void dsd_runtime_pump_controls(dsd_opts* opts, dsd_state* state);

typedef int (*dsd_controls_pending_fn)(void);

/**
 * @brief Register (or, with NULL, unregister) the query dsd_runtime_controls_pending() asks.
 */
void dsd_runtime_set_controls_pending(dsd_controls_pending_fn fn);

/**
 * @brief Whether a command waits to be pumped: 1 when the registered query says so, 0 without one.
 *
 * Asked only while an input waits on a silent source, so the decoder can leave the wait and apply it (issue #634).
 */
int dsd_runtime_controls_pending(void);

/**
 * @brief Register (or, with NULL, unregister) the query dsd_runtime_publish_pending() asks.
 */
void dsd_runtime_set_publish_pending(dsd_controls_pending_fn fn);

/**
 * @brief Whether a frontend publication was put off and waits for the decode loop's next pass: 1 when the registered
 * query says so, 0 without one.
 *
 * A snapshot publication that meets a P25 watchdog tick holding the tick guard is put off, and the next control pump
 * retries it. Asked only where an input waits on a silent source in slices, beside dsd_runtime_controls_pending(), so
 * the decoder leaves the wait and the pump publishes it; never by a decoder that is reading samples.
 */
int dsd_runtime_publish_pending(void);

/** The query dsd_runtime_controls_need_frame_loop() asks, given the decoder's own state. */
typedef int (*dsd_controls_need_frame_loop_fn)(const dsd_state* state);

/**
 * @brief Register (or, with NULL, unregister) the query dsd_runtime_controls_need_frame_loop() asks.
 */
void dsd_runtime_set_controls_need_frame_loop(dsd_controls_need_frame_loop_fn fn);

/**
 * @brief Whether a queued command needs the frame loop between frames: any but the deferrable ones (display, audio,
 * keys and decryption, recording, front-end tweaks such as RF gain or squelch level, scan flag edits on a target that
 * stays). 1 when the registered query says so, 0 without one.
 *
 * A decoder that holds one carrier in a loop of its own (dmrBS()) asks it at each burst boundary and returns to the
 * frame loop, which applies the command; other commands wait for the carrier to end (issue #637). @p state is that
 * decoder's own state, on its thread: a scan flag edit (a trunk-scan list switch, a put back, a clear; issues #672,
 * #697) is judged against it, and takes the frame loop when it leaves the target on air or starts or cancels the
 * departure that target owes.
 */
int dsd_runtime_controls_need_frame_loop(const dsd_state* state);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_RUNTIME_CONTROL_PUMP_H_H */

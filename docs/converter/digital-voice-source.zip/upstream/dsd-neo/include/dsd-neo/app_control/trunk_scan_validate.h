// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef DSD_NEO_INCLUDE_DSD_NEO_APP_CONTROL_TRUNK_SCAN_VALIDATE_H_
#define DSD_NEO_INCLUDE_DSD_NEO_APP_CONTROL_TRUNK_SCAN_VALIDATE_H_

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Validate with the engine's CSV parser without exposing owned targets or decoder
 * state to frontends. Returns 0 on success; count is zero on failure. Optional
 * output pointers may be NULL. Referenced side files (channel/key CSVs and
 * profiles) are not opened or checked for readability. Parsed key storage is erased before returning. */
int dsd_app_trunk_scan_validate_targets_csv(const char* path, int* target_count, char* err, size_t err_sz);

/** The same for the lists of one session (issue #697): each file through the parser, then the engine's rule across
 * them (dsd_trunk_scan_check_target_lists(): a row whose id an earlier list holds is that target, shared, when every
 * setting is the same, and refused naming both rows and the first column that differs otherwise; the distinct targets
 * within the target budget). Every error names the file it is about, by @p names[i] (a display name, for a frontend
 * validating private copies), or by @p paths[i] when @p names is NULL. 1 to DSD_TRUNK_SCAN_MAX_LISTS lists;
 * @p target_count is their distinct targets, a shared one counted once. */
int dsd_app_trunk_scan_validate_target_lists(const char* const* paths, const char* const* names, size_t count,
                                             int* target_count, char* err, size_t err_sz);

/** Nonsecret configured target. Unset dwell/hold/gain/bandwidth/tone_filter are -1; empty modulation
 * inherits. squelch_db (whole dB, 0 = off) is meaningful only with squelch_db_set, since
 * -1 dB is a real threshold; squelch_mode is the target's own squelch's dsd_squelch_mode, and
 * squelch_margin_db its dynamic margin in its place (auto: 3..30 dB over the learned floor; noise: 3..30
 * dB of FM quieting), 0 for a level. bandwidth_hz is an analog target's own channel width in Hz
 * (an nfm-conventional target's --nfm-bandwidth-hz, an am-conventional target's
 * --am-bandwidth-hz). tone_filter is an nfm-conventional target's own CTCSS/DCS tone policy
 * (dsd_tone_filter_mode: OFF for --no-tone-filter, ALLOW, BLOCK) and tone_list its list as
 * displayed (dsd_tone_set_format_display(): "100.0 Hz/D023N", the entries past the room
 * counted; "" without one). Strings belong to this fixed-size record, never to decoder state. */
typedef struct {
    char id[64];
    char type[24];
    char modulation[8];
    uint32_t frequency_hz;
    unsigned int row;
    int dwell_ms;
    int hold_ms;
    int gain_db;
    int squelch_db_set;
    int squelch_db;
    int squelch_mode;
    int squelch_margin_db;
    int bandwidth_hz;
    int tone_filter;
    char tone_list[96];
    char receive_summary[256];
} dsd_app_scan_csv_target;

typedef enum {
    DSD_APP_SCAN_FILE_CHANNEL,
    DSD_APP_SCAN_FILE_BANDPLAN,
    DSD_APP_SCAN_FILE_KEYS_HEX,
    DSD_APP_SCAN_FILE_KEYS_DEC,
    DSD_APP_SCAN_FILE_GROUP,
    DSD_APP_SCAN_FILE_DMR_MAP
} dsd_app_scan_file_kind;

typedef struct {
    size_t index;
    unsigned int row;
    dsd_app_scan_file_kind kind;
    const char* field;
    const char* path;
    const char* resolved_path;
} dsd_app_scan_csv_reference;

typedef void (*dsd_app_scan_csv_target_cb)(const dsd_app_scan_csv_target* target, void* context);
typedef void (*dsd_app_scan_csv_reference_cb)(const dsd_app_scan_csv_reference* reference, void* context);

typedef struct {
    dsd_app_scan_csv_target_cb target;
    dsd_app_scan_csv_reference_cb reference;
    void* context;
    /** The configured policies each target's receive_summary notes unreachable service names over
     * (dsd_scan_option_receive_summary_against()); NULL judges each target alone. */
    const struct dsd_scan_option_baseline* baseline;
} dsd_app_scan_csv_callbacks;

/** Synchronous inspection, without opening companions. base_path specifies the
 * original document's path base when inspecting a private copy (NULL uses path).
 * channel_map selects the channel import grammar instead of target CSV grammar.
 * Callbacks run only after inspection succeeds; pointers expire on return.
 * Input documents are limited to 64 MiB. Errors never include option/key cells. */
int dsd_app_scan_csv_inspect(const char* path, const char* base_path, int channel_map,
                             const dsd_app_scan_csv_callbacks* callbacks, char* err, size_t err_sz);

typedef struct {
    size_t reference_index;
    const char* relative_path;
} dsd_app_scan_csv_replacement;

/** dsd_app_scan_csv_rewrite()'s answer when the input and its replacements were fine but the destination could not be
 * written; errno then says why (ENOSPC for a full disk). */
enum { DSD_APP_SCAN_CSV_WRITE_FAILED = -2 };

/** Reinspect and rewrite only dependency tokens into a new private destination.
 * Every reference must have exactly one replacement. Generated paths may contain
 * ASCII letters/digits, slash, dot, underscore and hyphen; no leading dash.
 * Caller owns staging/atomic publication. No raw CSV or options cross this API.
 * Returns 0, DSD_APP_SCAN_CSV_WRITE_FAILED when only the destination write failed,
 * else -1 (the input could not be read or parsed, or a replacement is invalid). */
int dsd_app_scan_csv_rewrite(const char* path, const char* base_path, int channel_map, const char* destination,
                             const dsd_app_scan_csv_replacement* replacements, size_t count, char* err, size_t err_sz);

/** Complete preflight using isolated dry-run loaders, never engine initialization.
 * count/first_hz are zero on failure. Referenced channel maps validate their own
 * companions. Empty band plans and DMR mappings are refused as at engine start. */
int dsd_app_trunk_scan_validate_bundle(const char* path, int* count, uint32_t* first_hz, char* err, size_t err_sz);

#ifdef __cplusplus
}
#endif
#endif

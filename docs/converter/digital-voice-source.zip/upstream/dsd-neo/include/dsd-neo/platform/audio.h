// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_AUDIO_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_AUDIO_H_H

/**
 * @file
 * @brief Cross-platform audio I/O abstraction for DSD-neo.
 *
 * Provides a unified API for audio input/output that works with
 * PulseAudio (Linux) and PortAudio (cross-platform/Windows).
 */

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Opaque audio stream handle */
typedef struct dsd_audio_stream dsd_audio_stream;

/* Audio device information */
typedef struct dsd_audio_device {
    int index;
    char name[512];
    char description[256];
    int is_input;
    int is_output;
    int initialized;
} dsd_audio_device;

/* Audio stream parameters */
typedef struct dsd_audio_params {
    int sample_rate;      /* e.g., 8000, 48000 */
    int channels;         /* 1 (mono) or 2 (stereo) */
    int bits_per_sample;  /* 16 */
    const char* device;   /* Device name/identifier, or NULL for default */
    const char* app_name; /* Application name for audio server (optional) */
    int async_output;     /* nonzero enables low-latency async output with overrun drops */
} dsd_audio_params;

/** Android output device ID while an AAudio output is open; 0 while idle,
 * -1 when the backend does not publish Android routing information. */
int dsd_audio_output_device_id(void);

/**
 * @brief Initialize audio subsystem.
 *
 * Must be called before any audio operations.
 *
 * @return 0 on success, non-zero on failure.
 */
int dsd_audio_init(void);

/**
 * @brief Cleanup audio subsystem.
 *
 * Call at program termination.
 */
void dsd_audio_cleanup(void);

/**
 * @brief Enumerate available audio devices.
 *
 * @param inputs    Array to receive input devices (may be NULL).
 * @param outputs   Array to receive output devices (may be NULL).
 * @param max_count Maximum devices per array (typically 16).
 * @return 0 on success, non-zero on failure.
 */
int dsd_audio_enumerate_devices(dsd_audio_device* inputs, dsd_audio_device* outputs, int max_count);

/**
 * @brief Print available audio devices to stdout.
 *
 * Convenience function for CLI listing.
 *
 * @return 0 on success, non-zero on failure.
 */
int dsd_audio_list_devices(void);

/**
 * @brief Open an audio input stream.
 *
 * @param params    Stream parameters.
 * @return Stream handle, or NULL on failure.
 */
dsd_audio_stream* dsd_audio_open_input(const dsd_audio_params* params);

/**
 * @brief Open an audio output stream.
 *
 * @param params    Stream parameters.
 * @return Stream handle, or NULL on failure.
 */
dsd_audio_stream* dsd_audio_open_output(const dsd_audio_params* params);

/**
 * @brief Read audio samples from input stream.
 *
 * Blocks until requested samples are available.
 *
 * @param stream    Audio stream handle.
 * @param buffer    Buffer to receive samples (int16_t).
 * @param frames    Number of frames to read.
 * @return Number of frames read, or negative on error.
 */
int dsd_audio_read(dsd_audio_stream* stream, int16_t* buffer, size_t frames);

/**
 * @brief Read up to @p frames of what the input stream holds now, never waiting.
 *
 * What a discard kept comes first (dsd_audio_discard_input()), then what the device holds, as dsd_audio_discard_input()
 * counts it: PulseAudio's client-side queue (the record stream's held audio), PortAudio's
 * Pa_GetStreamReadAvailable(), AAudio's frames the device wrote and no read took (a read with no timeout). A source
 * that stops delivering holds nothing, and the call returns at once. The decoder's frame-sync hunt reads through this,
 * in bounded waits that service what waits on the decoder, so a stalled sound card cannot hold it; frame decoding
 * reads with dsd_audio_read(). The null backend paces as dsd_audio_read() does.
 *
 * With @p recover 0 (a probe) it makes no device teardown or reopen: an input it finds lost (AAudio after a route
 * disconnect) holds nothing until a call with @p recover set, or a blocking read, brings the device back. With
 * @p recover set, AAudio first tears down a stream a route change disconnected and opens it again once its reopen
 * backoff allows: synchronous calls into the audio service, so the decoder's hunt sets it only in a read that waits,
 * after it serviced what waits on it. PulseAudio, PortAudio and the null backend keep their input open.
 *
 * @return Frames read (0 when the stream holds none), or negative on error.
 */
int dsd_audio_read_held(dsd_audio_stream* stream, int16_t* buffer, size_t frames, int recover);

/**
 * @brief Drop the input samples the stream holds now, unread, but for those captured since @p marked_ns (issue #834: a
 * rigctl peer's audio from before its retune; the audio captured since the retune was asked for is kept).
 *
 * A device captures in real time, so the newest frames it holds, as many as the time since the mark lasts, are the
 * audio captured since then. That time is read after the backend counts what it holds (or, on PulseAudio, after its
 * reads), so audio captured while the caller waited before the count is kept, and the frame count rounds up: a
 * drop keeps more rather than less. Frames an earlier drop kept and no read took are the oldest the stream holds. A
 * drop may lose only audio held before the mark: once it cannot tell old audio from new (the device overran and threw
 * audio away), it stops, and keeps what it holds. The memory a drop keeps audio in is taken before it reads anything
 * (PulseAudio's ring of the newest frames, which then becomes the stream's kept frames; PortAudio's and AAudio's chunk
 * buffer, which an overrun's chunk is kept in): without it the drop reads nothing and fails, so running out of memory
 * never loses audio captured after the mark. No backend waits for audio: a source that stops delivering (one
 * suspended during the retune) ends the drop at once. Per backend:
 * - PulseAudio (Linux, macOS): everything the client holds now (the rest of the record fragment being read, the queue
 *   behind it) is read without a wait; what the server has not sent yet stays there and is read after the drop. At
 *   most 2 s of frames at the stream's rate, exact to one 32-frame read (the cap is checked before each read, so up to
 *   31 frames past it), no read begun after 250 ms on the monotonic clock. The client cannot say when a frame it holds
 *   was captured, so the newest frames read are kept in the stream and returned first by dsd_audio_read(). The keep is
 *   counted by time, not from a count taken first, so a server overrun (which throws the oldest audio away before it
 *   is read) loses no audio captured after the mark. The drop is approximate (issue #834): it assumes the source kept
 *   delivering, so audio held at the mark from a source that stopped since is kept as if it came after.
 * - PortAudio (Windows): one snapshot of the frames the stream reports available at the call
 *   (Pa_GetStreamReadAvailable(), at most its input buffer), less those kept, read without a wait: each read asks for
 *   no more than the stream reports available just before it (a blocking read of frames no longer held would wait for
 *   new capture), and the drop ends when it holds none. At most 2 s of frames at the stream's rate, no read begun
 *   250 ms or more after its first on the monotonic clock. A read that reports an
 *   overrun (paInputOverflowed) ends it: its frames are kept, returned first by dsd_audio_read(), and the rest stays in
 *   the device.
 * - AAudio (Android): the frames the device wrote and no read took (AAudioStream_getFramesWritten() less
 *   AAudioStream_getFramesRead()), less those kept, read with no wait: at most 96000 frames (2 s at 48 kHz), no read
 *   begun after 250 ms. A read whose chunk may hold audio captured after the mark ends it, as on PortAudio: the
 *   device's overrun count (AAudioStream_getXRunCount()) moved, or, since some input devices always report 0 there,
 *   the device has written more than its buffer capacity past the chunk's frame position, so the chunk may have been
 *   overwritten.
 * Audio still on its way to DSD-neo (in the producer, or in the sound server) arrives after the call and is kept.
 *
 * @param stream     Input stream handle.
 * @param marked_ns  The retune's mark on the monotonic clock (dsd_time_monotonic_ns(), dsd_input_cut::marked_ns): the
 *                   audio captured since is kept (a mark later than the count keeps nothing).
 * @return Frames dropped, or negative on error (an output stream included).
 */
int dsd_audio_discard_input(const dsd_audio_stream* stream, uint64_t marked_ns);

/**
 * @brief Write audio samples to output stream.
 *
 * May block until buffer space is available.
 *
 * @param stream    Audio stream handle.
 * @param buffer    Samples to write (int16_t).
 * @param frames    Number of frames to write.
 * @return Number of frames written (queued, on an async stream), or negative on error, including while the
 *         stream's device is down and owed a reopen (dsd_audio_output_health_get()).
 */
int dsd_audio_write(dsd_audio_stream* stream, const int16_t* buffer, size_t frames);

/** Device health of an output stream (dsd_audio_output_health_get()). */
typedef struct dsd_audio_output_health {
    uint64_t failures;   /* device failures since the stream opened; each left the device unusable, owing a reopen */
    uint64_t recoveries; /* failures after which a reopened device took audio again */
    int down;            /* 1 while the device is unusable and a reopen is owed; writes fail meanwhile */
    char error[256];     /* what the latest failure reported */
} dsd_audio_output_health;

/**
 * @brief Report an output stream's device failures and recoveries.
 *
 * PulseAudio and PortAudio give up a device whose write fails and reopen it behind the same stream handle, retrying
 * with a growing wait while it cannot be reopened; dsd_audio_write() fails while it is down. (PulseAudio closes and
 * reopens it on its output thread; PortAudio on the thread that writes and opened the stream.) A caller compares the counts
 * between calls to report each failure and recovery once. Backends that recover on their own without reporting
 * (AAudio) and the null backend report zeros.
 *
 * @param stream    Output stream handle.
 * @param out       Receives the report (zeroed on error).
 * @return 0 on success, -1 for a NULL, input or otherwise invalid stream.
 */
int dsd_audio_output_health_get(dsd_audio_stream* stream, dsd_audio_output_health* out);

/**
 * @brief Close an audio stream.
 *
 * @param stream    Stream handle (safe to pass NULL).
 */
void dsd_audio_close(dsd_audio_stream* stream);

/**
 * @brief Flush audio output buffers.
 *
 * @param stream    Stream handle.
 * @return 0 on success, non-zero on failure.
 */
int dsd_audio_drain(dsd_audio_stream* stream);

/**
 * @brief Get human-readable error string.
 *
 * @return Last error message, or empty string if none.
 */
const char* dsd_audio_get_error(void);

/**
 * @brief Get the name of the active audio backend.
 *
 * @return Backend name string (e.g., "pulse", "portaudio").
 */
const char* dsd_audio_backend_name(void);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_AUDIO_H_H */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H

/**
 * @file
 * @brief Cross-platform file descriptor compatibility for DSD-neo.
 *
 * Paths on Windows: every helper here (and dsd_mkdir(), dsd_mkdtemp(), dsd_mkstemp()) takes a path in one encoding,
 * chosen by dsd_win32_path_wide(). A path that is well-formed UTF-8 (the app's own files, named in any script) goes
 * through the wide call only, whatever the ANSI code page and the CRT locale; a path that is not (one a command line
 * gives in the ANSI code page) goes through the ANSI call only. A path never goes through both, so a name the wide
 * call answered for is never read again in the ANSI code page, which can name another file or split the path apart.
 * Pure ASCII is the same either way.
 */

#include <dsd-neo/platform/platform.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#if DSD_PLATFORM_WIN_NATIVE
#include <sys/stat.h>
/* The 64-bit-size form: struct _stat holds st_size in 32 bits, which a file past 2 GiB overflows. */
typedef struct _stat64 dsd_stat_t;
#else
#include <sys/stat.h>
typedef struct stat dsd_stat_t;
#endif

/* ssize_t definition for Windows */
#if DSD_PLATFORM_WIN_NATIVE && !defined(_SSIZE_T_DEFINED)
#include <BaseTsd.h>
typedef SSIZE_T ssize_t;
#define _SSIZE_T_DEFINED
#endif

/**
 * @brief Get file descriptor from FILE stream.
 *
 * @param fp    FILE pointer.
 * @return File descriptor, or -1 on error.
 */
int dsd_fileno(FILE* fp);

/**
 * @brief Check if file descriptor refers to a terminal.
 *
 * @param fd    File descriptor.
 * @return Non-zero if terminal, 0 otherwise.
 */
int dsd_isatty(int fd);

/**
 * @brief Disable text translation on an open descriptor used for raw bytes.
 *
 * Selects binary mode on Windows; POSIX descriptors already carry raw bytes.
 * Flush any buffered stdio output before changing its descriptor's mode.
 *
 * @param fd    Open file descriptor.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_set_binary_mode(int fd);

/**
 * @brief Duplicate a file descriptor.
 *
 * @param oldfd     File descriptor to duplicate.
 * @return New file descriptor, or -1 on error.
 */
int dsd_dup(int oldfd);

/**
 * @brief Duplicate a file descriptor to a specific number.
 *
 * @param oldfd     Source file descriptor.
 * @param newfd     Target file descriptor number.
 * @return newfd on success, -1 on error.
 */
int dsd_dup2(int oldfd, int newfd);

/**
 * @brief Close a file descriptor.
 *
 * @param fd    File descriptor to close.
 * @return 0 on success, -1 on error.
 */
int dsd_close(int fd);

/**
 * @brief Flush file data to disk.
 *
 * @param fd    File descriptor.
 * @return 0 on success, -1 on error.
 */
int dsd_fsync(int fd);

/**
 * @brief Get file status.
 *
 * @param fd    File descriptor.
 * @param st    Output stat struct.
 * @return 0 on success, -1 on error.
 */
int dsd_fstat(int fd, dsd_stat_t* st);

/**
 * @brief Get file status for a path.
 *
 * @param path  File path.
 * @param st    Output stat struct.
 * @return 0 on success, -1 on error.
 */
int dsd_stat_path(const char* path, dsd_stat_t* st);

/**
 * @brief Check whether file status describes a regular file.
 *
 * @param st    File status struct.
 * @return Non-zero if regular file, 0 otherwise.
 */
int dsd_stat_is_regular(const dsd_stat_t* st);

/**
 * @brief Seek a stream to a 64-bit offset.
 *
 * fseek() takes a long, which is 32 bits on Windows (and on 32-bit POSIX systems), so it cannot reach past 2 GiB
 * there. This uses _fseeki64() on Windows and fseeko() elsewhere. Where off_t is 32 bits, an offset it cannot hold
 * fails with EOVERFLOW.
 *
 * @param fp      Stream.
 * @param offset  Offset from @p whence.
 * @param whence  SEEK_SET, SEEK_CUR or SEEK_END.
 * @return 0 on success, -1 with errno set on error (EINVAL for a NULL stream).
 */
int dsd_fseek64(FILE* fp, int64_t offset, int whence);

/**
 * @brief A stream's position as a 64-bit offset (_ftelli64() on Windows, ftello() elsewhere).
 *
 * @param fp  Stream.
 * @return The position, or -1 with errno set on error (EINVAL for a NULL stream).
 */
int64_t dsd_ftell64(FILE* fp);

/**
 * @brief Set file permissions (best effort on Windows).
 *
 * @param fd    File descriptor.
 * @param mode  POSIX permission bits.
 * @return 0 on success, -1 on error.
 */
int dsd_fchmod(int fd, int mode);

/**
 * @brief Open a file for writing/appending with owner-only permissions when created.
 *
 * Supports standard write/append modes such as "w", "wb", "a", "ab", "w+",
 * and "a+". Read-only modes fall back to normal fopen semantics. An "x" after a
 * write mode ("wx", "wbx") creates the file exclusively, as C11 fopen() does:
 * the open fails with EEXIST when @p path already exists, which is left untouched.
 *
 * @param path  File path.
 * @param mode  fopen-compatible mode string.
 * @return FILE stream, or NULL on error.
 */
FILE* dsd_fopen_private(const char* path, const char* mode);

/**
 * @brief dsd_fopen_private(), also reporting whether it opened @p path.
 *
 * A write mode creates or empties the file once its descriptor opens, before the stream over that descriptor is made,
 * so an open whose stream cannot be made (fdopen() out of memory) returns NULL with the file already created or
 * emptied. A caller that must know whether it touched the file (the I/Q capture writer, which reports writing over an
 * earlier recording) reads @p out_opened. A read mode opens as fopen() does.
 *
 * @param path       File path.
 * @param mode       fopen-compatible mode string.
 * @param out_opened Set to 1 once @p path was opened, whether or not the stream over it was then made, and 0
 *                   otherwise. May be NULL.
 * @return FILE stream, or NULL on error.
 */
FILE* dsd_fopen_private_ex(const char* path, const char* mode, int* out_opened);

/**
 * @brief Create a private temporary sibling file for atomic replacement.
 *
 * The temporary file is created in the same directory as @p final_path with
 * owner-only permissions and exclusive creation. On success, @p tmp_path
 * receives the created file path and the returned stream owns the descriptor.
 *
 * @param final_path     Destination path that will later be replaced.
 * @param tmp_path       Output buffer for the created temporary path.
 * @param tmp_path_size  Output buffer size.
 * @param mode           fopen-compatible write mode such as "w" or "wb".
 * @return FILE stream, or NULL on error with errno set.
 */
FILE* dsd_fopen_private_temp_for_replace(const char* final_path, char* tmp_path, size_t tmp_path_size,
                                         const char* mode);

/**
 * @brief Make a directory entry change under @p path's parent durable (best effort).
 *
 * Syncs the parent directory of @p path after a file there was created, renamed or removed, so the change survives a
 * crash or power loss as well as the file's data does. Failures are ignored. A no-op on Windows, where the
 * filesystem gives no directory handle to sync.
 *
 * @param path  A path whose parent directory changed.
 */
void dsd_fsync_parent_dir(const char* path);

/**
 * @brief Atomically replace a destination path with a temporary file.
 *
 * Moves one regular file, @p tmp_path, onto @p final_path, in the same directory or another one on the same volume.
 * Never copies: across volumes it fails (EXDEV; on Windows ERROR_NOT_SAME_DEVICE maps to EXDEV) and leaves both paths
 * as they were. A directory @p tmp_path is refused with EISDIR before anything moves.
 *
 * @param tmp_path    Existing temporary file, on the same volume as @p final_path.
 * @param final_path  Destination path to replace.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_replace_file_with_temp(const char* tmp_path, const char* final_path);

/**
 * @brief Rename @p from to @p to unless @p to already exists.
 *
 * Moves one regular file, in the same directory or into another one on the same volume. Never copies: across volumes
 * it fails (EXDEV; on Windows ERROR_NOT_SAME_DEVICE maps to EXDEV). A directory @p from is refused with EISDIR before
 * anything moves. Never replaces an existing @p to: the call fails with EEXIST and leaves both files as they were. The
 * rename is atomic where the platform and filesystem offer a no-replace rename (Linux renameat2(RENAME_NOREPLACE),
 * macOS renamex_np(RENAME_EXCL), a hard link then an unlink on other POSIX systems; Windows' MoveFileEx() without
 * MOVEFILE_REPLACE_EXISTING or MOVEFILE_COPY_ALLOWED). On Windows the pair takes one call, as dsd_win32_path_wide()
 * picks: MoveFileExW() when both names are UTF-8 (whatever the process code page), MoveFileExA() otherwise, never
 * both. On a POSIX filesystem that supports neither (no no-replace rename, no hard links) it claims @p to with an
 * exclusive create and renames onto that claim: @p to briefly exists as an empty file, and only a process that deletes
 * the claim in between can still be replaced.
 *
 * @param from              Existing file.
 * @param to                New name, on the same volume as @p from.
 * @param out_source_left   Optional. Set to 1 when @p to was created but @p from could not be removed afterwards (a
 *                          hard link whose unlink failed): the call still succeeds, and @p from names the same file.
 *                          Set to 0 otherwise.
 * @return 0 on success, -1 on error with errno set (EEXIST when @p to exists).
 */
int dsd_rename_noreplace(const char* from, const char* to, int* out_source_left);

/**
 * @brief Whether a name exists, without following a symbolic link at it.
 *
 * Answers for the name itself: lstat() on POSIX, GetFileAttributes() on Windows, both of which describe a link or
 * reparse point rather than its target, so a dangling link exists. Only a confirmed absence answers 0; a caller that
 * must not lose a file treats -1 as "may exist".
 *
 * @param path  Path to probe.
 * @return 1 when the name exists (any type); 0 when it is confirmed absent, with errno ENOENT (or ENOTDIR: a parent is
 *         not a folder); -1 when it cannot tell, with errno set (EINVAL for NULL or an empty path, EACCES for a parent
 *         that cannot be searched).
 */
int dsd_path_exists_nofollow(const char* path);

/** What a name is, never following a link at it (dsd_path_type_nofollow()). */
typedef enum {
    DSD_PATH_TYPE_FILE,  /**< a regular file */
    DSD_PATH_TYPE_DIR,   /**< a folder that is not itself a link */
    DSD_PATH_TYPE_LINK,  /**< a symbolic link, dangling or not, whatever it names; on Windows any reparse point (a
                              symbolic link or a junction, file or folder) */
    DSD_PATH_TYPE_OTHER, /**< a FIFO, socket or device */
} dsd_path_type;

/**
 * @brief dsd_path_exists_nofollow(), also telling what the name is.
 *
 * Renaming the name moves a link itself, never its target, so a caller that may move a file aside but must leave a
 * real folder or FIFO alone decides by this, not by dsd_stat_path(), which follows the link.
 *
 * @param path      Path to probe.
 * @param out_type  Optional. Receives the type when the answer is 1; left as it was otherwise.
 * @return As dsd_path_exists_nofollow(), with the same errno.
 */
int dsd_path_type_nofollow(const char* path, dsd_path_type* out_type);

/**
 * @brief The absolute, canonical path of an existing file or folder.
 *
 * POSIX resolves symbolic links and "." and ".." (realpath()); Windows makes the path absolute and folds "." and "..",
 * through the wide or the ANSI call as the file note says, and gives the result in the encoding @p path came in (a
 * UTF-8 path's in UTF-8). Two paths in one encoding that name one folder the same way compare equal, which is what a
 * check whether a file lies inside a folder needs; a UTF-8 and an ANSI path to one folder need not.
 *
 * @param path      Existing path.
 * @param out       Output buffer.
 * @param out_size  Output buffer size.
 * @return 0 on success, -1 on error with errno set (ENAMETOOLONG when @p out is too small).
 */
int dsd_path_canonical(const char* path, char* out, size_t out_size);

/**
 * @brief Whether two paths name one existing file, however each is spelled.
 *
 * POSIX compares the device and inode stat() gives each (a symbolic link counts as the file it points to). Windows
 * compares the volume serial number and 128-bit file id GetFileInformationByHandleEx(FileIdInfo) gives each, exact on
 * ReFS, whose ids do not fit 64 bits; where FileIdInfo is not supported (before Windows 8, some file systems), the volume
 * serial number and 64-bit file index of GetFileInformationByHandle(). A hard link, another case of the same name on a
 * file system that ignores case, and a Windows short (8.3) name each name the file they spell.
 *
 * @param a     A path (UTF-8 on Windows, where a path that is not opens as the ANSI code page).
 * @param b     Another path.
 * @param same  Set to 1 when @p a and @p b name one file, 0 when they name two.
 * @return 0 with @p same set, or -1 with errno set when either file cannot be read (ENOENT for a missing file, EINVAL
 *         for NULL or an empty path; EIO on Windows when one file gives a 128-bit id and the other only a 64-bit index,
 *         which do not compare); @p same is then 0.
 */
int dsd_path_same_file(const char* a, const char* b, int* same);

/**
 * @brief The bytes free to this user on the volume that holds @p path.
 *
 * Free space only: statvfs() on POSIX and Android, GetDiskFreeSpaceExW() on Windows. Nothing else about the volume is
 * read (no label, no mount table), so on Android it makes no request the app's SELinux policy denies, as QStorageInfo's
 * label lookup does.
 *
 * @param path  A folder on the volume (Windows refuses a file's path: ENOTDIR).
 * @return The free bytes (capped at INT64_MAX), or -1 when they cannot be read, with errno set (ENOENT for a missing
 *         folder, EINVAL for NULL or an empty path).
 */
int64_t dsd_path_free_bytes(const char* path);

/**
 * @brief Remove the file at @p path: remove() on POSIX; on Windows the wide or the ANSI call, as the file note says.
 * @return 0, or -1 with errno set.
 */
int dsd_remove_file(const char* path);

#if DSD_PLATFORM_WIN_NATIVE
#include <wchar.h>
/**
 * @brief @p path as UTF-16 for the wide Windows file calls when it is well-formed UTF-8, as the app's own paths are in
 * any script; NULL when it is not (a path in the ANSI code page, as a command line gives it) or memory runs out. The
 * caller frees it. Windows only, and only a conversion: NULL does not tell those two answers apart, so the path helpers
 * decide wide or ANSI by dsd_win32_path_wide(), never by this.
 */
wchar_t* dsd_win32_utf8_path_to_wide(const char* path);

/**
 * @brief The one encoding rule every Windows path helper follows (see the file note): which call @p path goes through.
 *
 * @param path      Path, UTF-8 or in the ANSI code page.
 * @param out_wide  Receives @p path as UTF-16 when the answer is 1 (the caller frees it), else NULL.
 * @return 1: @p path is well-formed UTF-8, use the wide call with @p out_wide only. 0: it is not, use the ANSI call
 *         with @p path only. -1 with errno set: EINVAL for a NULL argument, ENOMEM when the copy cannot be made.
 */
int dsd_win32_path_wide(const char* path, wchar_t** out_wide);
#endif

/**
 * @brief Resolve a user-supplied local file name to an existing file in the current directory.
 *
 * The requested name must be a bare file name: no path separators, absolute
 * paths, empty names, or ".." segments. On success, @p out receives the
 * directory entry name for the existing regular file.
 *
 * @param requested  User-supplied bare file name.
 * @param out        Output buffer.
 * @param out_size   Output buffer size.
 * @return 0 on success, -1 on error with errno set.
 */
int dsd_resolve_existing_local_file(const char* requested, char* out, size_t out_size);

/**
 * @brief Open an existing regular file from the current directory by bare local file name.
 *
 * The requested name must be a bare file name: no path separators, absolute
 * paths, empty names, or ".." segments. On success, @p out receives the
 * directory entry name used to open the file.
 *
 * @param requested  User-supplied bare file name.
 * @param out        Output buffer.
 * @param out_size   Output buffer size.
 * @return Read stream for the existing regular file, or NULL with errno set.
 */
FILE* dsd_fopen_existing_local_file(const char* requested, char* out, size_t out_size);

/**
 * @brief Open an existing regular file by path for read-only access.
 *
 * The final path is opened without following symlinks/reparse points where the
 * platform exposes that protection. Only read modes such as "r" and "rb" are
 * accepted.
 *
 * @param path  Existing file path.
 * @param mode  fopen-compatible read-only mode.
 * @return Read stream for the existing regular file, or NULL with errno set.
 */
FILE* dsd_fopen_existing_regular_file(const char* path, const char* mode);

/**
 * @brief Open @p path for binary appending, creating it owner-only when absent, never waiting on what is there.
 *
 * As dsd_fopen_private(path, "ab"), except that only a regular file is ever opened: the final name is opened without
 * following a link (ELOOP on POSIX; a reparse point on Windows is refused with EINVAL), non-blocking, so a FIFO no
 * process reads fails at once instead of holding the open, and anything opened that is not a regular file (a FIFO
 * something reads, a device) is closed again, untouched, with EINVAL. A folder fails too (EISDIR or EINVAL). Writes
 * through the stream block as usual.
 *
 * @param path  File path.
 * @return Append stream for the regular file, or NULL with errno set.
 */
FILE* dsd_fopen_private_append_regular(const char* path);

/**
 * @brief Callback invoked once per regular file found by dsd_dir_list().
 *
 * @param name  Directory entry name with no path prefix.
 * @param user  Opaque pointer forwarded from the caller.
 * @return 0 to continue the walk, non-zero to stop it.
 */
typedef int (*dsd_dir_list_cb)(const char* name, void* user);

/**
 * @brief List the regular files in a directory.
 *
 * Entries are reported by bare name with no path prefix; "." and ".." and every
 * subdirectory are skipped. The order is whatever the platform returns, so a
 * caller that needs a stable order must sort. Stopping the walk by returning
 * non-zero from @p cb is not an error. On Windows names come back in the
 * folder's encoding: a UTF-8 folder reports UTF-8 names (skipping a name that
 * has no UTF-8 form), an ANSI one ANSI names.
 *
 * @param dir   Directory to walk.
 * @param cb    Per-entry callback.
 * @param user  Opaque pointer forwarded to @p cb.
 * @return 0 when the directory was walked to the end or the callback stopped it;
 *         -1 with errno set when the directory cannot be opened or reading it
 *         failed part-way (entries already reported are not retracted).
 */
int dsd_dir_list(const char* dir, dsd_dir_list_cb cb, void* user);

/**
 * @brief Read from a file descriptor.
 *
 * @param fd        File descriptor.
 * @param buf       Output buffer.
 * @param count     Bytes to read.
 * @return Number of bytes read, 0 on EOF, or -1 on error.
 */
ssize_t dsd_read(int fd, void* buf, size_t count);

/**
 * @brief Wait up to @p timeout_ms for a read on @p fd to return without blocking.
 *
 * A descriptor at end of stream or with an error counts as ready, so the read that follows reports it. On Windows only
 * an anonymous pipe can be waited on (PeekNamedPipe()); a console, a regular file or any other handle reports ready at
 * once, and the read that follows may block.
 *
 * @param fd          File descriptor.
 * @param timeout_ms  Longest wait in milliseconds (0 polls).
 * @return 1 when ready, 0 on timeout or a signal interruption, -1 on failure.
 */
int dsd_fd_wait_readable(int fd, unsigned int timeout_ms);

/**
 * @brief Whether a descriptor is a stream another program feeds: a pipe, FIFO or socket (on Windows a pipe).
 *
 * Only such a descriptor's readiness (dsd_fd_wait_readable()) says data is there: a regular file, a console or a
 * terminal reports ready whether or not a read would wait.
 *
 * @param fd File descriptor.
 * @return 1 for a pipe, FIFO or socket, 0 otherwise and on failure.
 */
int dsd_fd_is_stream(int fd);

/**
 * @brief Whether a read of @p fd can block with no bounded wait to put before it: on Windows a console or other
 * character device (a serial port), whose readiness dsd_fd_wait_readable() cannot tell. Never on POSIX, where a
 * terminal or device is polled.
 *
 * @param fd File descriptor.
 * @return 1 for such a descriptor, 0 otherwise and on failure.
 */
int dsd_fd_read_unbounded(int fd);

/**
 * @brief The bytes a pipe, FIFO or socket descriptor holds ready to read, without reading them (FIONREAD; on Windows
 * PeekNamedPipe() on a pipe). Safe while another thread reads the descriptor.
 *
 * @param fd File descriptor.
 * @return The bytes ready, or -1 for a descriptor that is not such a stream and on failure.
 */
long dsd_fd_readable_bytes(int fd);

/**
 * @brief Write to a file descriptor.
 *
 * @param fd        File descriptor.
 * @param buf       Data buffer.
 * @param count     Bytes to write.
 * @return Number of bytes written, or -1 on error.
 */
ssize_t dsd_write(int fd, const void* buf, size_t count);

/** What dsd_write_frames() did with a buffer. */
typedef enum {
    DSD_WRITE_FRAMES_OK = 0,      /**< every byte was written */
    DSD_WRITE_FRAMES_WOULD_BLOCK, /**< the descriptor would block at a frame boundary: the frames before it went out,
                                       the rest of the buffer did not, and the stream is still frame-aligned */
    DSD_WRITE_FRAMES_ERROR,       /**< a write failed (errno says why); the stream may end in the middle of a frame */
} dsd_write_frames_status;

/**
 * @brief Write a buffer of whole sample frames to a file descriptor.
 *
 * Retries interrupted writes and continues after short counts. On a non-blocking descriptor that is full it never
 * spins: at a frame boundary it returns DSD_WRITE_FRAMES_WOULD_BLOCK at once, and only when a short count left part of
 * a frame written does it wait (a bounded time) for room to finish that frame. A write that returns 0 is an error
 * (EIO). A reader that has gone away is an error (EPIPE) and never raises SIGPIPE: on POSIX the signal the write
 * raises in the calling thread is blocked and consumed (macOS: the descriptor's no-SIGPIPE flag is set), leaving the
 * process's signal dispositions and any SIGPIPE already pending alone.
 *
 * @param fd          File descriptor.
 * @param buf         Data buffer.
 * @param bytes       Bytes to write.
 * @param frame_bytes Bytes per sample frame (0 is taken as 1).
 * @param written     Optional; receives the bytes written.
 * @return What happened; errno is set when the result is DSD_WRITE_FRAMES_ERROR.
 */
dsd_write_frames_status dsd_write_frames(int fd, const void* buf, size_t bytes, size_t frame_bytes, size_t* written);

/**
 * @brief Get the null device path for this platform.
 *
 * @return "/dev/null" on POSIX, "NUL" on Windows.
 */
const char* dsd_null_device(void);

/**
 * @brief Standard file descriptor numbers.
 */
#if DSD_PLATFORM_WIN_NATIVE
#include <io.h>
#define DSD_STDIN_FILENO  0
#define DSD_STDOUT_FILENO 1
#define DSD_STDERR_FILENO 2
#else
#include <unistd.h>
#define DSD_STDIN_FILENO  STDIN_FILENO
#define DSD_STDOUT_FILENO STDOUT_FILENO
#define DSD_STDERR_FILENO STDERR_FILENO
#endif

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_PLATFORM_FILE_COMPAT_H_H */

// SPDX-License-Identifier: GPL-3.0-or-later
/**
 * @file
 * @brief P25 trunking state-machine interfaces and constants.
 *
 * This is the unified P25 trunking state machine. Design goals:
 *   - Single state machine for both P25P1 and P25P2
 *   - Minimal timing parameters (hangtime, grant_timeout, cc_grace)
 *   - Single timestamp-based activity tracking per slot
 *   - Unified release path with clear semantics
 *   - Event-driven transitions matching OP25's simpler model
 */
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_TRUNK_SM_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_TRUNK_SM_H_H

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/receive_types.h>
#include <dsd-neo/core/state_fwd.h>
#include <dsd-neo/runtime/trunk_tuning_hooks.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================================
 * High-level trunk SM mode (for UI/telemetry)
 * ============================================================================ */

typedef enum {
    DSD_P25_SM_MODE_UNKNOWN = 0,
    DSD_P25_SM_MODE_ON_CC = 1,
    DSD_P25_SM_MODE_ON_VC = 2,
    DSD_P25_SM_MODE_HANG = 3,
    DSD_P25_SM_MODE_HUNTING = 4,
    // Extended states for richer UI/telemetry across P1/P2
    DSD_P25_SM_MODE_ARMED = 5,     // tuned to VC, awaiting PTT/ACTIVE
    DSD_P25_SM_MODE_FOLLOW = 6,    // following active voice
    DSD_P25_SM_MODE_RETURNING = 7, // teardown in progress back to CC
} dsd_p25_sm_mode_e;

/* ============================================================================
 * State Machine States (4-state model aligned with OP25)
 * ============================================================================ */

typedef enum {
    P25_SM_IDLE = 0, // Not trunking or no CC known
    P25_SM_ON_CC,    // Parked on control channel, listening for grants
    P25_SM_TUNED,    // On voice channel (awaiting voice, active, or hangtime)
    P25_SM_HUNTING,  // Lost CC, searching candidates
} p25_sm_state_e;

typedef enum {
    P25_SM_CC_ACQUISITION_NONE = 0,
    P25_SM_CC_ACQUISITION_RETURN,
    P25_SM_CC_ACQUISITION_HUNT_PROBE,
} p25_sm_cc_acquisition_origin_e;

enum {
    // Grant decoder sentinel for opcodes that do not carry service options.
    // Passing svc_bits=0 explicitly clears the service option.
    P25_SM_SVC_UNKNOWN = -1,
    // Exact MAC_PTT octets 1-17, excluding the SACCH/FACCH transport header.
    P25_SM_PTT_SIGNATURE_BYTES = 17,
};

/** Return non-zero only for a subscriber source ID: not 0, and not a special address ($FFFFFC-$FFFFFF: FNE use, System
 * Default, Registration Default, ALL units; TIA-102.AABC-D Table 2.3.30-1), as dsd_position_source_names_radio()
 * reads a P25 source. */
static inline int
p25_source_id_is_subscriber(uint64_t source) {
    return source != 0U && !(source >= 0xFFFFFCU && source <= 0xFFFFFFU);
}

typedef enum {
    // Callers constructing grant events directly should identify whether the
    // decoded message starts an assignment or only updates one. UNKNOWN keeps
    // conservative post-END handling for compatibility with unclassified input.
    P25_SM_GRANT_PROVENANCE_UNKNOWN = 0,
    P25_SM_GRANT_PROVENANCE_ASSIGNMENT,
    P25_SM_GRANT_PROVENANCE_UPDATE,
} p25_sm_grant_provenance_e;

/* ============================================================================
 * Identity provenance (issue #800, spec 2.19)
 * ============================================================================ */

/* Which identity fields came from content whose own check passed: the source, the target (talkgroup or destination)
 * and the kind (group or private). The message that names a value sets that field's bit from its own check, and a
 * message that inherits the field keeps that bit. A later message naming the same value sets the bit when its check
 * passed and never clears it; one that omits the field (0 or absent) leaves it; one naming another value replaces the
 * field and its bit. A new call epoch, a release or a reset clears all three; a failed check never sets one. */
enum {
    P25_SM_IDENTITY_CHECKED_SOURCE = 0x01,
    P25_SM_IDENTITY_CHECKED_TARGET = 0x02,
    P25_SM_IDENTITY_CHECKED_KIND = 0x04,
    P25_SM_IDENTITY_CHECKED_ALL = 0x07,
};

/** 1 when a source named only by its home SUID (@p wacn, @p sysid) is a local radio of the current reception: the
 * reception's checked network status (dsd_state::rx_id, DSD_RXID_P25_WACN) names exactly that WACN and System ID. A
 * home of another system, or a reception whose system is not known yet, gives 0 (fail closed, issue #800): such an ID
 * is not a local working address, so it never earns a checked source (p25_sm_event_t::source_nonlocal). */
int p25_sm_suid_home_is_local(const dsd_state* state, uint32_t wacn, uint32_t sysid);

/* The identity of a slot's canonical call as the state machine and the Phase 2 voice users last named it, and which of
 * its fields are checked, under which reception. */
typedef struct {
    uint64_t epoch;   // Canonical call epoch the identity was published under; 0 = none
    uint64_t rx_gen;  // dsd_state_reception_generation() at the last publication: the checked flags were earned
                      // under it and count only there, and attribution binds to it
    uint32_t source;  // Source RID, 0 = none
    uint32_t target;  // Talkgroup (group) or destination RID (private)
    int32_t protocol; // DSD_SYNC_* of the published call
    uint8_t kind;     // dsd_call_kind of the published call
    uint8_t is_group; // 1 when target is a talkgroup
    uint8_t checked;  // P25_SM_IDENTITY_CHECKED_* bits
    uint8_t reserved[1];
} p25_sm_published_identity;

/* ============================================================================
 * Events
 * ============================================================================ */

typedef enum {
    P25_SM_EV_GRANT = 0,      // Channel grant received (channel, freq, tg, src, svc_bits)
    P25_SM_EV_PTT,            // MAC_PTT on slot
    P25_SM_EV_ACTIVE,         // MAC_ACTIVE on slot
    P25_SM_EV_END,            // MAC_END transmission boundary on slot
    P25_SM_EV_IDLE,           // MAC_IDLE transmission boundary on slot
    P25_SM_EV_TDU,            // P1 Terminator Data Unit transmission boundary
    P25_SM_EV_HANGTIME,       // P2 MAC_HANGTIME transmission boundary on slot
    P25_SM_EV_CC_SYNC,        // Control channel sync acquired
    P25_SM_EV_VC_SYNC,        // Voice channel sync acquired
    P25_SM_EV_SYNC_LOST,      // Sync lost
    P25_SM_EV_ENC,            // Encryption params detected on slot (algid, keyid)
    P25_SM_EV_CRYPTO_PENDING, // In-band encrypted indication awaiting definitive metadata
} p25_sm_event_type_e;

typedef struct {
    p25_sm_event_type_e type;
    int slot;                                          // 0 or 1 for TDMA, -1 for P1/N/A
    int channel;                                       // 16-bit channel number (for GRANT)
    long freq_hz;                                      // Frequency in Hz (for GRANT)
    int tg;                                            // Talkgroup (for GRANT/PTT/END, 0 if individual or unavailable)
    int src;                                           // Source RID (for GRANT/PTT/END, 0 if unavailable)
    int dst;                                           // Destination RID (for individual GRANT)
    int svc_bits;                                      // Service options (for GRANT), or P25_SM_SVC_UNKNOWN when absent
    int is_group;                                      // 1 for group grant, 0 for individual
    p25_sm_grant_provenance_e grant_provenance;        // Initial assignment or continuing assignment update
    int algid;                                         // Algorithm ID (for ENC event)
    int keyid;                                         // Key ID (for ENC event)
    int data_call_override;                            // 0=infer from svc_bits, 1=force data, -1=force non-data
    int identity_valid;                                // 1 when PTT/ACTIVE carries a decoded call identity
    int source_absent;                                 // 1 when the message type carries no source by design
    int facch;                                         // 1 when PTT/END was decoded from valid FACCH
    int crypto_new_epoch;                              // 1 when CRYPTO_PENDING must start a fresh deadline
    double observed_m;                                 // Optional monotonic timestamp when the event was observed
    uint8_t ptt_signature[P25_SM_PTT_SIGNATURE_BYTES]; // Optional exact MAC octets 1-17 for PTT
    int ptt_signature_valid;                           // 1 when ptt_signature and observed_m are authoritative
    uint32_t grant_seq;                                // IDLE: the slot's grant_seq when the IDLE was observed
    int grant_seq_valid;                               // 1 when grant_seq is set
    int preempt_only; // GRANT announced on a voice channel for another carrier: considered only as a preemption
    // P25_SM_IDENTITY_CHECKED_* bits for src, tg/dst and is_group: which of them came from a message whose own check
    // the producer ran and saw pass. Unchecked (0) unless the producer sets it; the builders below never do. A Phase 2
    // MAC_SIGNAL whose CRC failed (-F) leaves it 0 and is still followed, as documented for -F.
    uint8_t identity_checked;
    // 1 when the source field names the talker only by an ID that is not a complete local address of this reception: a
    // home SUID of another (or a not yet known) system (p25_sm_suid_home_is_local()), or a Phase 1 link control that
    // needs a Source ID Extension. The value stays for display; as evidence it is a special address's: never checked,
    // and it takes the source's flag away (spec 2.19, issue #800).
    uint8_t source_nonlocal;
} p25_sm_event_t;

/* ============================================================================
 * Configuration
 * ============================================================================ */

typedef struct {
    double hangtime_s;      // Hangtime after voice ends (default 2.0s)
    double grant_timeout_s; // Max wait for voice after grant (default 3.0s)
    double cc_grace_s;      // CC acquisition/loss grace; active hunt probes are capped at 2.0s
} p25_sm_config_t;

/* ============================================================================
 * Per-Slot Activity Context
 * ============================================================================ */

typedef struct {
    double last_active_m; // Monotonic timestamp of last activity (PTT/ACTIVE/voice)
    double last_start_m;  // Monotonic timestamp of the last PTT/ACTIVE call-epoch boundary
    double last_stop_m;   // Monotonic timestamp when the last followed epoch transitioned inactive
    // Monotonic timestamp this slot last carried traffic the SM was following,
    // 0 when it has carried none on the current carrier. The hangtime deadline
    // is derived from these two per-slot stamps rather than armed
    // (p25_sm_hangtime_started_m), so signaling the SM is not following -- a
    // locked-out slot's MAC repeats, an encryption-lockout reprobe assignment
    // -- can neither restart nor erase the countdown by construction.
    double last_followed_m;
    // The call this slot has followed since followed_since_m: target, kind and carrier. A repeat or a re-grant of
    // the same call keeps the stamp, so preemption dwell runs from when the call was first followed; a different
    // call, a physical retune or a release restarts it (p25_sm_clear_followed_history()).
    double followed_since_m;
    int followed_target;
    int followed_is_group;
    long followed_freq_hz;

    int voice_active;        // 1 if voice is currently active on this slot
    int algid;               // Current algorithm ID for this slot
    int keyid;               // Current key ID for this slot
    int tg;                  // Current talkgroup for this slot
    int grant_active;        // 1 if this TDMA slot has an accepted grant context
    int channel;             // Accepted grant channel number
    long freq_hz;            // Accepted grant RF frequency
    int target_id;           // Policy-selected target ID, or OTA target when no policy remap
    int ota_tg;              // OTA talkgroup for group grants
    int src;                 // Source RID
    int dst;                 // Destination RID for individual grants
    int is_group;            // 1 for group call, 0 for individual/private
    int data_call;           // 1 for data grant, 0 for voice
    int svc_bits;            // Service options, or P25_SM_SVC_UNKNOWN when absent
    int enc_override_clear;  // 1 when regroup KEY=0 supplied the current clear classification
    int enc_lockout_reprobe; // 1 when this assignment was re-admitted from the encryption-lockout
                             // ledger by a clear-claiming grant. The SM has no positive evidence
                             // for it, so it may acquire but may not outlive the hangtime the last
                             // followed transmission set.
    // Group identity retained while the TDMA media rejection latch is set.
    uint32_t rejected_target_id;
    double last_grant_m;     // Monotonic timestamp of last accepted grant for this slot
    uint32_t grant_seq;      // SM-wide sequence number of the last_grant_m stamp. Orders a grant against an
                             // IDLE observed at the same clock reading, which time alone cannot (issue #747).
    int acquire_ended;       // 1 once a voice start or stop ended the wait acquire_since_m began. A flag, not a time
                             // comparison: the grant, its voice and its end can share one decode-clock reading.
    double acquire_since_m;  // Start of the wait for this assignment's voice. Repeats of the grant keep it, in update
                             // or assignment form; a new follow, a voice start or stop since it, or a slot cleared
                             // after voice restarts it. Bounds how long a voiceless assignment holds the slot against
                             // preemption.
    double crypto_attempt_m; // Monotonic start of the current crypto classification attempt
    double last_end_m;       // Monotonic timestamp of the last accepted MAC_END_PTT
    int last_end_tg;         // Talkgroup carried by the last accepted MAC_END_PTT
    int last_end_src;        // Source RID carried by the last accepted MAC_END_PTT
    double facch_end_m;      // Monotonic timestamp of the first qualifying FACCH END_PTT
    int facch_end_tg;        // Identity carried by the qualifying FACCH END_PTT
    int facch_end_src;
    uint8_t ptt_signature[P25_SM_PTT_SIGNATURE_BYTES]; // Last accepted raw P25P2 MAC_PTT signature
    int ptt_signature_valid;                           // 1 while no accepted call boundary/replacement intervened
    double ptt_last_seen_m;                            // Last observation of that PTT, including retransmissions
    uint64_t ptt_canonical_epoch;                      // Canonical epoch that most recently accepted a MAC_PTT
    double last_enc_suppress_m; // Monotonic timestamp of the last enc-lockout suppression action on this slot.
                                // The suppressed transmission occupies the carrier with no assignment, epoch,
                                // or audio trace, so this is the only evidence of it that survives the teardown.
    uint8_t identity_checked;   // P25_SM_IDENTITY_CHECKED_* bits for src, ota_tg/dst and is_group (assignment)
    /* dsd_state_reception_generation() the assignment's flags were earned under: they count only there. A grant
       stores it after the retune it causes, so its checked talker carries to the channel it sends the receiver to. */
    uint64_t identity_rx_gen;
    p25_sm_published_identity published; // Identity last published for this slot's canonical call
} p25_sm_slot_ctx_t;

typedef struct {
    double end_m;        // Monotonic timestamp when the quarantine was armed
    double last_match_m; // Monotonic timestamp of the last matching CC update
    long freq_hz;        // Ended call RF frequency
    int slot;            // Ended TDMA slot
    int target;          // OTA talkgroup for group calls, destination RID for private calls
    int src;             // Source RID accepted from MAC_END_PTT, or an unknown-source value
    int is_group;        // 1 for group call, 0 for individual/private
    int probe_attempted; // 1 after the bounded validation tune becomes eligible
    int valid;           // 1 while matching ambiguous CC updates remain quarantined
} p25_sm_recent_call_end_t;

/**
 * Targets tracked for the encryption-lockout reprobe backoff. Sized so that a
 * busy site's set of concurrently locked-out talkgroups fits: a live cooldown
 * is never evicted to make room, so a table too small to hold them would hand
 * the overflow targets no backoff at all.
 */
enum { P25_SM_ENC_REPROBE_MEMO_MAX = 16 };

/**
 * One target re-admitted from the encryption-lockout ledger because a grant
 * claimed clear service options. The ledger entry is consumed by that
 * admission, so without this record every repeat of the same grant update
 * looks like the first one.
 */
typedef struct {
    double admitted_m; // Monotonic timestamp of the re-admission, 0 when unused
    uint32_t target;   // OTA talkgroup for group calls, destination RID for private calls
    uint8_t is_group;  // 1 for group/SG target, 0 for private destination
} p25_sm_enc_reprobe_memo_t;

/* ============================================================================
 * State Machine Context
 * ============================================================================ */

typedef struct {
    // Current state
    p25_sm_state_e state;

    // Configuration (cached from opts or defaults)
    p25_sm_config_t config;

    // Voice channel context (valid when state >= ARMED)
    long vc_freq_hz;
    int vc_channel;
    int vc_tg;
    int vc_src;
    int vc_is_tdma;                  // 1 if TDMA channel, 0 if single-carrier
    int vc_data_call;                // 1 if the accepted grant is data, 0 if voice
    int vc_cqpsk_retry_done;         // 1 once we retried VC tune with alternate CQPSK DSP mode for this grant
    int vc_reacquire_eligible;       // 1 while a no-sync VC release may use one CQPSK soft recovery attempt
    int vc_reacquire_attempted;      // 1 after the one-shot CQPSK soft recovery check for this VC tune
    int vc_stale_regrant_probe;      // 1 while an ambiguous post-END update is being validated on the VC
    int vc_stale_regrant_probe_slot; // TDMA slot being validated, or -1 when no validation is active
    int vc_activity_seen;            // 1 after the first traffic activity following a physical VC tune
    uint32_t cc_no_sync_passes;      // Completed frame-sync searches while a returned CC is still undecoded
    uint32_t vc_no_sync_passes;      // Completed frame-sync searches without P25P2 sync during VC acquisition

    // Per-slot identity quarantines for voice calls ended by MAC_END_PTT.
    // Ambiguous CC updates for each ended target/carrier/slot are suppressed
    // until quiet or until one bounded validation tune becomes eligible.
    p25_sm_recent_call_end_t recent_call_ends[2];

    // Per-slot activity (index 0 = left/P1, index 1 = right)
    p25_sm_slot_ctx_t slots[2];

    // Targets recently re-admitted from the encryption-lockout ledger by a
    // clear-claiming grant. Survives the carrier release the failed reprobe
    // ends in, which is the whole point: the ledger entry the reprobe consumed
    // is gone by then, so nothing else can tell the site's next identical grant
    // update apart from the first one.
    p25_sm_enc_reprobe_memo_t enc_reprobes[P25_SM_ENC_REPROBE_MEMO_MAX];

    // Timing
    double t_tune_m;                // Monotonic time of last VC tune
    double receive_check_started_m; // Repeated grants cannot extend a receive-policy acquisition window
    // The NAC last verified on each voice channel, so a grant to one the receive policy rejects is not followed.
    dsd_receive_carriers receive_carriers;
    // Whether this carrier's codes were forgotten at its tune, so what it holds now it proved;
    // receive_check_freq_hz is the carrier that answer belongs to.
    int receive_codes_fresh;
    long receive_check_freq_hz;
    double t_voice_m; // Monotonic time of last voice activity
    // The hangtime countdown has no field: it is derived from the per-slot
    // last_followed_m stamps by p25_sm_hangtime_started_m().
    double t_cc_sync_m;          // Monotonic time of last CC sync
    double t_cc_tune_m;          // Monotonic time of last CC tune awaiting decode
    double t_cc_reacquire_m;     // Monotonic time a soft CQPSK reacquire was queued
    double t_cc_first_no_sync_m; // Monotonic time of the first completed no-sync CC search
    double t_vc_reacquire_m;     // Monotonic time a VC soft CQPSK reacquire was queued
    double t_vc_first_no_sync_m; // Monotonic time of the first completed no-sync VC search
    double t_hunt_try_m;         // Monotonic time of last CC candidate attempt
    uint64_t cc_tune_request_id; // Runtime request awaiting asynchronous tune completion
    int cc_tune_pending;         // 1 while the tuner/output pipeline is still changing channels
    int cc_sync_pending;         // 1 until a completed CC tune is followed by decoded CC sync
    int cc_reacquire_attempted;  // 1 after the one-shot soft recovery check for this acquisition
    p25_sm_cc_acquisition_origin_e cc_acquisition_origin; // Origin of pending decoded-CC acquisition

    // Startup control-channel hunt (issue #703): a single-system session whose start frequency yields no validated
    // control within the grace window walks its channel map with the ordinary hunt. Decoder thread only
    // (p25_sm_cold_start_tick_locked()); the watchdog never ticks a machine whose cold_start_hunt is set.
    double t_cold_start_armed_m; // Monotonic time the startup window opened; 0 while unarmed
    int cold_start_hunt;         // 1 while a hunt the startup window started runs and no owner is named
    int cold_start_park_pending; // 0 none; 1 park keeping the window, 2 park unarmed, once settled
    long cold_start_probe_hz;    // Last startup probe tuned (OK or pending); 0 after a park or operator move

    // Statistics (for debugging/UI)
    uint32_t tune_count;
    uint32_t release_count;
    uint32_t grant_count;
    uint32_t cc_return_count;

    // NAC mismatch tracking: counts consecutive frames where the decoded NAC
    // differs from the expected CC NAC. After a threshold, triggers cc-lost
    // to avoid dwelling on a wrong-NAC channel for seconds. Keep the expected
    // NAC in the SM because state->p2_cc can be refreshed by each decoded P1 NID.
    int expected_cc_nac;
    int nac_mismatch_count;

    // Initialized flag
    int initialized;
} p25_sm_ctx_t;

/* ============================================================================
 * Public API - Core State Machine
 * ============================================================================ */

/**
 * @brief Initialize the unified P25 state machine.
 *
 * Reads timing parameters from opts/env, sets initial state based on CC presence.
 *
 * @param ctx State machine context to initialize.
 * @param opts Decoder options (may be NULL for defaults).
 * @param state Decoder state (may be NULL).
 */
void p25_sm_init_ctx(p25_sm_ctx_t* ctx, const dsd_opts* opts, dsd_state* state);

/**
 * @brief Process an event and update state machine.
 *
 * This is the main entry point for all P25 signaling events.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param ev Event to process.
 */
void p25_sm_event(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, const p25_sm_event_t* ev);

/**
 * @brief Seed an unknown P25 control-channel frequency from known CC state.
 *
 * Control-channel grant decoders call this before gating on state->p25_cc_freq
 * so the first live grant can establish the CC frequency for return-to-CC
 * behavior. The generic trunk-owner CC is preferred when it is already known.
 * Otherwise the tuner is sampled only while P25-specific tune state indicates the
 * decoder is parked on the control channel; voice-channel tunes are ignored.
 * Live P25 Phase 2 LCCH context seeds a TDMA CC modulation hint; ordinary
 * Phase 2 traffic sync leaves the hint unchanged. Live P25 Phase 1 sync clears
 * any stale TDMA CC hint.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_seed_cc_from_current_tuner_if_unknown(const dsd_opts* opts, dsd_state* state);

/**
 * @brief Note a validated P25 control block at its decode boundary (issue #703).
 *
 * Records control-channel activity (p25_sm_note_cc_activity(): the P25 owner, the decode stamps and the patch table's
 * listening clock) and, with trunking on, establishes the control channel from the tuner that carried the block when
 * none is known yet (p25_sm_seed_cc_from_current_tuner_if_unknown()). Running here rather than in a later tick keeps a
 * retune queued behind the block from lending its frequency to this evidence. Call it only for a TSBK, MBT or LCCH MAC
 * whose CRC passed: never for a voice channel's signalling, which would advance the listening clock.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_note_validated_cc(const dsd_opts* opts, dsd_state* state);

/**
 * @brief Run the startup control-channel hunt for one decoder-thread pass (issue #703).
 *
 * Arms the startup window while the machine is IDLE in an eligible session (dsd_state_trunk_cold_start_eligible())
 * whose startup P25 hunts (recovery admitted, or dsd_trunk_p25_cold_start_presumed()); once the window, measured
 * from the later of its opening and the last validated DMR or NXDN content (dsd_state::dmr_confidence_lock_m,
 * dsd_state::nxdn_confirm_lock_m), exceeds the CC grace it starts the ordinary map hunt, and while that hunt runs it
 * ticks the machine and ends or parks it (spec of #703: ends in place once validated control names an owner, parks
 * only once the tuning layer is settled). The caller holds the P25 SM tick guard; the watchdog never calls this.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_cold_start_tick_locked(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state);

/**
 * @brief Note an operator move of the receiver during the startup window or hunt (issue #703).
 *
 * Restarts the startup window at the move; a running startup hunt is marked to park keeping that window once the
 * tuning layer is settled. No-op outside the startup state. The caller holds the P25 SM tick guard.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_cold_start_note_retune(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state);

/** @brief Return 1 while the startup window is armed or a startup hunt runs (issue #703). */
int p25_sm_cold_start_active(const p25_sm_ctx_t* ctx);

/** @brief Return 1 while the machine hunts a control channel: HUNTING between probes, or ON_CC on a hunt probe whose
 *  control has not decoded yet. The startup hunt and recovery both probe this way. Read under the P25 SM tick guard
 *  (or on the thread that ticks the machine). */
int p25_sm_hunt_probe_in_flight(const p25_sm_ctx_t* ctx);

/** @brief Return 1 while the decoder's startup tick has work: the window armed or a hunt running, or an IDLE machine
 *  whose window the next tick arms (issue #703). Decoder thread, under the P25 SM tick guard. */
int p25_sm_cold_start_due(const p25_sm_ctx_t* ctx, const dsd_opts* opts, const dsd_state* state);

/**
 * @brief Select a new control channel during single-system P25 trunk following.
 *
 * Owns the watchdog guard; call on the decoder thread without holding it.
 * FAILED/DEFERRED leave the old channel and calls intact. OK/PENDING end the
 * old calls, forget site acquisition data, and retain the new CC through
 * asynchronous completion/recovery. CC acquisition and its grace window start
 * at the tune request's completion stamp, also when the request completed
 * before the call returns. Network band plans and user settings survive.
 * Requires an initialized context and a positive frequency in Hz.
 */
dsd_trunk_tune_result p25_sm_select_control_channel(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, long hz);

/**
 * @brief Start CC acquisition after a completed external retune.
 *
 * Refreshes the acquisition baseline and returns the context to ON_CC so the
 * normal acquisition watchdog grants the completed tune its full configured
 * grace period. The two-second acquisition bound applies only to active hunt
 * probes initiated by the state machine.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param tune_start_m Monotonic timestamp captured after retune completion.
 * @param source Short diagnostic source label.
 * @return 1 when acquisition was started, 0 otherwise.
 */
int p25_sm_restart_pending_cc_acquisition(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, double tune_start_m,
                                          const char* source);

/**
 * @brief Hold CC acquisition until an exact asynchronous retune completes.
 *
 * No acquisition deadline begins until the supplied request completes, even
 * for a previously synchronized parked context. After completion, external
 * returns receive the full configured grace period; the two-second bound
 * applies only to active hunt probes initiated by the state machine.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param request_id Runtime tune request being awaited.
 * @param source Short diagnostic source label.
 * @return 1 when the pending tune was recorded, 0 on invalid input.
 */
int p25_sm_await_pending_cc_tune(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, uint64_t request_id,
                                 const char* source);

/**
 * @brief Park the SM after an external tune to the control channel (#506).
 *
 * Frontend commands (user talkgroup lockout, manual return-to-CC) retune the
 * radio to the control channel through the tuning hooks themselves, bypassing
 * p25_sm_release(). Without this handoff the SM stays TUNED with the old
 * assignment's slot activity and judges every later grant as a preemption of
 * that phantom call. For a TUNED SM this ends the followed calls and clears
 * the assignment context; a parked or hunting SM keeps its context. Either
 * way it starts the same decoded-CC acquisition gate every return goes
 * through, so grants stay blocked until the CC decodes after the tune.
 *
 * The caller holds the watchdog guard across its tune, its decoder resets and
 * this handoff (p25_sm_tick_guard_enter()), like p25_sm_select_control_channel()
 * does internally: a watchdog tick in between would see a TUNED context with
 * no tuned decoder and issue a second CC return of its own.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param tune_result Result of the CC tune the caller already issued.
 * @param request_id Runtime tune request for PENDING results, 0 when unknown.
 * @param source Short diagnostic source label.
 * @return 1 when the SM was handed off, 0 when the tune was refused or the SM
 *         was idle and had nothing to hand off.
 */
int p25_sm_on_external_cc_tune(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, dsd_trunk_tune_result tune_result,
                               uint64_t request_id, const char* source);

/**
 * @brief Periodic tick for timeout-based transitions.
 *
 * Call at ~1-10 Hz. Handles:
 *   - ARMED -> ON_CC (initial traffic grant timeout)
 *   - retained traffic carrier -> ON_CC (inactivity hangtime expired)
 *   - ON_CC -> HUNTING (CC lost)
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 */
void p25_sm_tick_ctx(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state);

/**
 * @brief Get current state machine state.
 *
 * @param ctx State machine context.
 * @return Current state.
 */
static inline p25_sm_state_e
p25_sm_get_state(const p25_sm_ctx_t* ctx) {
    return ctx ? ctx->state : P25_SM_IDLE;
}

/**
 * @brief Get human-readable state name.
 *
 * @param state State to convert.
 * @return Static string with state name.
 */
const char* p25_sm_state_name(p25_sm_state_e state);

/**
 * @brief Access the global singleton state machine instance.
 *
 * Returns a process-global instance initialized with default callbacks.
 *
 * @return Pointer to global state machine context.
 */
p25_sm_ctx_t* p25_sm_get_ctx(void);

/**
 * @brief When the tuned carrier's hangtime countdown started, or 0 when none runs.
 *
 * Derived, never armed: the most recent moment any slot carried traffic the SM
 * was following, and 0 while a slot still is. Because only followed traffic
 * writes p25_sm_slot_ctx_t.last_followed_m, no amount of signaling from a
 * locked-out slot -- suppressed voice starts, ESS repeats, clear-claiming grant
 * updates -- can restart or cancel the countdown.
 *
 * @param ctx State machine context (may be NULL).
 * @return Monotonic start of the countdown, or 0.0 when the carrier is not in
 *         hangtime.
 */
double p25_sm_hangtime_started_m(const p25_sm_ctx_t* ctx);

/** Resolve the configured hangtime with the current Phase 1 error-hold extension. */
double p25_sm_effective_hangtime(const dsd_state* state, double hangtime);

/**
 * @brief Trigger explicit release and return to CC.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param reason Log tag for release reason.
 */
void p25_sm_release(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, const char* reason);

/**
 * @brief End the tuned call and come to rest on the control channel WITHOUT tuning.
 *
 * p25_sm_release() minus the return-to-CC tune, for a caller that owns the tuner and is
 * already moving it somewhere else: the trunk-scan coordinator evicting a target that reached
 * its per-visit limit (issue #507). Tuning here would fight that move, so this never asks the
 * tuner for anything -- it ends both call slots, clears the voice-channel context and decoder
 * mirrors, drops trunk_is_tuned and settles in P25_SM_ON_CC. Session state an ordinary release
 * keeps is kept: the counters and the encryption-reprobe memo survive.
 *
 * @param ctx State machine context (NULL uses the global singleton).
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param reason Log tag for the release reason.
 */
void p25_sm_abandon_carrier(p25_sm_ctx_t* ctx, dsd_opts* opts, dsd_state* state, const char* reason);

/**
 * @brief Record exact P25P2 frame sync while acquiring a tuned voice channel.
 *
 * This confirms demodulator acquisition and cancels no-sync recovery without
 * extending voice activity or trunk hangtime. Decoded MAC/voice events remain
 * authoritative for call activity.
 */
void p25_sm_note_vc_frame_sync(p25_sm_ctx_t* ctx, dsd_opts* opts, const dsd_state* state);

/**
 * @brief Record a completed frame-sync search while acquiring a returned control channel.
 *
 * The first completed no-sync search is progress evidence that permits one
 * CQPSK demodulator recovery attempt. Hunt probes, pending hardware tunes,
 * and already-decoded control channels are ignored.
 */
void p25_sm_note_cc_no_sync_pass(p25_sm_ctx_t* ctx, dsd_opts* opts, const dsd_state* state);

/**
 * @brief Record a completed frame-sync search with no sync on a tuned voice channel.
 *
 * Repeated no-sync passes may queue one bounded CQPSK demodulator recovery when
 * the tuned grant is still awaiting voice. Non-RTL, non-TDMA, active, and data
 * calls are ignored.
 */
void p25_sm_note_vc_no_sync_pass(p25_sm_ctx_t* ctx, dsd_opts* opts, const dsd_state* state);

/**
 * @brief Check whether a one-shot VC CQPSK recovery is holding a CC return.
 *
 * Generic no-carrier fallback uses this to avoid bypassing a recovery queued
 * by the P25 frame-sync release path in the same no-sync cycle. The hold is
 * bounded independently and never extends the original grant timeout.
 *
 * @param ctx State machine context.
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param now_m Current monotonic timestamp.
 * @return 1 while the matching VC recovery hold is active, 0 otherwise.
 */
int p25_sm_vc_reacquire_hold_active(const p25_sm_ctx_t* ctx, const dsd_opts* opts, const dsd_state* state,
                                    double now_m);

/**
 * @brief Check whether a TDMA slot has an accepted grant newer than a captured event time.
 *
 * Decoders use this after processing a MAC payload but before clearing IDLE
 * slot metadata, so grants carried inside the IDLE payload can keep their
 * policy and service context. A sequence rather than a timestamp: the grants a
 * payload carries are stamped at the clock reading the IDLE was observed at
 * whenever the clock does not move while the payload is dispatched (an I/Q
 * replay's window, a coarse clock).
 *
 * @param slot Slot index (0 or 1).
 * @param grant_seq p25_sm_slot_grant_seq() captured before payload processing.
 * @return 1 if the global state machine accepted an active grant for the slot since then, 0 otherwise.
 */
int p25_sm_slot_grant_since(int slot, uint32_t grant_seq);

/**
 * @brief The slot's grant sequence in the global state machine, for p25_sm_slot_grant_since()
 * and p25_sm_emit_idle_at().
 */
uint32_t p25_sm_slot_grant_seq(int slot);

/**
 * @brief The checked identity of a slot's ACTIVE canonical call a report of @p report_protocol may borrow (issue #800,
 * spec 2.19).
 *
 * The identity counts only while the slot's canonical call is ACTIVE, is the epoch the state machine last published
 * an identity for, still has that identity's source, target and kind, all three came from checked content (a field
 * inherited from an earlier assignment keeps that assignment's verdict, and only under the reception it was accepted
 * under), and it names a source; and only by the attribution rule (dsd_position_attribution_grant()): the call is of
 * the report's protocol class (a Phase 1 call never names a Phase 2 report's sender) and the reception has not changed
 * since the flags were earned.
 *
 * @param state Decoder state (canonical call state).
 * @param slot Slot index (0 or 1).
 * @param report_protocol DSD_SYNC_* of the report that borrows the identity.
 * @param[out] out The published identity; zeroed when none counts.
 * @return 1 when the call's source, target and kind are checked provenance, 0 otherwise.
 */
int p25_sm_checked_call_identity(const dsd_state* state, int slot, int report_protocol, p25_sm_published_identity* out);

/**
 * @brief Whether the state machine's record of the slot's call at @p epoch has withdrawn the talker @p source (issue
 * #800, fail closed): it names another source, or names @p source without its checked flag as it counts now (a special
 * address or a non-local source in a later message's source field, a repeated grant naming another talker, a
 * reception change). Evidence another record keeps of that talker (the Phase 1 voice-user LC record,
 * p25_p1_lc_attribution) no longer names a report's sender then. 0 when the record holds no identity of that call.
 */
int p25_sm_call_source_withdrawn(const dsd_state* state, int slot, uint64_t epoch, uint32_t source);

/**
 * @brief Record an identity a decoded message named for a slot's canonical call (issue #800, spec 2.19).
 *
 * For a message that observes the canonical call itself (a Phase 2 MAC_SIGNAL voice user), after that observation.
 * Each field it names with the value the ACTIVE call now holds takes @p checked when the call is a new epoch or the
 * value changed, and gains it otherwise; a field it leaves 0 keeps what it had. The slot's assignment takes it too: a
 * message naming the assignment's kind and target applies its fields there with @p checked, so a later source-less
 * voice start inherits this talker; one naming another kind or target drops the assignment's source.
 *
 * @param state Decoder state (canonical call state).
 * @param slot Slot index (0 or 1).
 * @param source Source RID the message named; 0 when none.
 * @param target Talkgroup (group) or destination RID (private) the message named; 0 when none.
 * @param is_group 1 for a group call, 0 for a private call.
 * @param checked P25_SM_IDENTITY_CHECKED_* bits: the message's own check (0 when it failed).
 * @param source_nonlocal 1 when the message names its talker by no local working address (an extended voice user with
 *        Source Address 0 and a home SUID, p25_sm_event_t::source_nonlocal): the source the call keeps loses its flag.
 */
void p25_sm_note_call_identity(dsd_state* state, int slot, uint32_t source, uint32_t target, int is_group,
                               uint8_t checked, uint8_t source_nonlocal);

/**
 * @brief Check whether a voice-user observation re-describes a call that just ended.
 *
 * After an accepted MAC_END_PTT the FNE keeps describing the completed call
 * for a few bursts: END repeats interleave with SACCH voice-user copies whose
 * assembly began before the END decoded. A voice user naming the completed
 * talker (or naming no talker) on the unchanged target inside that short tail
 * is retention of the ended transmission and must not begin a canonical
 * epoch. A changed source, or the same identity outside the tail, is fresh
 * evidence and returns 0.
 *
 * @param slot Slot index (0 or 1).
 * @param target OTA talkgroup for group calls, destination RID for private calls.
 * @param src Source RID, or 0/unknown when the observation carries none.
 * @param now_m Monotonic timestamp of the observation.
 * @return 1 when the observation repeats the recently ended call, 0 otherwise.
 */
int p25_sm_voice_user_repeats_recent_end(int slot, int target, int src, double now_m);

/**
 * @brief Whether a Phase 1 ESS observation may open a canonical epoch.
 *
 * Mirrors the voice-start rule: a trunked receiver with no traffic assignment
 * is parked on or hunting the control channel, where Phase 1 ESS can only be
 * noise briefly false-syncing as an LDU. Conventional receivers (trunking
 * disabled) always qualify.
 *
 * @param opts Decoder options (trunking configuration).
 * @return 1 when an ESS-driven epoch may open, 0 to decline the mint.
 */
int p25_sm_phase1_crypto_epoch_allowed(const dsd_opts* opts);

/**
 * @brief Fetch the tuned Phase 1 assignment identity for a pre-identity epoch.
 *
 * When ESS crypto resolves on a tuned FDMA traffic channel before any
 * LCW/voice evidence names the call, the epoch opened to hold the
 * classification should carry the assignment identity the grant already
 * established rather than begin identity-less. Only a tuned, non-TDMA,
 * non-data assignment with a known target qualifies; the conventional
 * identity-pending flow keeps its identity-less epoch (the following LCW
 * names that call).
 *
 * @param[out] is_group 1 for a group assignment, 0 for a private one.
 * @param[out] ota_target OTA talkgroup or destination RID of the assignment.
 * @param[out] policy_target Patch-aware policy target, or 0 when unknown.
 * @return 1 when a tuned Phase 1 assignment identity was filled, 0 otherwise.
 */
int p25_sm_phase1_assignment_identity(int* is_group, uint32_t* ota_target, uint32_t* policy_target);

/* ============================================================================
 * Public API - Convenience Emit Functions (use global singleton)
 * ============================================================================ */

/**
 * @brief Emit PTT event for a slot.
 *
 * Trunk-follow mode rejects the event unless the state machine owns an active
 * traffic-channel assignment. Conventional decoding does not require one.
 * @return 1 when downstream media handling may proceed; 0 when the event was rejected.
 */
int p25_sm_emit_ptt(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit a PTT event carrying an authoritative in-band call identity.
 *
 * The state machine reopens the call epoch from the retained carrier
 * assignment, re-evaluates policy/crypto, and never invokes the tuner for an
 * accepted identity on the current carrier. Trunk-follow mode rejects the
 * event when no traffic-channel assignment is active. The identity is
 * unchecked provenance; see p25_sm_emit_voice_start().
 * @return 1 when downstream media handling may proceed; 0 when the event was rejected.
 */
int p25_sm_emit_ptt_call(dsd_opts* opts, dsd_state* state, int slot, int tg, int dst, int src, int is_group,
                         int svc_bits);

/**
 * @brief Emit ACTIVE event for a slot.
 *
 * Trunk-follow mode rejects the event unless the state machine owns an active
 * traffic-channel assignment. Conventional decoding does not require one.
 * @return 1 when downstream media handling may proceed; 0 when the event was rejected.
 */
int p25_sm_emit_active(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit a voice start the caller built: a P25_SM_EV_PTT or P25_SM_EV_ACTIVE event, with or without an in-band
 *        identity, whose p25_sm_event_t.identity_checked the caller set from the check it ran on the message.
 *
 * Decoders use this form. The convenience emitters below publish their identity as unchecked (spec 2.19).
 * @return 1 when downstream media handling may proceed; 0 when the event was rejected.
 */
int p25_sm_emit_voice_start(dsd_opts* opts, dsd_state* state, const p25_sm_event_t* ev);

/**
 * @brief Emit an ACTIVE event carrying an authoritative in-band call identity.
 *
 * Trunk-follow mode rejects the event when no traffic-channel assignment is active. The identity is unchecked
 * provenance; see p25_sm_emit_voice_start().
 * @return 1 when downstream media handling may proceed; 0 when the event was rejected.
 */
int p25_sm_emit_active_call(dsd_opts* opts, dsd_state* state, int slot, int tg, int dst, int src, int is_group,
                            int svc_bits);

/**
 * @brief Note, with trunking off, the voice channel frequency a grant update named for @p target (issue #575).
 *
 * Each slot whose active call has that target keeps the frequency with the target for itself; a slot whose call has
 * another target, or none, keeps what it had. The conventional publication gives a call this frequency only when the
 * call has that target (p25_conventional_grant_frequency()).
 */
void p25_conventional_grant_note(dsd_state* state, uint32_t target, long int freq);

/**
 * @brief The voice channel frequency a grant update named, with trunking off, for @p target on @p slot, or 0 when none
 *        did: another call's grant is never this call's frequency (issue #575).
 */
int64_t p25_conventional_grant_frequency(const dsd_state* state, int slot, uint32_t target);

/**
 * @brief Emit an ACTIVE call whose message type carries no source field.
 *
 * See p25_sm_ev_active_call_source_absent(): the voice start must not inherit
 * the preceding assignment's talker for these calls. The identity is
 * unchecked provenance; see p25_sm_emit_voice_start().
 */
int p25_sm_emit_active_call_source_absent(dsd_opts* opts, dsd_state* state, int slot, int tg, int dst, int is_group,
                                          int svc_bits);

/**
 * @brief Emit END event for a slot.
 */
void p25_sm_emit_end(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit an identified END event observed at a specific time.
 *
 * Phase 2 XCCH decoders use this form so an END for an older call cannot
 * clear a newer same-slot assignment or media state. A redundant repeated
 * END is also rejected after the first one has been applied.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param slot Slot index (0 or 1).
 * @param tg Talkgroup carried by MAC_END_PTT, or 0 when unavailable.
 * @param src Source RID carried by MAC_END_PTT, or 0 when unavailable.
 * @param observed_m Monotonic timestamp captured when the END PDU was observed.
 * @return 1 when slot teardown should be applied, 0 when the END is stale or redundant.
 */
int p25_sm_emit_end_call_at(dsd_opts* opts, dsd_state* state, int slot, int tg, int src, double observed_m);

enum {
    P25_SM_END_IGNORED = 0,
    P25_SM_END_APPLIED = 1,
    P25_SM_END_CHANNEL_RELEASED = 2,
};

/**
 * @brief Emit an identified FACCH END event.
 *
 * Two matching FACCH END messages within one second, without intervening
 * PTT/ACTIVE activity, are an authoritative teardown hint once both slots are
 * inactive. SACCH callers must continue using p25_sm_emit_end_call_at().
 */
int p25_sm_emit_facch_end_call_at(dsd_opts* opts, dsd_state* state, int slot, int tg, int src, double observed_m);

/**
 * @brief Emit IDLE event for a slot.
 */
void p25_sm_emit_idle(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit IDLE event with a previously captured monotonic observation timestamp and the slot's
 * p25_sm_slot_grant_seq() at that observation. A grant accepted since then is newer than the IDLE.
 */
void p25_sm_emit_idle_at(dsd_opts* opts, dsd_state* state, int slot, double observed_m, uint32_t grant_seq);

/** @brief Emit a MAC_HANGTIME boundary for a slot. */
void p25_sm_emit_hangtime(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit TDU (P1 terminator) event.
 */
void p25_sm_emit_tdu(dsd_opts* opts, dsd_state* state);

/**
 * @brief Emit ENC event for a slot (encryption params detected).
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param slot Slot index (0 or 1).
 * @param algid Algorithm ID.
 * @param keyid Key ID.
 * @param tg Talkgroup associated with this call.
 */
void p25_sm_emit_enc(dsd_opts* opts, dsd_state* state, int slot, int algid, int keyid, int tg);

/**
 * @brief Note a FEC-accepted ESS repeat of an already-suppressed BLOCKED classification.
 *
 * The full ENC event is edge-triggered on the classification transition; this
 * lightweight note is the per-repeat liveness signal that the locked-out
 * transmission still occupies its slot. It refreshes the suppression stamp the
 * release heuristics read and keeps the slot's audio gate closed — it runs no
 * teardown and no stay-or-release decision. A slot whose lockout action never
 * ran (no suppression stamp) is left untouched so a stray repeat cannot invent
 * liveness for an idle slot.
 */
void p25_sm_note_enc_suppressed(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Emit an in-band encrypted indication that requires classification.
 *
 * A new transition closes the slot's media gate, clears stale voice activity,
 * and starts a fresh classification deadline. Repeated pending indications do
 * not extend an existing deadline.
 */
void p25_sm_emit_crypto_pending(dsd_opts* opts, dsd_state* state, int slot);

/** Refresh an armed skip for a rejected TDMA slot with a retained group identity.
 * Decoder thread only; a clear latch, invalid slot or absent identity is a no-op. */
void p25_sm_touch_rejected_slot_skip(dsd_opts* opts, dsd_state* state, int slot);
/** Clear retained rejection attribution beside the Phase 2 media-latch reset. */
void p25_sm_clear_rejected_slot(const dsd_state* state, int slot);

/** Emit a pending indication that explicitly starts a new classification deadline. */
void p25_sm_emit_crypto_pending_epoch(dsd_opts* opts, dsd_state* state, int slot);

/**
 * @brief Apply group grant policy side effects without attempting route/tune.
 *
 * Use when a decoder has a valid group grant but cannot yet resolve or follow
 * its channel. This preserves encrypted lockout/cache and clear-key regroup
 * policy behavior until a tunable grant arrives.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param channel Voice channel number.
 * @param svc_bits Service options associated with the grant, or P25_SM_SVC_UNKNOWN when absent.
 * @param tg Talkgroup.
 * @param src Source RID.
 */
void p25_sm_apply_group_grant_policy(dsd_opts* opts, dsd_state* state, int channel, int svc_bits, int tg, int src);

/** What an assignment for an announced call would decide, for ranking calls announced together. */
typedef struct {
    int tune_allowed; /**< the policy admits it */
    int hold_match;   /**< it is the held talkgroup */
    int priority;     /**< 0..100 from its row */
    int preempt;      /**< its row asks to preempt */
} p25_sm_grant_rank_t;

/**
 * @brief The policy decision an assignment for @p ev would reach, without writing anything.
 *
 * Patch-aware and lockout-release-aware like the grant path, but no ledger release, backoff, call-skip touch or log.
 * Decoders rank several calls announced together with it (hold match, then priority) before dispatching them.
 *
 * @return 1 when @p out was evaluated, 0 otherwise.
 */
int p25_sm_grant_candidate_rank(const dsd_opts* opts, dsd_state* state, const p25_sm_event_t* ev,
                                p25_sm_grant_rank_t* out);

/**
 * @brief Whether an announced group call would be tuned only as a silent probe under encrypted-call lockout.
 *
 * With encrypted calls not tuned (trunk_tune_enc_calls == 0), a call whose service options say encrypted, or that
 * carries none, is admissible only as a probe that may turn out encrypted and silent -- unless its talkgroup belongs
 * to a patch with a clear key. Decoders rank audible calls before probes when several are announced together, so a
 * probe cannot take the receiver from a clear call listed beside it.
 *
 * @param opts Decoder options.
 * @param state Decoder state (patch keys).
 * @param tg Announced talkgroup.
 * @param svc_bits Its service options, or P25_SM_SVC_UNKNOWN when absent.
 * @return 1 for a silent probe, 0 otherwise.
 */
int p25_sm_grant_is_silent_probe(const dsd_opts* opts, const dsd_state* state, int tg, int svc_bits);

/* ============================================================================
 * Helper: SACCH slot mapping
 * ============================================================================ */

/**
 * @brief Convert SACCH currentslot to voice channel slot.
 *
 * P25 Phase 2 SACCH uses inverted slot mapping relative to voice frames.
 * Use this helper at SM event emission points for consistency.
 *
 * @param currentslot The currentslot value from state.
 * @return Voice channel slot index (0 or 1).
 */
static inline int
p25_sacch_to_voice_slot(int currentslot) {
    return (currentslot ^ 1) & 1;
}

/* ============================================================================
 * Helper: Create events from common scenarios
 * ============================================================================ */

static inline p25_sm_event_t
p25_sm_ev_group_grant(int channel, long freq_hz, int tg, int src, int svc_bits) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_GRANT;
    ev.slot = -1;
    ev.channel = channel;
    ev.freq_hz = freq_hz;
    ev.tg = tg;
    ev.src = src;
    ev.svc_bits = svc_bits;
    ev.is_group = 1;
    ev.grant_provenance = P25_SM_GRANT_PROVENANCE_ASSIGNMENT;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_group_grant_update(int channel, long freq_hz, int tg, int src, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_group_grant(channel, freq_hz, tg, src, svc_bits);
    ev.grant_provenance = P25_SM_GRANT_PROVENANCE_UPDATE;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_indiv_grant(int channel, long freq_hz, int dst, int src, int svc_bits) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_GRANT;
    ev.slot = -1;
    ev.channel = channel;
    ev.freq_hz = freq_hz;
    ev.dst = dst;
    ev.src = src;
    ev.svc_bits = svc_bits;
    ev.is_group = 0;
    ev.grant_provenance = P25_SM_GRANT_PROVENANCE_ASSIGNMENT;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_indiv_grant_update(int channel, long freq_hz, int dst, int src, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_indiv_grant(channel, freq_hz, dst, src, svc_bits);
    ev.grant_provenance = P25_SM_GRANT_PROVENANCE_UPDATE;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_group_data_grant(int channel, long freq_hz, int tg, int src, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_group_grant(channel, freq_hz, tg, src, svc_bits);
    ev.data_call_override = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_indiv_data_grant(int channel, long freq_hz, int dst, int src, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_indiv_grant(channel, freq_hz, dst, src, svc_bits);
    ev.data_call_override = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_ptt(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_PTT;
    ev.slot = slot;
    ev.svc_bits = P25_SM_SVC_UNKNOWN;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_ptt_call(int slot, int tg, int dst, int src, int is_group, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_ptt(slot);
    ev.tg = tg;
    ev.dst = dst;
    ev.src = src;
    ev.is_group = is_group ? 1 : 0;
    ev.svc_bits = svc_bits;
    ev.identity_valid = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_active(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_ACTIVE;
    ev.slot = slot;
    ev.svc_bits = P25_SM_SVC_UNKNOWN;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_active_call(int slot, int tg, int dst, int src, int is_group, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_active(slot);
    ev.tg = tg;
    ev.dst = dst;
    ev.src = src;
    ev.is_group = is_group ? 1 : 0;
    ev.svc_bits = svc_bits;
    ev.identity_valid = 1;
    return ev;
}

/**
 * @brief ACTIVE call event whose message type carries no source field at all.
 *
 * Telephone Interconnect Voice Channel User is the case in practice: the
 * landline leg has no subscriber source, so src 0 means "none exists" rather
 * than "not decoded". Without that distinction the voice start would inherit
 * the talker from the preceding assignment and attribute a landline call to
 * whichever radio last held the channel.
 */
static inline p25_sm_event_t
p25_sm_ev_active_call_source_absent(int slot, int tg, int dst, int is_group, int svc_bits) {
    p25_sm_event_t ev = p25_sm_ev_active_call(slot, tg, dst, 0, is_group, svc_bits);
    ev.source_absent = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_end(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_END;
    ev.slot = slot;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_end_call_at(int slot, int tg, int src, double observed_m) {
    p25_sm_event_t ev = p25_sm_ev_end(slot);
    ev.tg = tg;
    ev.src = src;
    ev.observed_m = observed_m;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_facch_end_call_at(int slot, int tg, int src, double observed_m) {
    p25_sm_event_t ev = p25_sm_ev_end_call_at(slot, tg, src, observed_m);
    ev.facch = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_idle(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_IDLE;
    ev.slot = slot;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_idle_at(int slot, double observed_m) {
    p25_sm_event_t ev = p25_sm_ev_idle(slot);
    ev.observed_m = observed_m;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_idle_observed(int slot, double observed_m, uint32_t grant_seq) {
    p25_sm_event_t ev = p25_sm_ev_idle_at(slot, observed_m);
    ev.grant_seq = grant_seq;
    ev.grant_seq_valid = 1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_hangtime(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_HANGTIME;
    ev.slot = slot;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_tdu(void) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_TDU;
    ev.slot = -1;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_enc(int slot, int algid, int keyid, int tg) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_ENC;
    ev.slot = slot;
    ev.algid = algid;
    ev.keyid = keyid;
    ev.tg = tg;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_crypto_pending(int slot) {
    p25_sm_event_t ev = {0};
    ev.type = P25_SM_EV_CRYPTO_PENDING;
    ev.slot = slot;
    return ev;
}

static inline p25_sm_event_t
p25_sm_ev_crypto_pending_epoch(int slot) {
    p25_sm_event_t ev = p25_sm_ev_crypto_pending(slot);
    ev.crypto_new_epoch = 1;
    return ev;
}

/* ============================================================================
 * Patch group (P25 regroup/patch) tracking helpers
 * ============================================================================ */

/**
 * @brief Record or update a P25 regroup/patch state for a Super Group ID (SGID).
 *
 * A message that only names the SG (grants, grant updates, voice users): it refreshes the
 * row's seen stamp and recency, never the members stamp, and first expires members that
 * are no longer current. A new SG takes at most a memberless row of a full table, never a
 * live patch's slot: it writes nothing when every entry is live. See <dsd-neo/core/p25_patch.h>.
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param is_patch 1 for two-way patch, 0 for simulselect (one-way regroup).
 * @param active 1 to activate, 0 to deactivate/clear.
 */
void p25_patch_update(dsd_state* state, int sgid, int is_patch, int active);

/**
 * @brief Add a Working Group ID to an SGID entry (creates/activates if needed).
 *
 * A membership message: every accepted Add (a duplicate included) reactivates the entry and
 * refreshes its seen and members stamps. The SG listed as its own member is ignored; a member
 * past DSD_P25_PATCH_GROUP_MAX is dropped, noted on the handler's stderr line (no newline).
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param wgid Working Group ID to add.
 */
void p25_patch_add_wgid(dsd_state* state, int sgid, int wgid);

/**
 * @brief Add a Working Unit ID to an SGID entry (creates/activates if needed).
 *
 * Refreshes like p25_patch_add_wgid(); a radio past DSD_P25_PATCH_RADIO_MAX is dropped, noted
 * on the handler's stderr line (no newline).
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param wuid Working Unit ID to add.
 */
void p25_patch_add_wuid(dsd_state* state, int sgid, uint32_t wuid);

/**
 * @brief Compose a detailed status string including WGID/WUID context.
 *
 * Example: "SG069[P] WG:2(0345,0789); SG142[S] U:3".
 * Lists active entries whose SG was named within the TTL on the listening clock; member and
 * KEY/ALG/SSN fields only while the members are current. Never mutates the state.
 *
 * @param state Decoder state (read-only).
 * @param out Destination buffer.
 * @param cap Capacity of destination buffer.
 * @return Length written.
 */
int p25_patch_compose_details(const dsd_state* state, char* out, size_t cap);

/**
 * @brief Remove a WGID membership or clear the entire SG record.
 *
 * A Delete that lists the SG itself ends the whole patch (p25_patch_clear_sg()). Members that
 * are no longer current expire first; removing the last member deactivates the entry and
 * expires its KEY/ALG/SSN context. Not a refresh: neither stamp moves.
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param wgid Working Group ID to remove.
 */
void p25_patch_remove_wgid(dsd_state* state, int sgid, int wgid);
/**
 * @brief Clear all membership and status for an SG record.
 *
 * A Cancel: the entry turns inactive and its members and KEY/ALG/SSN context expire.
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID to clear.
 */
void p25_patch_clear_sg(dsd_state* state, int sgid);

/**
 * @brief Prepare an MFID GRG update, clearing inactive or version-replaced state.
 *
 * Inactive GRG commands remove the supergroup record. Active commands with a
 * changed SSN clear stale membership before the caller adds the new members.
 * SG-only: an active command refreshes the row (seen stamp and recency) like
 * p25_patch_update(); the members stamp refreshes only through the following
 * p25_patch_add_wgid()/p25_patch_add_wuid() or p25_patch_set_kas().
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param is_patch 1 for two-way patch, 0 for simulselect.
 * @param active 1 to activate/update, 0 to deactivate/clear.
 * @param ssn SSN from GRG options, or -1 when absent.
 * @return 1 if members should be processed, 0 when the command cleared state.
 */
int p25_patch_prepare_grg_update(dsd_state* state, int sgid, int is_patch, int active, int ssn);

/**
 * @brief Set optional Key/Alg/SSN context for an SG.
 *
 * Values of -1 leave the existing field unchanged. A membership message: it refreshes the
 * entry's seen and members stamps.
 *
 * @param state Decoder state holding patch context.
 * @param sgid Super Group ID.
 * @param key Key ID (or -1 to leave unchanged).
 * @param alg Algorithm ID (or -1 to leave unchanged).
 * @param ssn SSN ID (or -1 to leave unchanged).
 */
void p25_patch_set_kas(dsd_state* state, int sgid, int key, int alg, int ssn);

/**
 * @brief Return 1 if TG is a WGID within an active SG that is explicitly clear.
 *
 * Only an SG named within the TTL whose members are current counts.
 *
 * Used to override ENC lockout when GRG commands indicate a clear operation
 * for a patch/regroup.
 *
 * @param state Decoder state (read-only).
 * @param tg Talkgroup to test.
 * @return 1 if the TG maps to a clear SG, 0 otherwise.
 */
int p25_patch_tg_key_is_clear(const dsd_state* state, int tg);
/**
 * @brief Return 1 if an SGID has explicit KEY=0 (clear) policy and is active.
 *
 * Only an SG named within the TTL whose members (and so KEY context) are current counts.
 *
 * @param state Decoder state (read-only).
 * @param sgid Super Group ID to query.
 * @return 1 if active and explicitly clear; 0 otherwise.
 */
int p25_patch_sg_key_is_clear(const dsd_state* state, int sgid);

/* ============================================================================
 * Affiliation (RID) tracking
 * ============================================================================ */

/**
 * @brief Record a RID as affiliated/registered (updates last_seen or adds new entry).
 *
 * @param state Decoder state holding affiliation table.
 * @param rid Radio ID to register.
 */
void p25_aff_register(dsd_state* state, uint32_t rid);

/**
 * @brief Remove a RID from the affiliation table (explicit deregistration or aging).
 *
 * @param state Decoder state holding affiliation table.
 * @param rid Radio ID to remove.
 */
void p25_aff_deregister(dsd_state* state, uint32_t rid);

/**
 * @brief Periodic aging/cleanup of the affiliation table (call at ~1 Hz).
 *
 * @param state Decoder state holding affiliation table.
 */
void p25_aff_tick(dsd_state* state);

/** A unit's home identity (SUID): WACN, System ID and unit ID. valid 0 means unknown. */
typedef struct {
    uint32_t wacn;
    uint16_t sys;
    uint32_t id;
    uint8_t valid;
} p25_home_id;

/**
 * @brief Record an accepted Unit Registration: local address @p assigned, given to @p home on the serving system.
 *
 * The entry for @p assigned is added or refreshed as p25_aff_register() does. When @p home is valid (non-zero ID) and
 * the serving system is known (WACN or System ID non-zero), the entry also keeps who it was assigned to: a new owner
 * replaces the previous one (an address is reassigned), and another entry this home held on the same serving system
 * goes (a unit holds one registration per system). Otherwise the entry keeps no owner.
 *
 * @param state Decoder state holding the affiliation table.
 * @param assigned Local address (WUID) the registration assigned.
 * @param home Home identity the response named; NULL or invalid keeps no owner.
 * @param serving_wacn WACN of the system the response was heard on.
 * @param serving_sys System ID of the system the response was heard on.
 */
void p25_aff_register_assigned(dsd_state* state, uint32_t assigned, const p25_home_id* home, uint32_t serving_wacn,
                               uint16_t serving_sys);

/**
 * @brief Remove the registration a Unit Deregistration Acknowledge names by its home identity.
 *
 * Removes every entry still owned by @p home on this serving system. An entry with no owner goes only when its
 * address is the home unit ID and the home system is the serving system (a unit at home is addressed by its own ID)
 * or no serving system is known; an address now owned by another home stays.
 *
 * @return Number of entries removed.
 */
int p25_aff_deregister_home(dsd_state* state, const p25_home_id* home, uint32_t serving_wacn, uint16_t serving_sys);

/**
 * @brief The local address @p home holds on the serving system.
 *
 * @param assigned Receives the address when found (may be NULL).
 * @return 1 when an entry owned by @p home on this serving system exists, else 0.
 */
int p25_aff_assigned_for_home(const dsd_state* state, const p25_home_id* home, uint32_t serving_wacn,
                              uint16_t serving_sys, uint32_t* assigned);

/**
 * @brief Drop the owners another serving system named (the system identity, p2_wacn / p2_sysid, just changed).
 *
 * A local address (WUID) is assigned at registration and unique only within its system (TIA-102.AABC-D §2.3.27), so
 * an owner learned on another system no longer holds it here. The registered addresses stay.
 */
void p25_aff_drop_foreign_owners(dsd_state* state);

/* ============================================================================
 * Group Affiliation (RID ↔ TG) helpers
 * ============================================================================ */

/**
 * @brief Add a group affiliation (RID to TG).
 *
 * @param state Decoder state holding group affiliation table.
 * @param rid Radio ID.
 * @param tg Talkgroup to associate.
 */
void p25_ga_add(dsd_state* state, uint32_t rid, uint16_t tg);
/**
 * @brief Age/cleanup group affiliation entries (call at ~1 Hz).
 *
 * @param state Decoder state holding group affiliation table.
 */
void p25_ga_tick(dsd_state* state);

/**
 * @brief Emit a single encryption lockout event for a group or private target.
 *
 * Arms the session-permanent encrypted-target ledger (core/enc_lockout.h) and
 * pushes the corresponding event to history/log.
 *
 * @param opts Decoder options.
 * @param state Decoder state.
 * @param slot 0 for FDMA/left, 1 for TDMA/right.
 * @param target Group or private target.
 * @param svc_bits Optional service bits (pass 0 if unknown).
 * @param is_group Nonzero for a group target, zero for a private target.
 * @param algid Confirmed ALGID, or DSD_ENC_LOCKOUT_ALGID_UNKNOWN.
 * @param keyid Confirmed key id (0 when unknown).
 */
void p25_emit_enc_lockout_once_typed(dsd_opts* opts, dsd_state* state, uint8_t slot, int target, int svc_bits,
                                     int is_group, int algid, int keyid);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_TRUNK_SM_H_H */

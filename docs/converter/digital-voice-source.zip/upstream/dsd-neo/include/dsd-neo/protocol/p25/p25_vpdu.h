// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief P25 MAC VPDU handler interfaces.
 *
 * Declares VPDU processing entrypoints implemented in the P25 protocol code.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief P25 Phase 2 MAC PDU type carried by an XCCH block.
 *
 * This is the outer PDU type and is a different namespace from the inner MAC
 * message opcode: PDU type 3 is IDLE, while MAC opcode 3 is Telephone
 * Interconnect Voice Channel User.
 *
 * PTT and END_PTT are listed for completeness against the standard but never
 * reach process_MAC_VPDU(): those PDUs carry no MAC message opcode, so
 * p25p2_xcch_handle_{sacch,facch}_mac_ptt/_mac_end raise the corresponding
 * state-machine events directly. Treat them as unreachable there rather than
 * as a case the voice-provenance gate has to rule on.
 */
typedef enum {
    P25_MAC_PDU_SIGNAL = 0,
    P25_MAC_PDU_PTT = 1,
    P25_MAC_PDU_END_PTT = 2,
    P25_MAC_PDU_IDLE = 3,
    P25_MAC_PDU_ACTIVE = 4,
    P25_MAC_PDU_HANGTIME = 6,
} p25_mac_pdu_type;

/**
 * @brief Process a native Phase 2 MAC PDU: mac[0] is its MAC header, its messages start at mac[1] and are segmented
 * with the Phase 2 message lengths.
 *
 * No octet marks the transport: a mac[0] of 0x07 is a MAC header like any other. A Phase 1 TSBK goes through
 * process_MAC_VPDU_bridged_p1() instead.
 *
 * @param type SACCH (1) or FACCH (0) transport.
 * @param pdu_type Outer Phase 2 MAC PDU type.
 */
void process_MAC_VPDU(dsd_opts* opts, dsd_state* state, int type, p25_mac_pdu_type pdu_type,
                      unsigned long long int mac[24]);

/**
 * @brief process_MAC_VPDU() with the PDU's CRC verdict.
 *
 * @param crc_ok 0 for a MAC_SIGNAL that failed its CRC and reaches here only
 *               because -F relaxes the check (p25p2_xcch_validate_sacch_crc()).
 *               Nothing that proves the carrier's identity -- a network status
 *               broadcast's NAC, which marks the Phase 2 seed proven
 *               (p2_cc_verified) -- is taken from such a PDU (issue #575).
 *               process_MAC_VPDU() passes 1.
 */
void process_MAC_VPDU_crc(dsd_opts* opts, dsd_state* state, int type, p25_mac_pdu_type pdu_type,
                          unsigned long long int mac[24], int crc_ok);

/**
 * @brief Decode one CRC-valid Phase 1 TSBK through the MAC message handlers.
 *
 * @p mac holds the TSBK in the MAC form p25p1_tsbk.c builds: 0x07 at mac[0], the TSBK opcode as its abbreviated
 * Phase 2 opcode (0x40 | opcode) at mac[1], and TSBK octets 2-9 at mac[2..9] (the MFID and the CRC are not
 * carried). That is one 9-octet message: it is never split into several MAC messages, never joins a multi-fragment
 * assembly, and nothing past mac[9] is read. Handlers whose Phase 2 layout differs read the Phase 1 one
 * (TIA-102.AABC-D), or print the octets raw where Phase 1 has no single-block layout.
 */
void process_MAC_VPDU_bridged_p1(dsd_opts* opts, dsd_state* state, unsigned long long int mac[24]);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_P25_P25_VPDU_H_ */

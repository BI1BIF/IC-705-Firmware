// SPDX-License-Identifier: GPL-3.0-or-later
/**
 * @file
 * @brief CSBK parsing helpers shared across DMR control code.
 */
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/*
 * DMR CSBK parsing and dispatch helpers.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_DMR_DMR_CSBK_PARSE_H_
#define DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_DMR_DMR_CSBK_PARSE_H_

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>
#include <dsd-neo/core/talkgroup_policy.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct dmr_csbk_result {
    uint8_t lb;
    uint8_t pf;
    uint8_t opcode;
    uint8_t fid;

    /* Channel grant-related fields (when applicable). */
    uint16_t lpcn;
    uint16_t pluschannum;
    uint8_t lcn;
    uint8_t st1;
    uint8_t st2;
    uint8_t st3;
    uint32_t target;
    uint32_t source;

    /* Optional resolved frequency in Hz when known (0 if unknown). */
    long freq_hz;

    /* The grant's classification and talkgroup policy verdict, as the CSBK layer judged it (dmr_csbk_handle() hands
       them to the trunk state machine, which never re-evaluates a grant). */
    int data_call;
    int policy_valid;
    dsd_tg_policy_decision policy;

    const uint8_t* bits;
    const uint8_t* bytes;
};

/**
 * Decode basic CSBK header fields and, for channel-grant opcodes, the
 * common grant fields used by trunking logic.
 *
 * @return 0 on success, negative on error.
 */
int dmr_csbk_parse(const uint8_t* cs_pdu_bits, const uint8_t* cs_pdu, struct dmr_csbk_result* out);

/**
 * Central dispatch helper for CSBK trunking actions.
 *
 * Currently routes channel-grant CSBKs to the DMR Tier III trunking
 * state machine (dmr_sm_submit_grant()) using the parsed fields in @p res,
 * with the call kind and policy verdict the CSBK layer computed.
 */
void dmr_csbk_handle(const struct dmr_csbk_result* res, dsd_opts* opts, dsd_state* state);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_PROTOCOL_DMR_DMR_CSBK_PARSE_H_ */

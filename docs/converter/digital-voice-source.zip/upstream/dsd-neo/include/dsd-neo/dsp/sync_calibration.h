// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Generic sync calibration module for threshold warm-start.
 *
 * Provides protocol-agnostic APIs for:
 * - Symbol history buffer management
 * - Threshold warm-start from outer-only sync patterns
 *
 * This module enables any FSK4 protocol (DMR, P25, YSF, NXDN, dPMR, M17) to
 * immediately calibrate slicer thresholds at sync detection, improving
 * first-frame decode accuracy.
 *
 * The warm-start API leverages the property that many sync patterns use only
 * outer symbols (+3/-3 in 4-level FSK), which allows direct min/max estimation
 * from the sync pattern alone.
 *
 * @see dmr_sync.h for DMR-specific resample-on-sync features
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_DSP_SYNC_CALIBRATION_H_
#define DSD_NEO_INCLUDE_DSD_NEO_DSP_SYNC_CALIBRATION_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declarations */
struct dsd_opts;
struct dsd_state;

/* ─────────────────────────────────────────────────────────────────────────────
 * Constants
 * ───────────────────────────────────────────────────────────────────────────── */

/**
 * @brief Default symbol history buffer size.
 *
 * Stores symbol-rate floats (one per dibit decision), not raw audio samples.
 * At 4800 sym/s, 2048 symbols covers ~427ms which is sufficient for any
 * protocol's sync + pre-sync window.
 */
#define DSD_SYMBOL_HISTORY_SIZE     2048

/**
 * @brief Minimum span between positive and negative symbol means.
 *
 * If the span is smaller than this value, warm-start is skipped as the signal
 * is likely degenerate or the sync pattern was not detected correctly.
 */
#define DSD_WARM_START_MIN_SPAN     1.0f

/**
 * @brief Mid-threshold placement factor between center and outer rails.
 *
 * A pure midpoint between inner/outer rails would be 0.5, but 0.625 has shown
 * better first-frame decode robustness on noisy captures by adding a small bias
 * toward the outer symbols during warm-start.
 */
#define DSD_WARM_START_MID_FRACTION 0.625f

/* ─────────────────────────────────────────────────────────────────────────────
 * Symbol History Management
 *
 * Accessors for the circular buffer owned by the decoder state lifecycle.
 * ───────────────────────────────────────────────────────────────────────────── */

/**
 * @brief Store a symbol in the history buffer.
 *
 * Should be called exactly once per symbol/dibit decision from getSymbol().
 *
 * @param state Decoder state
 * @param symbol Symbol value (typically in range -3 to +3)
 */
void dsd_symbol_history_push(struct dsd_state* state, float symbol);

/**
 * @brief Get a symbol from history at given offset from current position.
 *
 * @param state Decoder state
 * @param back Offset from most recent symbol (0 = newest, 1 = one before, etc.)
 * @return Symbol value at offset, or 0.0f if unavailable
 */
float dsd_symbol_history_get_back(const struct dsd_state* state, int back);

/**
 * @brief Get number of symbols currently in history buffer.
 * @param state Decoder state
 * @return Number of symbols stored (up to buffer size)
 */
int dsd_symbol_history_count(const struct dsd_state* state);

/* ─────────────────────────────────────────────────────────────────────────────
 * Threshold Warm-Start
 *
 * Protocol-agnostic warm-start from outer-only sync patterns.
 * ───────────────────────────────────────────────────────────────────────────── */

/**
 * @brief Result codes for warm-start operations.
 */
typedef enum {
    DSD_WARM_START_OK = 0,         /**< Warm-start applied successfully */
    DSD_WARM_START_DISABLED = 1,   /**< Warm-start disabled by runtime policy */
    DSD_WARM_START_NO_HISTORY = 2, /**< Not enough symbols in history */
    DSD_WARM_START_DEGENERATE = 3, /**< Span too small (degenerate signal) */
    DSD_WARM_START_NULL_STATE = 4, /**< NULL state pointer */
} dsd_warm_start_result_t;

/**
 * @brief Return whether sync warm-start is enabled by runtime policy.
 *
 * `DSD_NEO_SYNC_WARMSTART=0` disables warm-start without selecting a different
 * calibration implementation.
 */
int dsd_sync_warm_start_enabled(void);

/**
 * @brief Warm-start slicer thresholds from outer-only sync pattern.
 *
 * Extracts the last `sync_len` symbols from history, assuming they represent
 * an outer-only sync pattern (only +3 and -3 symbols). Computes mean positive
 * and negative values to estimate actual signal levels, then initializes
 * slicer thresholds:
 *
 *   - state->min = mean of negative symbols
 *   - state->max = mean of positive symbols
 *   - state->center = (min + max) / 2
 *   - state->umid = center + 0.625 * (max - center)
 *   - state->lmid = center + 0.625 * (min - center)
 *   - state->minref = min * 0.80
 *   - state->maxref = max * 0.80
 *
 * Also pre-fills state->minbuf/maxbuf to skip warmup period.
 *
 * This function is protocol-agnostic and works with any outer-only sync (NXDN's and YSF's carry inner symbols and
 * take dsd_sync_warm_start_thresholds_from_dibits()):
 *   - DMR: sync_len = 24
 *   - P25p1: sync_len = 24
 *   - dPMR: sync_len = 12
 *   - M17: sync_len = 8
 *
 * @param opts Decoder options (for msize; may be NULL)
 * @param state Decoder state to update
 * @param sync_len Number of symbols in sync pattern
 * @return Result code indicating success or reason for skip
 */
dsd_warm_start_result_t dsd_sync_warm_start_thresholds_outer_only(const struct dsd_opts* opts, struct dsd_state* state,
                                                                  int sync_len);

/**
 * @brief Warm-start slicer thresholds from a sync word whose levels are known, inner symbols included.
 *
 * NXDN's FSW and YSF's frame sync carry inner symbols (+1/-1) among their outer ones, so their positive and negative
 * symbols do not average to the outer levels: taking them as outer-only put the NXDN rails at 2.6 of 3 and shifted
 * YSF's centre by a quarter of an outer level, which read clean inner symbols as outer. This fits the last
 * @p sync_len symbols in history to the word's levels by least squares (symbol = centre + gain * level), every symbol
 * at its own level, and sets the thresholds from the fitted outer levels (centre -/+ 3 * gain) exactly as
 * dsd_sync_warm_start_thresholds_outer_only() sets them from its means, with the same rolling-buffer prefill. On a
 * word of outer symbols alone the fit is the two means.
 *
 * @param opts        Decoder options (for msize; may be NULL)
 * @param state       Decoder state to update
 * @param sync_dibits The word as received, oldest first: '0' +1, '1' +3, '2' -1, '3' -3 (dsd_symbol_level_from_dibit())
 * @param sync_len    Number of symbols in the word
 * @return Result code: DEGENERATE as well for a word of one level, a character outside '0'..'3', or a fit whose
 *         outer levels are less than DSD_WARM_START_MIN_SPAN apart or the wrong way round
 */
dsd_warm_start_result_t dsd_sync_warm_start_thresholds_from_dibits(const struct dsd_opts* opts, struct dsd_state* state,
                                                                   const char* sync_dibits, int sync_len);

/**
 * @brief Warm-start only the DC center estimate from an outer-only sync.
 *
 * CQPSK in dsd-neo uses a fixed-threshold slicer (see cqpsk_slice in
 * src/core/frames/dsd_dibit.c) and subtracts state->center to remove DC bias
 * before slicing. For this path, a safe sync-time calibration is to update
 * only state->center, leaving the CQPSK decision thresholds unchanged.
 *
 * This function estimates the two outer symbol clusters from the last
 * `sync_len` history entries and sets:
 *   - state->center = (mean_low + mean_high) / 2
 *
 * It does not modify state->min/max/lmid/umid or reference values.
 *
 * @param state Decoder state to update
 * @param sync_len Number of symbols in sync pattern
 * @return Result code indicating success or reason for skip
 */
dsd_warm_start_result_t dsd_sync_warm_start_center_outer_only(struct dsd_state* state, int sync_len);

#ifdef __cplusplus
}
#endif

#endif /* DSD_NEO_INCLUDE_DSD_NEO_DSP_SYNC_CALIBRATION_H_ */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief DSP demodulation pipeline public API.
 *
 * Declares decimation, discrimination, deemphasis, DC block, audio filtering,
 * and the full pipeline entrypoint implemented in `src/dsp/demod_pipeline.cpp`.
 */

#ifndef DSP_DEMOD_PIPELINE_H
#define DSP_DEMOD_PIPELINE_H

#include <dsd-neo/dsp/live_iq_step.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Forward declaration of demod_state structure */
struct demod_state;

/**
 * Boxcar low-pass and decimate by step (no wraparound).
 * Length must be a multiple of step.
 *
 * @param signal2 In/out buffer of samples.
 * @param len     Length of input buffer.
 * @param step    Decimation factor.
 * @return New length after decimation.
 */
int low_pass_simple(float* signal2, int len, int step);

/**
 * Simple square window FIR on real samples with decimation to rate_out2.
 *
 * @param s Demodulator state (uses result buffer and decimation state).
 */
void low_pass_real(struct demod_state* s);

/**
 * Perform FM discrimination on interleaved low-passed I/Q to produce audio PCM.
 *
 * @param fm Demodulator state (uses lowpassed as input, writes to result).
 * @note Renamed to avoid collision with codec2's fm_demod symbol on Windows.
 */
void dsd_fm_demod(struct demod_state* fm);

/* AM envelope detector design (issue #524). The carrier estimate is a one-pole average of |z| with this time constant
   in milliseconds, recomputed for the rate the detector runs at. */
#define DSD_AM_CARRIER_TAU_MS  50

/* A channel squelch that stays closed longer than this, in milliseconds, ends the transmission the carrier estimate
   was tracking: the next unsquelched block warm-starts it, as after a reset, since what opens the squelch next is
   usually another station at another level. A shorter closure (a fade) keeps the estimate. Twice the carrier time
   constant, so a dip the estimate would not have forgotten anyway is not treated as a new station. */
#define DSD_AM_CARRIER_HOLD_MS (2 * DSD_AM_CARRIER_TAU_MS)

/**
 * AM envelope detector on interleaved low-passed I/Q (issue #524).
 *
 * Output is 0.25 x clamp(|z| / C - 1, -2, 2), where C is the carrier estimate held in `am_carrier`: a one-pole average
 * of |z| with a DSD_AM_CARRIER_TAU_MS time constant. Dividing by the carrier makes the level the modulation depth,
 * whatever the RF level or input scaling (100% modulation peaks at 0.25, as live FM does at about 6 kHz deviation), so
 * the RTL output scale is not applied to it. The envelope has no phase, so a carrier offset inside the channel changes
 * nothing. A block the channel squelch zeroed (`channel_squelched`) is silence and leaves C where it was; once the
 * squelch has been closed for longer than DSD_AM_CARRIER_HOLD_MS (`am_squelched_samples`), the next unsquelched block
 * starts C over. C at 0 (a reset) is warm-started from the block's mean magnitude; with no carrier at all the output
 * is silence.
 *
 * @param fm Demodulator state (uses lowpassed as input, writes to result, updates am_carrier and am_squelched_samples).
 */
void dsd_am_demod(struct demod_state* fm);

/**
 * Whether the AM envelope detector demodulates the monitor audio: the analog family's AM kind installed it and the
 * monitor runs on its own channel (dsd_demod_analog_monitor_active()). A typed digital scan row's profile on an AM
 * session is FM-demodulated instead, as under the FM monitor, so it reads 0 there; the AM session's de-emphasis (none)
 * still applies to it, where the FM monitor's de-emphasizes it.
 *
 * @param d Demodulator state; NULL reads as not AM.
 * @return 1 when the AM detector produces the monitor audio, else 0.
 */
int dsd_demod_am_active(const struct demod_state* d);

/**
 * Whether the complex I/Q DC blocker runs on the next block.
 *
 * It runs when enabled (`iq_dc_block_enable`), except under the AM detector: AM keeps its carrier at 0 Hz after
 * tuning (centred I/Q, offset tuning), where the blocker would remove it. The setting itself is kept.
 *
 * @param d Demodulator state; NULL reads as not running.
 * @return 1 when the blocker runs, else 0.
 */
int dsd_demod_iq_dc_block_active(const struct demod_state* d);

/**
 * Whether the I/Q balance (image suppression) correction runs on the next block.
 *
 * It runs when enabled (`iqbal_enable`) and CQPSK is off, except under the AM detector: its image estimate reads an AM
 * carrier at 0 Hz after tuning, whose I/Q is a fixed phasor, as a full image and would subtract the wanted carrier and
 * sidebands with it. The setting itself is kept.
 *
 * @param d Demodulator state; NULL reads as not running.
 * @return 1 when the correction runs, else 0.
 */
int dsd_demod_iq_balance_active(const struct demod_state* d);

/**
 * Pass-through demodulator: copies low-passed samples to output unchanged.
 *
 * @param fm Demodulator state (copies lowpassed to result).
 */
void raw_demod(struct demod_state* fm);

/**
 * Differential QPSK demodulator for CQPSK/LSM.
 *
 * Converts each carrier-corrected differential phasor to a real symbol using
 * `atan2f(Q, I) * (4/pi)`, matching OP25's `multiply_const_ff(4.0/pi)` stage.
 * The output range maps nominal CQPSK decision points to approximately
 * `{-3, -1, +1, +3}` for four-level slicers.
 *
 * @param fm Demodulator state (reads interleaved I/Q in lowpassed, writes phase deltas to result).
 */
void qpsk_differential_demod(struct demod_state* fm);

/**
 * Apply post-demod deemphasis IIR filter with Q15 coefficient.
 *
 * @param fm Demodulator state (reads/writes result, updates deemph_avg).
 */
void deemph_filter(struct demod_state* fm);

/** The FM monitor's output scale, which takes discriminator radians into roughly [-1, 1] at the reference rate below:
    1 kHz at 3 kHz deviation reads 0.125 peak. */
#define DSD_DEMOD_MONITOR_OUTPUT_SCALE       (1.0 / 3.14159265358979323846)
/** The discriminator rate the monitor's output scale is calibrated at. Its output is the phase step per sample, so the
    scale grows with the rate it runs at: a given deviation reads the same at any rate. */
#define DSD_DEMOD_MONITOR_SCALE_REFERENCE_HZ 48000.0

/**
 * The one-pole de-emphasis coefficient for @p tau_us at @p rate_hz, quantised to Q15 as the filters apply it: the
 * monitor's (deemph_filter(), at `rate_out`) and the FSK voice lane's (at `complex_rate`).
 *
 * @return The coefficient in (0, 1), or 0 for no de-emphasis (@p tau_us 0 or less).
 */
float dsd_demod_deemph_alpha(int rate_hz, int tau_us);

/**
 * The gain that makes up for the de-emphasis the next block's output runs through, at 1 kHz (issue #518): the inverse
 * of the filter's magnitude there, from the quantised coefficient it applies at the rate it runs at: the monitor's
 * (`deemph_a` at `rate_out`, after the post-demod decimator), or on the FSK discriminator the voice lane's while it
 * runs (`voice_lane_deemph_a` at `complex_rate`). The monitor's reference tone, 1 kHz at 3 kHz deviation, then reads
 * the same whatever `DSD_NEO_DEEMPH` selects: about 1.105 (+0.865 dB) at the default 75 us and 48 kHz, 4.81
 * (+13.65 dB) at 750 us.
 *
 * @param d Demodulator state; NULL reads as none.
 * @return The gain, or 1.0 when the block runs no de-emphasis: off, AM, the FSK discriminator without its voice lane,
 *         CQPSK symbols and the raw pass-through.
 */
double dsd_demod_deemph_compensation(const struct demod_state* d);

/**
 * Apply a simple DC blocking (leaky integrator high-pass) filter to audio.
 *
 * @param fm Demodulator state (reads/writes result, updates dc_avg).
 */
void dc_block_filter(struct demod_state* fm);

/**
 * Apply a simple one-pole low-pass filter to audio.
 *
 * @param fm Demodulator state (reads/writes result, updates audio_lpf_state).
 */
void audio_lpf_filter(struct demod_state* fm);

/**
 * Calculate mean power (squared RMS) with DC bias removed.
 *
 * @param samples Input samples buffer.
 * @param len     Number of samples.
 * @param step    Step size for sampling.
 * @return Mean power (squared RMS) with DC bias removed.
 */
float mean_power(const float* samples, int len, int step);

/**
 * Full demodulation pipeline for one block.
 * Applies decimation via half-band cascade and the selected demodulation chain.
 *
 * A block its front end (the half-band cascade and the channel filter) leaves empty, as a channel-filter warm-up can,
 * sets result_len to 0 and makes no per-block decision: the squelch gate, the squelch envelope, the channel power and
 * the CQPSK zero symbols wait for the next block with samples.
 *
 * @param d Demodulator state (consumes lowpassed, produces result).
 */
void full_demod(struct demod_state* d);

/**
 * @brief The TETRA chain's transfer sub-block, in symbols of mixer input.
 *
 * The chain moves the FLL's residual into its tracking mixer (dsd_fll_band_edge_transfer()) only at multiples of this
 * many symbols of mixer input since the channel filter last started over (demod_state::tetra_sub_pos), running a
 * block in pieces cut at those boundaries, so the transfer falls on the same sample however the input is cut into
 * blocks. 96 symbols is 5.33 ms, the block an I/Q replay reads at every rate in the TETRA domain.
 */
#define DSD_TETRA_SUBBLOCK_SYMBOLS 96

/**
 * @brief Whether the TETRA receive chain can run on a demodulator as it is configured now.
 *
 * True only when all of these hold: the channel profile is DSD_CH_LPF_PROFILE_TETRA; CQPSK is enabled; the symbol
 * rate is 18000; the effective TED samples per symbol (ted_sps_override when above 0, else ted_sps) and ted_sps
 * itself, which the Gardner TED and the FLL run at (dsd_cqpsk_timing_sps()), both equal complex_rate / 18000
 * exactly; complex_rate is in the TETRA rate domain (dsd_tetra_dsp_rate_runs(), 36 to 144 kHz); the channel LPF is
 * enabled; and dsd_tetra_channel_design() succeeds at complex_rate, whatever plan is installed now. That last answer is memoized by rate
 * (demod_state::tetra_design_rate_out): full_demod() checks the design once per rate, and the predicate reads the memo
 * for its rate, designing only when the memo is for another one.
 *
 * full_demod() evaluates it once per block, after the half-band decimation (dsd_demod_update_tetra_chain(), which a
 * stream open also calls), and keeps the result in demod_state::tetra_chain, running the state transition when it
 * changes: entering splits the carrier estimate into the TETRA mixer and re-initializes the band-edge FLL with the
 * TETRA parameters; leaving folds the mixer back into the FLL and re-initializes it with the P25 parameters; either way
 * the mixer phasor, the channel LPF, the matched filter and the CQPSK AGC average start over. Setters never evaluate
 * it.
 *
 * @param d Demodulator state (NULL reads false).
 * @return 1 when the chain can run, else 0.
 */
int dsd_demod_tetra_chain_wanted(const struct demod_state* d);

/**
 * @brief Whether the TETRA channel filter (dsd_tetra_channel_design()) runs on a demodulator as it is now.
 *
 * It runs with the TETRA chain (demod_state::tetra_chain), and on a trunked mode uplink session
 * (demod_state::tetra_uplink), which never runs the chain but keeps its channel filter: the TETRA profile on
 * CQPSK at 18000 sym/s with the channel LPF on, at a rate in the TETRA rate domain (dsd_tetra_dsp_rate_runs()) where
 * the design succeeds (the memo dsd_demod_tetra_chain_wanted() reads). Otherwise a TETRA profile runs the legacy WIDE
 * design, or with the channel LPF off none.
 *
 * @param d Demodulator state (NULL reads false).
 * @return 1 when the TETRA channel filter is the plan, else 0.
 */
int dsd_demod_tetra_channel_runs(const struct demod_state* d);

/**
 * @brief The TETRA stage that bounds a demodulator's noise, for the SNR bias (dsd_snr_noise_bandwidth_hz()).
 *
 * @param d Demodulator state (NULL reads DSD_SNR_TETRA_STAGE_WIDE).
 * @return DSD_SNR_TETRA_STAGE_CHAIN while the TETRA chain runs, DSD_SNR_TETRA_STAGE_CHANNEL while the TETRA channel
 *         filter runs without it (dsd_demod_tetra_channel_runs()), else DSD_SNR_TETRA_STAGE_WIDE.
 */
int dsd_demod_tetra_stage(const struct demod_state* d);

/**
 * @brief Whether the Gardner TED takes a TETRA uplink session's burst timing from the training sequences
 *        (tetra_uplink_timing.h).
 *
 * On a trunked mode uplink session (demod_state::tetra_uplink) off the TETRA chain while the TETRA channel filter runs
 * (dsd_demod_tetra_channel_runs()), at @p sps from DSD_TETRA_UL_MIN_SPS to DSD_TETRA_UL_MAX_SPS. Nothing else runs it.
 *
 * @param d Demodulator state (NULL reads false).
 * @param sps Samples per symbol the Gardner runs at (dsd_cqpsk_timing_sps()).
 * @return 1 when the uplink burst timing runs, else 0.
 */
int dsd_demod_tetra_uplink_timing_runs(const struct demod_state* d, int sps);

/**
 * @brief Samples of signal the uplink still holds back: its look-ahead and the Gardner's delay line behind it
 * (dsd_tetra_ul_timing_held_through() with the delay line's twice_sps).
 *
 * 0 off the uplink burst timing (dsd_demod_tetra_uplink_timing_runs()) or before the Gardner fed the look-ahead.
 *
 * @param d Demodulator state (NULL reads 0).
 * @return Zero samples to push before every symbol that reads signal is out of the Gardner.
 */
size_t dsd_demod_tetra_uplink_held(const struct demod_state* d);

/**
 * @brief The end of an uplink stream: push the held signal out.
 *
 * Runs exactly dsd_demod_tetra_uplink_held() zero samples through the uplink's Gardner, differential and Costas stages
 * and the phase demodulator, so every symbol the look-ahead and the Gardner's delay line held back is in
 * demod_state::result (result_len, 0 when it held nothing) and nothing is held after it. The demod thread publishes it
 * as a block of its own once a replay's input ended (a squelched block drains the same samples in full_demod()).
 *
 * @param d Demodulator state.
 * @return 1 when it produced output, else 0.
 */
int dsd_demod_tetra_uplink_flush(struct demod_state* d);

/**
 * @brief Evaluate the TETRA chain's activation predicate and run the state transition when the answer changed.
 *
 * full_demod() calls this at every block boundary, after the half-band decimation. A stream open calls it once its
 * configuration is final, before any block runs, so a TETRA open runs the chain, and publishes the TETRA profile, from
 * the start; the first block then finds demod_state::tetra_chain already set and runs no transition. With nothing
 * changed since the last call it does nothing (it warns once per cause about a TETRA profile whose chain cannot run).
 *
 * @param d Demodulator state (NULL does nothing).
 */
void dsd_demod_update_tetra_chain(struct demod_state* d);

/**
 * @brief Averaging weight of the CQPSK RMS AGC (OP25 rms_agc alpha; the decay is 1 - alpha).
 *
 * @param tetra_chain demod_state::tetra_chain: nonzero for the TETRA receive chain.
 * @return 0.1 for the TETRA chain, OP25's 0.45 for every other chain.
 */
float dsd_cqpsk_agc_alpha(int tetra_chain);

/**
 * Return the filter state to a fresh stream's: each half-band stage's history and pending count (its look-ahead and
 * decimation phase), the live I/Q rate step's history and phase (its design stays), the channel FIR's history and
 * pending outputs, and a replay's post-demod audio decimator on either
 * path (the polyphase history and phase; the fallback's one-pole and part-filled group). Every filter's next output is
 * centred on its next input sample, the decimator's next output comes with the post_downsample-th sample, and what
 * they held back is dropped. The auto squelch's tracker starts its windows over at its next block, keeping its floor
 * when the context is the same. The one filter reset: stream open, retunes and family switches all reset through it.
 *
 * @param d Demodulator state; NULL is ignored.
 */
void dsd_demod_reset_filter_state(struct demod_state* d);

/**
 * Prepare @p plan as the live I/Q rate step's candidate (issue #806; dsd_live_iq_step_prepare() on
 * demod_state::live_iq_step) with this pipeline's capacities: a block brings the step at most MAXIMUM_BUF_LENGTH / 2
 * complex samples halved by each of the plan's passes, and the step writes it to a DSD_DEMOD_WORKBUF_LENGTH work
 * buffer. A plan whose largest block would not fit (one that upsamples) is refused here, before any sample flows.
 * Call it, and the commit, rollback and finish after it, on the controller thread while the demod thread is paused.
 *
 * @return DSD_LIVE_IQ_STEP_OK, or a negative dsd_live_iq_step_status.
 */
int dsd_demod_live_step_prepare(struct demod_state* d, const dsd_live_iq_step_plan* plan);

/**
 * Build the dynamic squelches' noise model for the live I/Q rate step's active plan (issue #806;
 * dsd_squelch_step_model_build() on demod_state::squelch_step_model, behind the half-band cascade the plan's passes
 * run). Call it after every commit or rollback that leaves the step running, on the controller thread while the demod
 * thread is paused: the auto and noise squelch plans of a stepping chain come from it, and stay not valid (the gate
 * open) without it. A model already built for the plan is kept; with the step off nothing changes.
 *
 * @return 0, or -1 when the model could not be built (the squelch gate then stays open behind the step).
 */
int dsd_demod_squelch_step_model_sync(struct demod_state* d);

/**
 * Channel edge (Hz) that the channel low-pass protects for a profile.
 *
 * The half-width of the nominal channel — 12.5 kHz modes return 6250. This is
 * the channel, not the filter: DSD_CH_LPF_PROFILE_P25_CQPSK runs a roomier
 * 7250 Hz cutoff and still protects a 12.5 kHz channel. DSD_CH_LPF_PROFILE_TETRA
 * returns 11250, the edge its TETRA chain design protects.
 *
 * @param profile DSD_CH_LPF_PROFILE_* value.
 * @return Channel half-width in Hz; the wide/analog edge for unknown profiles.
 */
double dsd_channel_lpf_protected_edge_hz(int profile);

/**
 * Design the analog channel filter for a full RF channel width.
 *
 * Cutoff is width/2 + DSD_ANALOG_CHANNEL_GUARD_HZ with the fixed
 * DSD_ANALOG_CHANNEL_TRANSITION_HZ Blackman transition, so the width is the
 * protected passband. 16000 Hz reproduces the WIDE profile's taps wherever the
 * WIDE design runs unclamped: rates from about 19.1 kHz, where its cutoff stops
 * being held to 0.9 x Nyquist, up to the 288-tap capacity both share at about
 * 102.7 kHz (DSD_DIGITAL_CHANNEL_MAX_RATE_HZ; 219 taps at 78,125 Hz). Above that
 * WIDE runs its 63-tap fallback prototype. There is no Nyquist clamp and no
 * fallback prototype here: a width the rate cannot realize (see
 * dsd_analog_width_realizable()) is an error.
 *
 * @param rate_hz  Channel-filter sample rate (demod complex_rate) in Hz.
 * @param width_hz Full channel width in Hz.
 * @param taps_out Output taps; must hold @p max_taps floats.
 * @param max_taps Capacity of @p taps_out (at most DSD_ANALOG_CHANNEL_MAX_TAPS is used).
 * @return Number of taps written, or -1 when the width cannot be designed.
 */
int dsd_channel_lpf_design_analog(int rate_hz, int width_hz, float* taps_out, int max_taps);

/**
 * Design the TETRA chain's channel filter for a rate.
 *
 * GNU Radio's window design (firdes::low_pass()) with cutoff 12.5 kHz and a
 * 2.5 kHz Blackman transition, so it protects the 11250 Hz channel edge: 49 / 97 /
 * 193 taps at 36 / 72 / 144 kHz. The channel plan installs it for
 * DSD_CH_LPF_PROFILE_TETRA only while demod_state::tetra_chain is set. There is
 * no Nyquist clamp and no fallback prototype: a rate whose Nyquist frequency
 * does not clear the 13750 Hz stopband edge, or a design longer than the
 * capacity, is an error.
 *
 * @param rate_hz  Channel-filter sample rate (demod complex_rate) in Hz.
 * @param taps_out Output taps; must hold @p max_taps floats.
 * @param max_taps Capacity of @p taps_out (at most DSD_CHANNEL_LPF_MAX_TAPS is used).
 * @return Number of taps written, or -1 when the rate cannot be designed for (nothing written).
 */
int dsd_tetra_channel_design(int rate_hz, float* taps_out, int max_taps);

/**
 * Channel width the legacy WIDE profile plan protects at a rate.
 *
 * The plan the unset NFM default runs where the rate cannot realize the 16 kHz
 * width-driven design: the WIDE design within DSD_CHANNEL_LPF_MAX_TAPS with its
 * cutoff held to 0.9 x Nyquist, or, at rates that design cannot fit (above
 * DSD_DIGITAL_CHANNEL_MAX_RATE_HZ, about 102.7 kHz), the 63-tap WIDE fallback
 * prototype, whose response scales with the rate it runs at. The width is the
 * protected passband (twice the edge the transition starts at), measured the
 * same way as an analog width.
 *
 * @param rate_hz Channel-filter sample rate (demod complex_rate) in Hz.
 * @return Protected width in Hz, or 0 for a rate of 0 or less.
 */
int dsd_channel_lpf_legacy_wide_width_hz(int rate_hz);

#ifdef __cplusplus
}
#endif

#endif /* DSP_DEMOD_PIPELINE_H */

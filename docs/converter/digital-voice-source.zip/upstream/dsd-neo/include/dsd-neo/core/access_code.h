// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief The access code a call was heard with: DMR/dPMR/TETRA colour code, P25 NAC, NXDN RAN, M17 CAN.
 *
 * A call history row records the code of the carrier its call was decoded on (issue #575). This header names the
 * kinds and reads the live code for a protocol. It stays out of `state.h` so app-control's public views, which may
 * not include `state.h` or `opts.h`, can name the kinds.
 *
 * Each source the reader takes is set only from content the protocol checked, as below, and is cleared or reset to a
 * sentinel between carriers:
 * - DMR `dmr_color_code`: the slot type's Golay(20,8) (behind the BS colour-code lock) or the MS embedded
 *   signalling's QR(16,7,6); 16 until one decodes, and back to 16 at every carrier boundary.
 * - P25 Phase 1 `nac`: the BCH(63,16) network identifier; 0 between carriers. `p25p1_nid_nac_usable()` refuses
 *   NAC 0x000 and 0xFFF, dsd-neo's own acceptance rule (a dead or stuck input decodes as an all-zero or all-one NID),
 *   so a carrier whose NID decodes either leaves `nac` at 0 and shows no NAC.
 * - P25 Phase 2 `p2_proven_nac`: the NAC the latest checked Phase 2 proof on this carrier named (issue #802), -1 for
 *   none: the seed (`p2_cc`, from the network status broadcast or the Phase 1 NID, or set by hand) once a burst
 *   descrambled with it (a scrambled FACCH or SACCH, or an ESS) passed its Reed-Solomon check, or the NAC a checked
 *   network status broadcast carries, whatever seed is configured (a hand-set seed stays the descrambler's). A call
 *   carried by unscrambled FACCH/SACCH never tests the seed, so a value -X or another carrier left is no NAC until a
 *   proof names it. Never `rx_id`, which outlives the carrier and which a Phase 1 NID writes too; the record goes,
 *   with the seed's proof (`p2_cc_verified`), at every carrier boundary, Phase 1 NID or site reset that changes the
 *   seed, and seed set by hand.
 * - NXDN `nxdn_last_ran`: the CRC-checked CAC, FACCH2/UDCH or SACCH, or a CRC-checked site information message's site
 *   code (Table 6.3-4) of a confirmed transmission; (unsigned)-1 until one decodes, and between transmissions. The
 *   field also holds values that are not a RAN, which the terminal shows in its place: an IDAS (Type-D) carrier's SCCH
 *   area bit, and the fixed 7 a DCR transmission is given. The protocol marks
 *   those with `nxdn_last_ran_stand_in`, and the reader takes none of them: neither carrier has an access code.
 * - dPMR `dpmr_color_code`: the colour-code table's entry whose 12 information-bearing bits (the channel code's dibit
 *   MSBs; the LSBs are forced to 1 before the lookup) match the received channel code's, set only once the transmission
 *   is confirmed; -1 between carriers.
 * - M17 CAN: the low four bits of the call's service options, which the CRC-checked LSF carries; only once the call
 *   has service metadata.
 * - TETRA `rx_id` (<dsd-neo/core/received_identity.h>): the 6-bit colour code (EN 300 392-2 table 21.76) a
 *   CRC-checked trunked mode BSCH received on this carrier names, or that a CRC-checked downlink block descrambled
 *   with proves (every carrier of a cell scrambles with its network and colour code). The network a `--tetra-net`
 *   preset names, or one the descrambler keeps from another carrier, is configuration until such a block passes; a
 *   direct mode carrier has none. The record drops the code at every carrier boundary and accepted trunking retune
 *   until the new carrier's next BSCH or checked downlink block.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_ACCESS_CODE_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_ACCESS_CODE_H_H

#include <dsd-neo/core/state_fwd.h>

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Which access code a value is. The values are pinned: `Event_History::access_code_kind` carries them, the control
 * API sends them, and the Qt call history persists them, so a value is never renumbered or reused.
 */
typedef enum {
    DSD_ACCESS_CODE_NONE = 0,       /**< No code, or none known. */
    DSD_ACCESS_CODE_COLOR_CODE = 1, /**< DMR (0..15), dPMR (0..63) or TETRA (0..63) colour code. */
    DSD_ACCESS_CODE_NAC = 2,        /**< P25 network access code (0x001..0xFFE; dsd-neo takes no 0x000 or 0xFFF). */
    DSD_ACCESS_CODE_RAN = 3,        /**< NXDN radio access number (0..63). */
    DSD_ACCESS_CODE_CAN = 4,        /**< M17 channel access number (0..15). */
} dsd_access_code_kind;

/**
 * Say which access code a protocol carries.
 *
 * @param synctype A `DSD_SYNC_*` value.
 * @return COLOR_CODE for DMR (BS and MS), dPMR and TETRA, NAC for P25 Phase 1 and 2, RAN for NXDN, CAN for M17; NONE
 *         for everything else (D-STAR, YSF, EDACS, ProVoice, X2-TDMA, analog, no sync).
 */
dsd_access_code_kind dsd_access_code_kind_for_protocol(int synctype);

/**
 * Read a protocol's access code as the decoder holds it now.
 *
 * A P25 Phase 1 call reads `nac` only and a Phase 2 call `p2_proven_nac` only. A fallback from one to the other would
 * read a stale seed on a Phase 1 carrier whose NID decoded NAC 0x000 or 0xFFF, which leave `nac` at 0, or a Phase 1
 * NID's NAC as a Phase 2 proof.
 *
 * @param state                Decoder state; NULL reports no code.
 * @param protocol             The call's `DSD_SYNC_*` value.
 * @param service_options      The call's service options (M17 carries its CAN there).
 * @param has_service_metadata Non-zero once the service options were observed.
 * @param kind_out             Receives the `dsd_access_code_kind`; NONE when there is no valid code. May be NULL.
 * @param value_out            Receives the code; 0 when there is no valid code. May be NULL.
 * @return 1 when the protocol's code is valid now, 0 otherwise (unknown, a sentinel, or a protocol without one).
 */
int dsd_access_code_current(const dsd_state* state, int protocol, uint16_t service_options,
                            uint8_t has_service_metadata, uint8_t* kind_out, uint16_t* value_out);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_ACCESS_CODE_H_H */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief CSV import helpers for runtime/UI one-shot actions.
 *
 * Declares CSV import entrypoints implemented in core.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_CSV_IMPORT_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_CSV_IMPORT_H_H

#include <dsd-neo/core/csv_validate.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#ifndef __cplusplus
/* In C, a tag first declared in a parameter list has only prototype scope. */
struct p25_bandplan_row;
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Import a group list (docs/csv-formats.md, "Group List CSV") into the state's talkgroup
 * policy. Malformed rows are skipped with a warning, as are rows dropped for an allocation
 * failure, and the import still returns 0 with whatever loaded. Returns -1 when the file
 * cannot be opened or a read error interrupts it (rows read before it stay loaded). A load that
 * left rows out (dsd_tg_policy_load_report_incomplete(): a dropped row, a read error, or data
 * rows none of which loaded) is logged once and marks the list incomplete, so it is never
 * written back over the file (dsd_tg_policy_incomplete()); -1 when no list could carry that mark.
 * A header-only or empty file loads as an empty list.
 */
/* Source aliases: replace on success; preserve live store on open/read/allocation failure. */
int csvSrcImport(const dsd_opts* opts, dsd_state* state);
int csvSrcImportPath(const char* path, dsd_state* state);

int csvGroupImport(const dsd_opts* opts, dsd_state* state);
/** csvGroupImport() on an explicit path. */
int csvGroupImportPath(const char* group_file_path, dsd_state* state);

/** Why csvGroupImportPathReported() failed. */
typedef enum {
    DSD_GROUP_IMPORT_OK = 0,
    DSD_GROUP_IMPORT_NOT_FOUND,  /* no file at the path */
    DSD_GROUP_IMPORT_UNREADABLE, /* it could not be opened or read to the end */
    DSD_GROUP_IMPORT_NO_MEMORY,  /* the list could not be stored or marked */
} dsd_group_import_failure;

/**
 * csvGroupImportPath() that says why it failed in @p failure (may be NULL; DSD_GROUP_IMPORT_OK on success). With
 * @p quiet_open nonzero a file that cannot be opened is not logged, for a caller that reports the failure itself; row
 * warnings and an incomplete load are logged as always.
 */
int csvGroupImportPathReported(const char* group_file_path, dsd_state* state, int quiet_open,
                               dsd_group_import_failure* failure);
int csvChanImport(const dsd_opts* opts, dsd_state* state);
struct dsd_scan_option_baseline;
/** Warn, one line per entry, about each channel-map entry of @p rows whose service names only rejected traffic could
 * carry: its own filters, or the configured policies @p baseline (NULL: none) it inherits, reject them (issue #637).
 * The names are kept. Call once the map and the policies it runs over are final, with the configured ones
 * (dsd_scan_option_baseline_configured() on the live state), never an import's scratch state. */
void csvChanWarnUnreachableNames(const dsd_state* rows, const struct dsd_scan_option_baseline* baseline);
int csvKeyImportDec(const dsd_opts* opts, dsd_state* state);
int csvKeyImportHex(const dsd_opts* opts, dsd_state* state);
int csvKeyImportDecPath(const char* path, int show_keys, dsd_state* state, dsd_csv_validation* stats);
int csvKeyImportHexPath(const char* path, int show_keys, dsd_state* state, dsd_csv_validation* stats);
int csvVertexKsImport(dsd_state* state, const char* path);
int csvDmrTgKeyImport(dsd_state* state, const char* path);

/**
 * Load a P25 band plan CSV (docs/csv-formats.md, "P25 Band Plan CSV") into
 * state->p25_bandplan_rows, replacing any stored plan, then seed the live IDEN
 * tables (dsd_state_p25_bandplan_seed). Bad rows are skipped with a warning; a
 * file with no usable row fails and leaves the stored plan untouched.
 * Returns 0 on success, -1 otherwise.
 */
int csvP25BandplanImportPath(const char* path, dsd_state* state);
/** csvP25BandplanImportPath() on opts->p25_bandplan_in_file. */
int csvP25BandplanImport(const dsd_opts* opts, dsd_state* state);
/**
 * Write band-plan rows (see dsd_p25_bandplan_append_tables) to `path` in the
 * import format, through a private temp file and atomic replace. Refuses an
 * empty list. Returns 0 on success, -1 otherwise.
 */
int csvP25BandplanExportRows(const char* path, const struct p25_bandplan_row* rows, int count);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_CSV_IMPORT_H_H */

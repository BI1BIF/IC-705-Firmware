// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Keyring helper API.
 *
 * Declares the keyring loader implemented in core.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_KEYRING_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_KEYRING_H_H

#include <dsd-neo/core/call_state.h>
#include <dsd-neo/core/key_material.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Activate imported key material for an explicit decoder slot. */
void keyring_activate_slot(dsd_opts* opts, dsd_state* state, int slot);
/** Storage index used by legacy destination-key imports and autoload. */
uint16_t keyring_destination_index(uint32_t destination);
/** Return whether the first required AES segments exist for an imported key ID. */
int keyring_aes_segments_complete(const dsd_state* state, int key_id, unsigned int required_segments);

/** Look up the DMR talkgroup -> key ID override map. Returns 1 on a hit with *out_kid set. */
int keyring_dmr_tg_map_kid(const dsd_state* state, uint32_t tg, uint8_t* out_kid);

/** Drop every DMR talkgroup -> key ID mapping and the per-slot applied- and skipped-notice latches. */
void keyring_dmr_tg_map_reset(dsd_state* state);

/**
 * keyring_dmr_kid_for_call() plus the once-per-call-epoch operator notice.
 *
 * Use this on the voice path, where a call epoch exists to latch the notice against. Other
 * consumers want keyring_dmr_kid_for_call(), which is silent.
 */
int keyring_dmr_slot_kid_for_call(dsd_state* state, int slot, const dsd_call_snapshot* call, dsd_key_material_need need,
                                  int signaled_kid);

/**
 * Report the imported key material behind a key ID without activating it.
 *
 * Classification and lockout must ask "could this key id decrypt?" before any voice frame
 * has run, which the activation path cannot answer without mutating R/A1..A4.
 *
 * Segment 0 shares the scalar key's index, so a scalar key also reports aes_loaded -- this
 * deliberately mirrors keyring_activate_slot_with_kid() so classification and activation
 * cannot disagree. A segment is present when it was imported (rkey_array_loaded), whatever its
 * value, or, for material stored without that flag, when it is non-zero: an imported all-zero key
 * is a key, as the same value entered directly is.
 *
 * @param out_rkey       scalar key value, 0 when none or when the key is zero (may be NULL); whether
 *                       a zero value is a key is keyring_kid_scalar_present()'s answer
 * @param out_aes_loaded 1 when the key's first AES segment (its own cell) is present (may be NULL); whether
 *                       the key is wide enough for an ALG is keyring_kid_aes_segments()'s answer
 * @return 1 when the key ID has any material at all.
 */
int keyring_kid_material(const dsd_state* state, int key_id, unsigned long long* out_rkey, int* out_aes_loaded);

/**
 * Whether the key ID holds a scalar key, by the rule activation applies to
 * dsd_state::scalar_key_present: imported (rkey_array_loaded) whatever its value, or non-zero.
 */
int keyring_kid_scalar_present(const dsd_state* state, int key_id);

/**
 * The key ID's width in AES segments (0..4): how many of its leading segment cells (ID, +0x101, +0x201, +0x301) are
 * present by the same rule. An AES ALG can use the key only when this reaches its width (AES-128 2, TDEA 3, AES-256
 * 4); a cell after a missing one is another ID's key aliased onto it and is never counted.
 */
int keyring_kid_aes_segments(const dsd_state* state, int key_id);

/**
 * Load the key ID's scalar key into the slot (R or RR, scalar_key_present[]) when keyring_kid_scalar_present() says
 * it holds one, an imported zero included. Leaves the slot untouched and returns 0 when it holds none; 1 when loaded.
 * For the protocols that key a scalar by a signalled ID or destination outside keyring_activate_slot_with_kid()
 * (NXDN).
 */
int keyring_load_scalar_key(dsd_state* state, int slot, int key_id);

/**
 * Report whether a key ID holds a complete Kirisun (ALG 0x36/0x37) quartet.
 *
 * The Kirisun half of decryptability cannot be expressed as rkey/aes_loaded: it needs all four
 * AES segments present *and* strictly non-zero. keyring_kid_material() answers the scalar half of
 * "could this key id decrypt?"; this answers the Kirisun half, so classification and lockout can
 * evaluate a --dmr-tg-key-csv key id before any voice frame has activated it.
 *
 * Predicts exactly what dsd_dmr_kirisun_slot_key_complete() reports for a slot once
 * keyring_activate_slot_with_kid() has installed @p key_id into it.
 *
 * @return 1 when the key ID would activate as a complete Kirisun key.
 */
int keyring_kid_kirisun_complete(const dsd_state* state, int key_id);

/**
 * @brief Whether an imported key ID holds the material @p need calls for.
 *
 * The gate `keyring_dmr_effective_kid()` applies to a --dmr-tg-key-csv row. "Has any bytes at
 * all" is the wrong question twice over: a scalar cannot serve an AES ALG, and the flat
 * rkey_array aliases segment N of key K onto the scalar of key K + offset, so one unrelated
 * import can make an empty key ID look populated. Requiring the ALG's actual material answers
 * both -- an accidental match then needs as many colliding keys as the ALG needs segments.
 *
 * Presence follows activation: a cell counts when it was imported (rkey_array_loaded) whatever its
 * value, or when it is non-zero, so a loaded all-zero key satisfies the need it covers. The Kirisun
 * quartet keeps its all-non-zero rule (keyring_kid_kirisun_complete()). Classification must predict
 * activation.
 *
 * @return 1 when @p key_id satisfies @p need; 0 otherwise, including for DSD_KEY_NEED_NONE.
 */
int keyring_kid_satisfies_need(const dsd_state* state, int key_id, dsd_key_material_need need);

/**
 * Key ID a DMR slot should decrypt with (--dmr-tg-key-csv).
 *
 * A map row for `target` replaces the OTA-signaled key ID, but only when the mapped ID holds the
 * material @p need calls for: a row naming a key that cannot serve this ALG would otherwise zero
 * the slot key and shadow a signaled ID that would have worked, arming a session-permanent
 * lockout on a call that was decryptable. `need` comes from the caller because the ALG numbering
 * is the caller's -- voice IDs in core/audio, DMR data IDs in protocol/dmr.
 *
 * `target_is_group` is load-bearing, not defensive -- DMR radio IDs share the talkgroup's
 * 24-bit space, so an unchecked match keys a unit call off a colliding row.
 *
 * Returns `signaled_kid` unchanged whenever the map does not apply, so callers activate one
 * key ID rather than maintaining a map path and a signaled path in parallel. That includes a
 * `signaled_kid` outside 0..0xFF: DMR key IDs are byte-wide, but `payload_keyid` is shared
 * across protocols and P25 stores a full 16-bit KID there, so the resolver owns the width guard
 * and every caller passes the value it holds without narrowing it first.
 *
 * @param out_mapped set to 1 when a map row was applied, 0 otherwise (may be NULL)
 */
int keyring_dmr_effective_kid(const dsd_state* state, uint32_t target, int target_is_group, dsd_key_material_need need,
                              int signaled_kid, int* out_mapped);

/**
 * Activate imported key material for a slot using an explicit key ID.
 *
 * R/RR and A1..A4 take the stored values; scalar_key_present[] and aes_key_loaded[] take presence
 * from the import flags (keyring_kid_scalar_present(), the key's first AES segment), so an imported
 * all-zero key activates as present and an absent one as absent. aes_key_segments[] is the key's width
 * (keyring_kid_aes_segments()). Activation does not know the ALG, so every consumer that decides
 * decryptability for an AES ALG requires aes_key_segments[] to reach the ALG's width.
 */
void keyring_activate_slot_with_kid(dsd_state* state, int slot, int key_id);

/**
 * keyring_dmr_effective_kid() for a call snapshot the caller already holds.
 *
 * Applies only to an active DMR group-voice call with a usable talkgroup; returns
 * `signaled_kid` for anything else. Announces nothing -- see keyring_dmr_slot_kid_for_call().
 */
int keyring_dmr_kid_for_call(const dsd_state* state, const dsd_call_snapshot* call, dsd_key_material_need need,
                             int signaled_kid, int* out_mapped);

/** The keyring cell the DMR talkgroup key autoload reads for talkgroup @p tg (an ID past 16 bits is hashed to 16, as
 * the -k importer stores it). */
uint32_t keyring_dmr_tg_key_cell(uint32_t tg);

/**
 * The DMR talkgroup key autoload for a frame of slot @p slot's call on talkgroup @p tg (the legacy destination keyring,
 * -k/-K): loads the key the keyring holds for @p tg as the Basic Privacy and Hytera working key (K, K1, H). The working
 * key is one value both slots share, so when @p tg has no key, a key an earlier autoload loaded for another call's
 * talkgroup is taken out again and the key state that autoload replaced comes back (a key set directly, or none): it
 * is not this call's. A call no LC has named yet (@p tg 0, an identity-less epoch, as a colour code change reopens a
 * call) keys from the talkgroup the slot's own call last keyed from, or, when that is not known, from talkgroup 0's
 * own key if one is set, else from none (the key state the autoload replaced): never from the other slot's. A
 * terminator on the slot, the no-carrier pass, a carrier boundary other than a stream gap, a trunked follow that leaves
 * the carrier and a trunk-scan visit forget it (keyring_dmr_tg_autoload_forget_slot(), dmr_forget_call_privacy()), so
 * a new call keys from no earlier call's talkgroup; one whose terminator was missed on the same carrier is still the
 * slot's call and keys from its talkgroup until the new call's LC names its own (the code cannot tell them apart
 * before that). A key written since by anything else (a key command, a key set, a direct key, the no-carrier unload:
 * dsd_dmr_tg_autoload_hand_back()), whatever its value, is left alone. Returns 1 when a talkgroup's key was loaded,
 * that talkgroup into @p keyed_from, 0 otherwise.
 */
int keyring_dmr_tg_autoload_apply(dsd_state* state, uint8_t slot, uint32_t tg, uint32_t* keyed_from);

/**
 * The Basic Privacy and Hytera working key (K, K1, K2, K3, K4, H, then basic_key_present and hytera_key_segments) a
 * frame of slot @p slot's call on talkgroup @p tg is keyed with once the autoload has run for it
 * (keyring_dmr_tg_autoload_apply()), without running it: for judging and showing a call from its LC before its voice
 * keys it. With no @p state, no key (zeros): every word and flag is written on every path.
 */
void keyring_dmr_tg_autoload_preview(const dsd_state* state, uint8_t slot, uint32_t tg, unsigned long long int words[6],
                                     uint8_t flags[2]);

/** The Basic Privacy key index (K) alone that keyring_dmr_tg_autoload_preview() leaves, read without copying any other
 *  key word: the talkgroup's own key, else the key the autoload replaced, else the working key. 0 with no @p state. */
unsigned long long int keyring_dmr_tg_autoload_basic_key(const dsd_state* state, uint8_t slot, uint32_t tg);

/** Whether keyring_dmr_tg_autoload_preview() leaves a Basic Privacy or Hytera key. */
int keyring_dmr_tg_autoload_key_present(const dsd_state* state, uint8_t slot, uint32_t tg);

/** Forget the talkgroup slot @p slot's call keyed from and that key (its call ended at a terminator, or the receiver
 * left the carrier). */
void keyring_dmr_tg_autoload_forget_slot(dsd_state* state, uint8_t slot);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_KEYRING_H_H */

// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Dibit/symbol consumption helpers.
 *
 * Declares the dibit reader and soft-decision helpers implemented in
 * `src/core/frames/dsd_dibit.c`.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_DIBIT_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_DIBIT_H_H

#include <dsd-neo/platform/platform.h>

#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/state_fwd.h>

#include <stdint.h>

typedef struct {
    uint8_t reliability; /* 0=uncertain, 255=confident; min confidence across both bits. */
    int16_t llr[2];      /* [0]=MSB, [1]=LSB. Positive values favor bit 1. */
} dsd_dibit_soft_t;

enum DSD_ATTR_PACKED {
    DSD_SYMBOL_REPLAY_FORMAT_UNKNOWN = 0,
    DSD_SYMBOL_REPLAY_FORMAT_LEGACY = 1,
    DSD_SYMBOL_REPLAY_FORMAT_SOFT = 2,
};

#define DSD_SYMBOL_CAPTURE_SOFT_MAGIC       "DSDNSYM2"
#define DSD_SYMBOL_CAPTURE_SOFT_HEADER_SIZE 16
#define DSD_SYMBOL_CAPTURE_SOFT_RECORD_SIZE 10

/**
 * \brief The slicer that cut a four-level dibit, whose coordinates its reliability is measured in.
 */
typedef enum {
    /* The adaptive thresholds (min, lmid, center, umid, max), in the input's own units: C4FM and GFSK, any modulation
       from a float symbol file or PCM audio (a P25 rf_mod 1 session included), DMR CACH resampling. */
    DSD_DIBIT_SLICER_ADAPTIVE = 0,
    /* The RTL CQPSK phase domain, arg * 4/pi: the fixed levels +-1 and +-3 about state->center, as P25's CQPSK slicers
       cut them. */
    DSD_DIBIT_SLICER_CQPSK_PHASE = 1,
    /* TETRA's quadrant levels (dsd_tetra_quadrant_levels()): the fixed levels +-1 and +-3 about 0. */
    DSD_DIBIT_SLICER_TETRA_QUADRANT = 2,
} dsd_dibit_slicer;

#ifdef __cplusplus
extern "C" {
#endif

int get_dibit_and_analog_signal(dsd_opts* opts, dsd_state* state, int* out_analog_signal);
int getDibitSoft(dsd_opts* opts, dsd_state* state, dsd_dibit_soft_t* out_soft);
int getDibitAndSoftSymbol(dsd_opts* opts, dsd_state* state, float* out_soft_symbol);
void write_symbol_capture_record(dsd_opts* opts, dsd_state* state, int dibit, float symbol,
                                 const dsd_dibit_soft_t* soft);
/**
 * \brief Confidence (0 = none, 255 = full) in the dibit @p slicer cut from @p sym, measured in that slicer's
 * coordinates: the distance to its decision boundary, weighted by the demodulator's SNR on a radio build. The fixed
 * CQPSK levels apply only to a symbol that is arg * 4/pi of the differential phasor; any other symbol (a float symbol
 * file, PCM audio) reads 0 against them, so its caller passes DSD_DIBIT_SLICER_ADAPTIVE whatever rf_mod is.
 */
uint8_t dmr_compute_reliability(const dsd_state* st, float sym, dsd_dibit_slicer slicer);
void soft_symbol_frame_begin(dsd_state* state);
uint16_t soft_symbol_to_viterbi_cost(float symbol, const dsd_state* state, int bit_position);
/**
 * \brief Viterbi cost (0 = strong bit 0, 65535 = strong bit 1) of one bit of a CQPSK symbol in the demodulator's
 * arg(z) * 4/pi domain, against the fixed levels +-1 and +-3 with the quadrant boundaries 0 and +-2. Bit 0 is the
 * sign (0 for the positive pair), bit 1 inner (0) against outer (1). TETRA decodes with it.
 */
uint16_t cqpsk_soft_symbol_to_viterbi_cost(float symbol, int bit_position);
/**
 * \brief Whether TETRA's symbols are read at the fixed pi/4-DQPSK levels: sliced at the quadrant boundaries by the
 * frame sync hunt and digitize(), and costed by cqpsk_soft_symbol_to_viterbi_cost() in the TETRA decoder. Only on
 * QPSK (rf_mod 1), where they are the CQPSK demodulator's arg(z) * 4/pi. Under another modulation (-fT -mc, not a
 * supported TETRA receiver) all three read them on the adaptive levels.
 */
int dsd_tetra_quadrant_levels(const dsd_state* state);
uint16_t gmsk_soft_symbol_to_viterbi_cost(float symbol, const dsd_state* state);
/**
 * \brief Confidence (0 = none, 255 = full) in a two-level symbol's hard bit, for soft-decision vocoder FEC.
 *
 * The distance from state->center over half the spacing of state->min and state->max, which the sync warm start
 * leaves on the two class means: 255 at a mean and beyond, 0 on the threshold. Polarity does not enter. Thresholds
 * with no usable spacing, and symbols replayed from a legacy symbol capture (which stores only the decided bit),
 * return 255, the weight a hard decision carries; a non-finite symbol or a NULL opts or state returns 0.
 */
uint8_t dsd_two_level_symbol_reliability(const dsd_opts* opts, const dsd_state* state, float symbol);
int digitize(const dsd_opts* opts, dsd_state* state, float symbol);
void skipDibit(dsd_opts* opts, dsd_state* state, int count);

#ifdef __cplusplus
}
#endif
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_DIBIT_H_H */

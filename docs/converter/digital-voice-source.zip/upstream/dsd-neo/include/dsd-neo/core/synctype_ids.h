// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2025 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Named sync type IDs for self-documenting code.
 *
 * This header defines named constants for synctype/lastsynctype values used
 * throughout the decoder. Use these instead of magic numbers to make code
 * branches self-documenting and safer to modify.
 *
 * IMPORTANT: These numeric values must match the existing synctype assignments
 * in dsd_frame_sync.c. Do NOT change the numeric values - that would be a
 * behavioral change requiring extensive testing.
 *
 * Mapping source: src/dsp/dsd_frame_sync.c getFrameSync() comment block
 */
#ifndef DSD_SYNCTYPE_IDS_H
#define DSD_SYNCTYPE_IDS_H

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================================
 * P25 Phase 1 (FDMA C4FM)
 * ============================================================================ */
#define DSD_SYNC_P25P1_POS        0 /**< +P25 Phase 1 (non-inverted) */
#define DSD_SYNC_P25P1_NEG        1 /**< -P25 Phase 1 (inverted) */

/* ============================================================================
 * X2-TDMA
 * ============================================================================ */
#define DSD_SYNC_X2TDMA_DATA_POS  2 /**< +X2-TDMA data frame (non-inverted) */
#define DSD_SYNC_X2TDMA_VOICE_NEG 3 /**< -X2-TDMA voice frame (inverted) */
#define DSD_SYNC_X2TDMA_VOICE_POS 4 /**< +X2-TDMA voice frame (non-inverted) */
#define DSD_SYNC_X2TDMA_DATA_NEG  5 /**< -X2-TDMA data frame (inverted) */

/* ============================================================================
 * D-STAR
 * ============================================================================ */
#define DSD_SYNC_DSTAR_VOICE_POS  6  /**< +D-STAR voice */
#define DSD_SYNC_DSTAR_VOICE_NEG  7  /**< -D-STAR voice */
#define DSD_SYNC_DSTAR_HD_POS     18 /**< +D-STAR header */
#define DSD_SYNC_DSTAR_HD_NEG     19 /**< -D-STAR header */

/* ============================================================================
 * M17
 * ============================================================================ */
#define DSD_SYNC_M17_STR_POS      8   /**< +M17 stream frame (non-inverted) */
#define DSD_SYNC_M17_STR_NEG      9   /**< -M17 stream frame (inverted) */
#define DSD_SYNC_M17_LSF_POS      16  /**< +M17 link setup frame (non-inverted) */
#define DSD_SYNC_M17_LSF_NEG      17  /**< -M17 link setup frame (inverted) */
#define DSD_SYNC_M17_BRT_POS      76  /**< +M17 BERT frame (non-inverted) */
#define DSD_SYNC_M17_BRT_NEG      77  /**< -M17 BERT frame (inverted) */
#define DSD_SYNC_M17_PKT_POS      86  /**< +M17 packet frame (non-inverted) */
#define DSD_SYNC_M17_PKT_NEG      87  /**< -M17 packet frame (inverted) */
#define DSD_SYNC_M17_PRE_POS      98  /**< +M17 preamble (non-inverted) */
#define DSD_SYNC_M17_PRE_NEG      99  /**< -M17 preamble (inverted) */
#define DSD_SYNC_M17_EOT_POS      100 /**< +M17 end-of-transmission marker (non-inverted) */
#define DSD_SYNC_M17_EOT_NEG      101 /**< -M17 end-of-transmission marker (inverted) */

/* ============================================================================
 * DMR (Base Station)
 * ============================================================================ */
#define DSD_SYNC_DMR_BS_DATA_POS  10 /**< +DMR BS data frame (non-inverted) */
#define DSD_SYNC_DMR_BS_VOICE_NEG 11 /**< -DMR BS voice frame (inverted) */
#define DSD_SYNC_DMR_BS_VOICE_POS 12 /**< +DMR BS voice frame (non-inverted) */
#define DSD_SYNC_DMR_BS_DATA_NEG  13 /**< -DMR BS data frame (inverted) */

/* ============================================================================
 * DMR (Mobile Station / Repeater Control)
 * ============================================================================ */
#define DSD_SYNC_DMR_MS_VOICE     32 /**< DMR MS voice */
#define DSD_SYNC_DMR_MS_DATA      33 /**< DMR MS data */
#define DSD_SYNC_DMR_RC_DATA      34 /**< DMR RC (repeater control) data */

/* ============================================================================
 * ProVoice / EDACS
 * ============================================================================ */
#define DSD_SYNC_PROVOICE_POS     14 /**< +ProVoice (EDACS) */
#define DSD_SYNC_PROVOICE_NEG     15 /**< -ProVoice (EDACS) */
#define DSD_SYNC_EDACS_POS        37 /**< +EDACS */
#define DSD_SYNC_EDACS_NEG        38 /**< -EDACS */

/* ============================================================================
 * dPMR
 * ============================================================================ */
#define DSD_SYNC_DPMR_FS1_POS     20 /**< +dPMR frame sync 1 */
#define DSD_SYNC_DPMR_FS2_POS     21 /**< +dPMR frame sync 2 */
#define DSD_SYNC_DPMR_FS3_POS     22 /**< +dPMR frame sync 3 */
#define DSD_SYNC_DPMR_FS4_POS     23 /**< +dPMR frame sync 4 */
#define DSD_SYNC_DPMR_FS1_NEG     24 /**< -dPMR frame sync 1 */
#define DSD_SYNC_DPMR_FS2_NEG     25 /**< -dPMR frame sync 2 */
#define DSD_SYNC_DPMR_FS3_NEG     26 /**< -dPMR frame sync 3 */
#define DSD_SYNC_DPMR_FS4_NEG     27 /**< -dPMR frame sync 4 */

/* ============================================================================
 * NXDN
 * ============================================================================ */
#define DSD_SYNC_NXDN_POS         28 /**< +NXDN (sync only) */
#define DSD_SYNC_NXDN_NEG         29 /**< -NXDN (sync only) */

/* ============================================================================
 * YSF (Yaesu System Fusion)
 * ============================================================================ */
#define DSD_SYNC_YSF_POS          30 /**< +YSF */
#define DSD_SYNC_YSF_NEG          31 /**< -YSF */

/* ============================================================================
 * P25 Phase 2 (TDMA CQPSK/H-DQPSK)
 * ============================================================================ */
#define DSD_SYNC_P25P2_POS        35 /**< +P25 Phase 2 (non-inverted) */
#define DSD_SYNC_P25P2_NEG        36 /**< -P25 Phase 2 (inverted) */

/* ============================================================================
 * Generic / Special
 * ============================================================================ */
#define DSD_SYNC_ANALOG           39   /**< Generic analog signal */
#define DSD_SYNC_DIGITAL          40   /**< Generic digital signal */
#define DSD_SYNC_NONE             (-1) /**< No sync / uninitialized */

/* ============================================================================
 * Protocol Classification Helper Macros
 *
 * These macros check whether a synctype belongs to a particular protocol
 * family. They are designed to replace scattered magic number comparisons
 * throughout the codebase.
 * ============================================================================ */

/** Check if synctype is P25 Phase 1 */
#define DSD_SYNC_IS_P25P1(s)      ((s) == DSD_SYNC_P25P1_POS || (s) == DSD_SYNC_P25P1_NEG)

/** Check if synctype is P25 Phase 2 */
#define DSD_SYNC_IS_P25P2(s)      ((s) == DSD_SYNC_P25P2_POS || (s) == DSD_SYNC_P25P2_NEG)

/** Check if synctype is any P25 (Phase 1 or Phase 2) */
#define DSD_SYNC_IS_P25(s)        (DSD_SYNC_IS_P25P1(s) || DSD_SYNC_IS_P25P2(s))

/** Check if synctype is X2-TDMA */
#define DSD_SYNC_IS_X2TDMA(s)     ((s) >= DSD_SYNC_X2TDMA_DATA_POS && (s) <= DSD_SYNC_X2TDMA_DATA_NEG)

/** Check if synctype is DMR Base Station */
#define DSD_SYNC_IS_DMR_BS(s)                                                                                          \
    ((s) == DSD_SYNC_DMR_BS_DATA_POS || (s) == DSD_SYNC_DMR_BS_VOICE_NEG || (s) == DSD_SYNC_DMR_BS_VOICE_POS           \
     || (s) == DSD_SYNC_DMR_BS_DATA_NEG)

/** Check if synctype is DMR Mobile Station or Repeater Control */
#define DSD_SYNC_IS_DMR_MS(s)                                                                                          \
    ((s) == DSD_SYNC_DMR_MS_VOICE || (s) == DSD_SYNC_DMR_MS_DATA || (s) == DSD_SYNC_DMR_RC_DATA)

/** Check if synctype is any DMR */
#define DSD_SYNC_IS_DMR(s) (DSD_SYNC_IS_DMR_BS(s) || DSD_SYNC_IS_DMR_MS(s))

/** Check if synctype is D-STAR (voice or header) */
#define DSD_SYNC_IS_DSTAR(s)                                                                                           \
    ((s) == DSD_SYNC_DSTAR_VOICE_POS || (s) == DSD_SYNC_DSTAR_VOICE_NEG || (s) == DSD_SYNC_DSTAR_HD_POS                \
     || (s) == DSD_SYNC_DSTAR_HD_NEG)

/** Check if synctype is any M17 */
#define DSD_SYNC_IS_M17(s)                                                                                             \
    ((s) == DSD_SYNC_M17_STR_POS || (s) == DSD_SYNC_M17_STR_NEG || (s) == DSD_SYNC_M17_LSF_POS                         \
     || (s) == DSD_SYNC_M17_LSF_NEG || (s) == DSD_SYNC_M17_BRT_POS || (s) == DSD_SYNC_M17_BRT_NEG                      \
     || (s) == DSD_SYNC_M17_PKT_POS || (s) == DSD_SYNC_M17_PKT_NEG || (s) == DSD_SYNC_M17_PRE_POS                      \
     || (s) == DSD_SYNC_M17_PRE_NEG || (s) == DSD_SYNC_M17_EOT_POS || (s) == DSD_SYNC_M17_EOT_NEG)

/** Check if synctype is NXDN */
#define DSD_SYNC_IS_NXDN(s)       ((s) == DSD_SYNC_NXDN_POS || (s) == DSD_SYNC_NXDN_NEG)

/** Check if synctype is YSF */
#define DSD_SYNC_IS_YSF(s)        ((s) == DSD_SYNC_YSF_POS || (s) == DSD_SYNC_YSF_NEG)

/** Check if synctype is dPMR */
#define DSD_SYNC_IS_DPMR(s)       ((s) >= DSD_SYNC_DPMR_FS1_POS && (s) <= DSD_SYNC_DPMR_FS4_NEG)

/** Check if synctype is ProVoice */
#define DSD_SYNC_IS_PROVOICE(s)   ((s) == DSD_SYNC_PROVOICE_POS || (s) == DSD_SYNC_PROVOICE_NEG)

/** Check if synctype is EDACS */
#define DSD_SYNC_IS_EDACS_ONLY(s) ((s) == DSD_SYNC_EDACS_POS || (s) == DSD_SYNC_EDACS_NEG)

/** Check if synctype is EDACS/ProVoice */
#define DSD_SYNC_IS_EDACS(s)      (DSD_SYNC_IS_PROVOICE(s) || DSD_SYNC_IS_EDACS_ONLY(s))

/* ============================================================================
 * TETRA
 * ============================================================================ */
#define DSD_SYNC_TETRA_NDB_POS    41 /**< +TETRA Normal Downlink Burst (non-inverted) */
#define DSD_SYNC_TETRA_NDB_NEG    42 /**< -TETRA Normal Downlink Burst (inverted) */
#define DSD_SYNC_TETRA_SB_POS     43 /**< +TETRA Synchronisation Burst (non-inverted) */
#define DSD_SYNC_TETRA_SB_NEG     44 /**< -TETRA Synchronisation Burst (inverted) */

/** Check if synctype is TETRA */
#define DSD_SYNC_IS_TETRA(s)                                                                                           \
    ((s) == DSD_SYNC_TETRA_NDB_POS || (s) == DSD_SYNC_TETRA_NDB_NEG || (s) == DSD_SYNC_TETRA_SB_POS                    \
     || (s) == DSD_SYNC_TETRA_SB_NEG)

/**
 * Check if synctype belongs to a protocol the trunking layer can follow.
 *
 * Sync on one of these means a control channel is at least possible here, which
 * is what a control offering to hand the tuner to trunking needs to know. It is
 * not a promise that this particular carrier is a control channel — only the
 * decoded signalling says that — but the protocols left out (D-STAR, M17, YSF,
 * dPMR) have no trunking to follow at all, so offering it there would be a
 * control that does nothing. TETRA direct mode shares the trunked-mode sync
 * words, so its carriers are offered too; there the TETRA state machine finds
 * no control channel and follows nothing.
 */
#define DSD_SYNC_IS_TRUNKABLE(s)                                                                                       \
    (DSD_SYNC_IS_P25(s) || DSD_SYNC_IS_DMR(s) || DSD_SYNC_IS_NXDN(s) || DSD_SYNC_IS_EDACS(s) || DSD_SYNC_IS_X2TDMA(s)  \
     || DSD_SYNC_IS_TETRA(s))

/** Check if synctype is inverted (negative polarity) */
#define DSD_SYNC_IS_INVERTED(s)                                                                                        \
    ((s) == DSD_SYNC_P25P1_NEG || (s) == DSD_SYNC_X2TDMA_VOICE_NEG || (s) == DSD_SYNC_X2TDMA_DATA_NEG                  \
     || (s) == DSD_SYNC_DSTAR_VOICE_NEG || (s) == DSD_SYNC_DSTAR_HD_NEG || (s) == DSD_SYNC_M17_STR_NEG                 \
     || (s) == DSD_SYNC_M17_LSF_NEG || (s) == DSD_SYNC_M17_BRT_NEG || (s) == DSD_SYNC_M17_PKT_NEG                      \
     || (s) == DSD_SYNC_M17_PRE_NEG || (s) == DSD_SYNC_M17_EOT_NEG || (s) == DSD_SYNC_DMR_BS_VOICE_NEG                 \
     || (s) == DSD_SYNC_DMR_BS_DATA_NEG || (s) == DSD_SYNC_PROVOICE_NEG || (s) == DSD_SYNC_EDACS_NEG                   \
     || (s) == DSD_SYNC_NXDN_NEG || (s) == DSD_SYNC_YSF_NEG || (s) == DSD_SYNC_P25P2_NEG                               \
     || (s) == DSD_SYNC_DPMR_FS1_NEG || (s) == DSD_SYNC_DPMR_FS2_NEG || (s) == DSD_SYNC_DPMR_FS3_NEG                   \
     || (s) == DSD_SYNC_DPMR_FS4_NEG || (s) == DSD_SYNC_TETRA_NDB_NEG || (s) == DSD_SYNC_TETRA_SB_NEG)

/**
 * @brief The protocol family of sync type @p s (issue #800): one value per system type, so both polarities and both
 * phases or bursts of one system give one family. 1 P25, 2 DMR, 3 NXDN, 4 TETRA, 5 D-STAR, 6 M17, 7 EDACS and
 * ProVoice; any other sync type is its own family, 0x100 + @p s. The position feed's tracks and the History merge both
 * read it (dsd_position_protocol_family(), call_history_protocol_family()).
 */
static inline int
dsd_sync_protocol_family(int s) {
    if (DSD_SYNC_IS_P25(s)) {
        return 1;
    }
    if (DSD_SYNC_IS_DMR(s)) {
        return 2;
    }
    if (DSD_SYNC_IS_NXDN(s)) {
        return 3;
    }
    if (DSD_SYNC_IS_TETRA(s)) {
        return 4;
    }
    if (DSD_SYNC_IS_DSTAR(s)) {
        return 5;
    }
    if (DSD_SYNC_IS_M17(s)) {
        return 6;
    }
    if (DSD_SYNC_IS_EDACS(s)) {
        return 7;
    }
    return 0x100 + s;
}

/**
 * @brief The protocol class of sync type @p s (issue #800): the protocol family (dsd_sync_protocol_family()), except
 * that P25 Phase 1 (0x1001) and Phase 2 (0x1002) are two classes. Two receptions of different classes are never one
 * (dsd_position_same_reception()), and sender evidence never crosses classes (dsd_position_attribution_class()).
 */
static inline int
dsd_sync_protocol_class(int s) {
    if (DSD_SYNC_IS_P25P1(s)) {
        return 0x1001;
    }
    if (DSD_SYNC_IS_P25P2(s)) {
        return 0x1002;
    }
    return dsd_sync_protocol_family(s);
}

/* ============================================================================
 * Safe String Mapping Function
 *
 * Use this instead of direct SyncTypes[] array indexing to avoid out-of-bounds
 * access and NULL pointer dereferences.
 * ============================================================================ */

/**
 * @brief Convert a synctype value to a human-readable string.
 *
 * This function safely maps synctype values to descriptive strings, handling
 * both the standard range (0-44) covered by the base SyncTypes[] table and
 * extended M17 types (76-77, 86-87, 98-101).
 *
 * @param synctype The sync type value to convert.
 * @return A constant string describing the sync type, or "UNKNOWN" if the
 *         value is out of range or unrecognized.
 */
const char* dsd_synctype_to_string(int synctype);

#ifdef __cplusplus
}
#endif

#endif /* DSD_SYNCTYPE_IDS_H */

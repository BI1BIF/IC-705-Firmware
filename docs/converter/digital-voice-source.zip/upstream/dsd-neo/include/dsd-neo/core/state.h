// SPDX-License-Identifier: GPL-3.0-or-later
/*
 * Copyright (C) 2026 by arancormonk <180709949+arancormonk@users.noreply.github.com>
 */

/**
 * @file
 * @brief Core decoder state structure (`dsd_state`) and helper types.
 *
 * Hosts the full `dsd_state` definition so modules needing state fields
 * can include it directly.
 */

#ifndef DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H
#define DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H

#include <dsd-neo/platform/input_backlog.h>
#include <dsd-neo/platform/platform.h>

#include <dsd-neo/core/input_level.h>
#include <dsd-neo/core/opts_fwd.h>
#include <dsd-neo/core/p25_patch.h>
#include <dsd-neo/core/p25p2_playout.h>
#include <dsd-neo/core/position.h>
#include <dsd-neo/core/position_attribution.h>
#include <dsd-neo/core/receive_types.h>
#include <dsd-neo/core/state_ext.h>
#include <dsd-neo/core/state_fwd.h>

#include <stdint.h>
#include <time.h>

#include <dsd-neo/core/dibit.h>
#include <dsd-neo/core/dmr_key_map.h>
#include <dsd-neo/core/enc_lockout.h>
#include <dsd-neo/core/key_set.h>
#include <dsd-neo/core/received_identity.h>
#include <dsd-neo/core/tetra_publication.h>
#include <dsd-neo/core/trunk_scan_lists.h>

#include <dsd-neo/protocol/p25/p25_cc_candidates.h>
#include <dsd-neo/protocol/p25/p25_status_symbol.h>

/* Buffer size for a human-readable channel label. Sized to hold a trunk-scan
 * target id (dsd_trunk_scan_target.id[64]) unchanged; a channel-map CSV name is
 * truncated to 63 characters plus the terminator. */
#define DSD_CHANNEL_LABEL_SIZE 64

/* One avoided --trunk-scan target as the trunk-scan coordinator publishes it (issue #672), in target-list order: its
 * 1-based position in the list, its frequency, and its id and label columns ("" when the target has no label). The
 * list lives in dsd_state::trunk_scan_avoids (dsd_state_trunk_scan_avoids_set()). */
typedef struct dsd_trunk_scan_avoid_entry {
    uint32_t ordinal;
    uint32_t pad; /* explicit, so a byte copy carries no indeterminate padding */
    uint64_t frequency_hz;
    char id[DSD_CHANNEL_LABEL_SIZE];
    char label[DSD_CHANNEL_LABEL_SIZE];
} dsd_trunk_scan_avoid_entry;

/* One --trunk-scan target list as the coordinator publishes it (issue #697, dsd_state::trunk_scan_lists). */
typedef struct {
    char name[DSD_TRUNK_SCAN_LIST_NAME_SIZE]; /**< File name without folder and extension; "" past the last list */
    uint8_t enabled;                          /**< 1 = switched on: its targets are in the rotation */
    uint16_t targets;                         /**< Targets the list holds */
} dsd_trunk_scan_list_publication;

/* Exact sync-word hits a frame sync join rule looks back over (src/dsp/dsd_frame_sync.c). A rule that joins on hits a
 * frame apart has to remember every hit of the frames it looks back over, not only the latest: before a lock the
 * matcher reads every window of the payload too, and a real carrier's payload matches a short sign-sliced word several
 * times per frame (NXDN96 traffic gave about eight). Remembering only the latest hit let each of those overwrite the
 * frame sync word a frame back, and a transmission joined only when a frame happened to carry none. 64 entries cover
 * the two frames looked back over at that rate several times over. kind 0 marks an empty slot. */
#define DSD_SYNC_HIT_HISTORY_LEN 64

typedef struct {
    uint32_t symbolcnt[DSD_SYNC_HIT_HISTORY_LEN];
    uint8_t kind[DSD_SYNC_HIT_HISTORY_LEN];
    uint8_t next; /* the slot the next hit takes */
} dsd_sync_hit_history;

#ifdef __cplusplus
static_assert(DSD_SYNC_HIT_HISTORY_LEN <= 255, "dsd_sync_hit_history::next is a uint8_t slot index");
#else
_Static_assert(DSD_SYNC_HIT_HISTORY_LEN <= 255, "dsd_sync_hit_history::next is a uint8_t slot index");
#endif

static inline void
dsd_sync_hit_history_clear(dsd_sync_hit_history* hits) {
    for (int i = 0; i < DSD_SYNC_HIT_HISTORY_LEN; i++) {
        hits->kind[i] = 0U;
    }
    hits->next = 0U;
}

/* NXDN96 frame synchronization (src/dsp/dsd_frame_sync.c, NXDN TS 1-A 5.3): the frame sync word hits lately seen; the
 * lock a transmission keeps, timed from the last accepted FSW whose frame's LICH was good (lock_type 0 is no lock); the
 * FSW just accepted, waiting on its frame's LICH (pending_type 0 is none); and how many LICHs in a row passed their
 * parity but were rejected: a value no NXDN frame uses, or an inbound LICH on a trunked session. */
typedef struct {
    dsd_sync_hit_history hits;
    uint32_t lock_symbolcnt;
    uint32_t pending_symbolcnt;
    uint8_t lock_type;
    uint8_t pending_type;
    uint8_t lich_wrong;
} dsd_nxdn96_sync;

/* S1 (TS 1-A 5.3.2, Table 5.9-3): good-parity LICHs in a row that lose frame sync. The specification counts LICHs
 * naming another RF channel type; this counts the ones nxdn_frame() rejects with good parity
 * (DSD_NXDN96_LICH_WRONG). */
#define DSD_NXDN96_SYNC_LICH_WRONG_S1 5U

/* What an NXDN frame's LICH said, for the NXDN96 lock (dsd_nxdn96_sync_note_lich()). */
typedef enum {
    DSD_NXDN96_LICH_GOOD = 0,
    DSD_NXDN96_LICH_PARITY_ERROR = 1, /* says nothing either way (TS 1-A 5.3) */
    DSD_NXDN96_LICH_WRONG = 2,        /* parity good, but an unknown value or a trunked session's inbound LICH */
} dsd_nxdn96_lich_result;

static inline void
dsd_nxdn96_sync_clear(dsd_nxdn96_sync* sync) {
    dsd_sync_hit_history_clear(&sync->hits);
    sync->lock_symbolcnt = 0U;
    sync->pending_symbolcnt = 0U;
    sync->lock_type = 0U;
    sync->pending_type = 0U;
    sync->lich_wrong = 0U;
}

/* An accepted NXDN96 FSW's frame read its LICH, @p symbolcnt symbols into the stream. The LICH conditions of TS 1-A 5.3
 * apply only to a LICH whose parity holds: a good one makes the FSW the lock's new timing; one whose parity fails
 * changes nothing, so a real call's lock rides out the error and a noise accept never refreshes it; S1 good-parity
 * LICHs in a row that nxdn_frame() rejects (an unknown value, or inbound on a trunked session) drop the lock and the
 * hits. An FSW the LICH did not follow at
 * once (another frame read in between) is not this LICH's. */
static inline void
dsd_nxdn96_sync_note_lich(dsd_nxdn96_sync* sync, uint32_t symbolcnt, dsd_nxdn96_lich_result result) {
    const uint8_t type = sync->pending_type;
    sync->pending_type = 0U;
    if (type == 0U || (uint32_t)(symbolcnt - sync->pending_symbolcnt) > 32U) {
        return;
    }
    if (result == DSD_NXDN96_LICH_GOOD) {
        sync->lock_symbolcnt = sync->pending_symbolcnt;
        sync->lock_type = type;
        sync->lich_wrong = 0U;
    } else if (result == DSD_NXDN96_LICH_WRONG && ++sync->lich_wrong >= DSD_NXDN96_SYNC_LICH_WRONG_S1) {
        dsd_nxdn96_sync_clear(sync);
    }
}

/* The TETRA burst capture the frame sync hands to the TETRA decoder (dsd_state::tetra_sync). */
typedef struct {
    /* ─────────────────────────────────────────────────────────────────────────
     * TETRA NDB Block 1 capture
     *
     * The NDB sync scan window consumes Block 1 before processTetraFrame() is
     * called.  At TETRA sync detection the 108 hard dibits of Block 1 are saved
     * here from the scan buffer so the frame processor can decode both blocks.
     *
     * b1_valid:   1 when b1_dibuf holds a fresh capture, cleared
     *                   after processTetraFrame() consumes it.
     * polarity:   0 = normal (+TETRA), 1 = inverted (-TETRA): the
     *                     carrier's, which normal bursts are classified
     *                     and decoded with. Written by the decoder only:
     *                     from a synchronisation burst whose BSCH (or DSB
     *                     SCH/S) passed its CRC, and from a control uplink
     *                     burst whose SCH/HU passed its CRC.
     * nts2:        1 = this NDB matched training sequence 2.
     * cb:          1 = the frame sync locked a control uplink burst. Every
     *                     TETRA lock sets it; it stays for the burst's
     *                     publication (control uplink mode).
     * ───────────────────────────────────────────────────────────────────────── */
    uint8_t b1_dibuf[108];
    float b1_soft[108];
    uint8_t b1_valid;
    uint8_t b1_soft_valid;
    /* aach1_dibuf: the 7 hard dibits of a TMO downlink normal burst's AACH half 1, bb(1) to bb(14) right before its
     * training sequence (EN 300 392-2 table 9.7), captured with block 1.
     * aach1_valid: 1 when aach1_dibuf holds them; 0 for a burst with no AACH (uplink, direct mode). */
    uint8_t aach1_dibuf[7];
    uint8_t aach1_valid;
    uint8_t polarity;
    uint8_t nts2;
    /* How many 90° slicer steps to undo before FEC. 0 keeps the historical
     * mapping; 1..3 correct a Costas phase that still correlates the training
     * word but not against the unrotated pattern. */
    uint8_t phase_rot;
    uint8_t cb;

    /* sb1_dibuf: 60 hard dibits of the BSCH block captured from the
     * synchronisation burst (SB) scan window at SSB detection.
     * sb1_valid: 1 when sb1_dibuf holds a fresh capture. */
    uint8_t sb1_dibuf[60];
    float sb1_soft[60];
    uint8_t sb1_valid;
    uint8_t sb1_soft_valid;
    /* The polarity of the synchronisation burst in sb1_dibuf, 0 normal or 1 inverted, as its training sequence matched
     * it: the burst is decoded with it, and it becomes the carrier's (polarity) only once the burst is accepted. */
    uint8_t sb_polarity;
    /* Set by the decoder: 1 when block 1 sits directly against the training sequence (direct mode and the
     * uplink normal burst have no AACH), so the frame sync captures it from the right symbols. */
    uint8_t block1_follows_training;

    /* The first b2_lead_count dibits of block 2 (0 or 2), hard and soft, which the frame sync read past the training
     * sequence before it locked: on the uplink, normal training sequence 1 is also the middle of the control burst's
     * extended training sequence, so an uplink normal burst is told from a control burst only two symbols after its
     * training. The decoder takes them before it reads on; b2_lead_soft_valid is 0 when no soft values came with
     * them. Every TETRA lock sets the count. */
    uint8_t b2_lead_dibits[2];
    float b2_lead_soft[2];
    uint8_t b2_lead_count;
    uint8_t b2_lead_soft_valid;
} dsd_tetra_sync_capture;

/* Where every clear of the rolling dibit buffers (dibit_buf, dmr_payload_buf, dmr_soft_buf: initState(), noCarrier(),
 * an NXDN reset) and every wrap puts the write pointer: the buffer plus this many entries. What lies before it is the
 * clear's zeros or the dibits a wrap left, none of them the stream's latest, so a decoder that reads back from the
 * pointer has real dibits only for what was written since (dsd_state_rolling_dibits()). */
#define DSD_ROLLING_DIBIT_FLOOR             200

/* Dibits of frame-sync history a getFrameSync() call hands the next (dsd_frame_sync_history_carry). */
#define DSD_FRAME_SYNC_HISTORY_CARRY_DIBITS 128
/* Raw levels it hands on with them: the call's level window, at most this many. */
#define DSD_FRAME_SYNC_HISTORY_CARRY_LEVELS 48

/* The dibit history the frame sync's windows are built from, and the raw levels of its last symbols (the call's
 * level window, which the window's level estimate and the NXDN96 FSW's four-level reading read), as a getFrameSync()
 * call left them on a no-sync exit, the timeout after a matchless pass or the hunt budget's, with where the stream
 * was then. The next call starts from it when nothing came between: the symbol clock has not moved; neither the
 * clock's epoch, the input, the carrier count, the trunk tuning generation, the SPS hunt profile nor the modulation
 * changed; no tune off the decoder thread awaits reconciling; and no retune forgot the sync histories
 * (dsd_state_forget_sync_join_histories(), which the decoder thread's trunk retunes run: a tune through the trunk
 * tuning hooks, dsd_engine_rxid_trunk_tune(), and noCarrier's direct control-channel return; and so do every
 * off-thread tune applied, every carrier boundary, a typed scanner row that moved the receiver yet ends unlanded
 * included, and every acquisition reset) since the call began. The first symbol the next call reads is checked
 * again, for a stream flush its read found. A sync matcher that reads only its window, or reads forward from its
 * sync (TETRA, P25, NXDN, YSF, dPMR, D-STAR, M17, ProVoice, EDACS), then matches a frame that began before the exit
 * as one that did not; before, the new call started with no history, and a TETRA uplink burst whose training ended
 * fewer than its window's symbols into the call was never matched. The levels go with the dibits under the same
 * rules, so a window read on its levels (the NXDN96 FSW) is read whole. DMR and X2-TDMA decode their burst back from
 * the rolling dibit buffers, which the no-carrier reset clears, so they match only on a window the call read itself,
 * as before, or one a dropped P25p1 candidate's carry brought while the buffers still hold it (own_symbols). Every
 * other exit, a sync above all, drops it. Written and read by the frame sync alone
 * (src/dsp/dsd_frame_sync.c), and dropped by dsd_state_forget_sync_join_histories(); decoder-thread private. */
typedef struct {
    char dibits[DSD_FRAME_SYNC_HISTORY_CARRY_DIBITS]; /* the history ring, '0'..'3' */
    int head;                                         /* the next slot to write */
    int count;                                        /* dibits held, up to the capacity */
    /* The raw levels of the last level_count symbols, oldest first: the level window's, unwrapped. */
    float levels[DSD_FRAME_SYNC_HISTORY_CARRY_LEVELS];
    int level_count;
    uint64_t symbol_clock; /* dsd_state::symbol_clock at the exit */
    uint32_t symbol_clock_epoch;
    uint32_t symbol_clock_input;
    uint32_t carrier_seq;
    uint64_t tune_generation; /* dsd_trunk_tuning_generation() when the history began */
    int sps_hunt_idx;
    int rf_mod;
    /* Where in its matchless pass the next call starts (getFrameSync()'s pass position): 0 after a no-sync exit, which
       ends a pass; after a dropped P25p1 candidate the pass the candidate interrupted, with its symbols, so the hunt's
       no-sync timing runs as if the candidate had never been taken. A break the next call's first read finds drops it
       with the history: that call starts a pass of its own. */
    int pass_symbols;
    /* How many of the last carried dibits the rolling dibit buffers hold as the stream's (dibit_buf, dmr_payload_buf,
       which DMR and X2-TDMA decode a burst back from): 0 after a no-sync exit, whose no-carrier reset clears them;
       after a dropped P25p1 candidate all of them, the word's written by the hunt and the NID's by its read. The next
       call counts no more than the buffers hold written since their last clear. */
    int own_symbols;
    /* Bumped by every drop (dsd_state_forget_sync_join_histories()); a call that saw it move keeps nothing. The P25
       Phase 1 carrier NAC (dsd_p25p1_carrier_nac) reads it too, as the same stream boundary. */
    uint32_t drops;
    uint8_t valid;
} dsd_frame_sync_history_carry;

/* The NAC the P25 Phase 1 NIDs on the carrier being received established, and a NAC change held for corroboration
 * (p25p1_nid_verdict_classify(), src/protocol/p25/phase1/p25p1_nid_verdict.c). Established by an unborrowed NID naming
 * a usable NAC (not 0x000 or 0xFFF), it holds only on the stream it was named on: the carrier count, the accepted trunk
 * tuning generation and the sync history drop count it was taken under must all still be current, so a carrier
 * boundary, an accepted tune (a control channel return, which is no carrier boundary, included), a trunk scan visit
 * and every other sync history drop end it. dsd_state_forget_p25p1_carrier_nac() also ends it at the carrier codes'
 * forget (the no-carrier pass, a carrier boundary, a voice channel tune), a trunk scan target's restore and an input
 * interruption (the engine loop that takes it up, and a NID it cut). Decoder-thread private. */
typedef struct {
    uint64_t tune_generation;    /* dsd_trunk_tuning_generation() when established */
    uint32_t carrier_seq;        /* dsd_state::carrier_seq when established */
    uint32_t sync_history_drops; /* dsd_frame_sync_history_carry::drops when established */
    uint16_t nac;                /* the established NAC, when valid */
    uint16_t candidate_nac;      /* another NAC a costly NID named, when candidate_valid */
    uint8_t valid;
    uint8_t candidate_valid;
} dsd_p25p1_carrier_nac;

/* Where a P25 sync word (Phase 1 or Phase 2) stood on the stream, and the stream it was read on: the symbol clock at
 * the word's first dibit, what that clock is measured in, and the receiver's setup (the history carry's terms,
 * dsd_frame_sync_history_carry). */
typedef struct dsd_p25_sync_context {
    uint64_t sync_clock;      /* dsd_state::symbol_clock of the sync word's first dibit */
    uint64_t tune_generation; /* dsd_trunk_tuning_generation() */
    uint32_t symbol_clock_epoch;
    uint32_t symbol_clock_input;
    uint32_t carrier_seq;
    uint32_t sync_history_drops; /* dsd_frame_sync_history_carry::drops */
    int sps_hunt_idx;
    int rf_mod;
    uint8_t map_idx;  /* the CQPSK dibit map the word matched under (dsd_state::p25_cqpsk_dibit_map_idx) */
    uint8_t inverted; /* 1 for the inverted word (DSD_SYNC_P25P1_NEG, DSD_SYNC_P25P2_NEG) */
} dsd_p25_sync_context;

/* Where a sync word the hunt read lies in the matched-filter seam's raw history (dsd_matched_filter_seam::raw), taken
 * as the word was accepted so that it can be measured once more samples have come in (dsd_symbol_mark_p25p1_sync_anchor()
 * in <dsd-neo/dsp/symbol_anchor.h>). Decoder-thread private. */
typedef struct dsd_matched_filter_seam_mark {
    uint64_t symbol_clock; /* dsd_state::symbol_clock as the word's window ended */
    int raw_head;          /* dsd_matched_filter_seam::raw_head and raw_count then */
    int raw_count;
    int last_back; /* samples behind the newest then of the word's last measured centre, a filter's group delay in */
    int sps;       /* the span the grid read the word at */
    uint8_t valid;
} dsd_matched_filter_seam_mark;

/* The P25 Phase 1 sync anchor: where the data unit after the last validated one starts (src/dsp/
 * frame_sync_p25p1_anchor.c). On a continuous outbound carrier every data unit is padded to whole 36-dibit segments
 * and the next one's sync starts where it ends (TIA-102.BAAA-A 8.2), so the hunt, which matches sync words exactly,
 * may there accept one within DSD_P25P1_TOLERANT_SYNC_MAX_BIT_ERRORS bit errors on the RTL CQPSK 4800/4 path, or
 * DSD_P25P1_C4FM_ANCHORED_MAX_SIGN_ERRORS sign errors on the C4FM chain's 4800/4 hunt.
 * Installed when a frame validates (its NID decoded unborrowed, within the BCH radius, naming a usable NAC and a
 * defined DUID, accepted by the NAC rule), from the sync-time context the frame sync captured when it accepted that
 * frame's sync, and only when the stream is still that one. Spent by the first window the hunt reaches at or past the
 * expected position and by any accepted sync; forgotten by a change of anything in the context, a pending off-thread
 * tune, a P25p1 chain step, an acquisition reset and the no-carrier pass (dsd_state_forget_p25p1_sync_anchor()).
 * Written and read by the frame sync, which the P25p1 dispatcher tells what each frame was
 * (dsd_frame_sync_p25p1_frame_decoded()). Decoder-thread private. */
typedef struct {
    dsd_p25_sync_context anchor; /* the validated frame's sync */
    uint64_t expected_clock;     /* anchor.sync_clock plus the frame's length: where the next sync starts */
    uint16_t nac;                /* the NAC the validated frame's NID named */
    uint8_t valid;
    /* The sync of the frame being decoded, as the frame sync accepted it, until its dispatcher reports the frame. */
    dsd_p25_sync_context frame;
    uint16_t frame_nac;  /* an anchored sync's: the NAC its frame's NID must name, the anchor's */
    uint8_t frame_valid; /* captured, with no off-thread tune pending */
    /* How the sync was accepted (dsd_p25p1_sync_kind): stands until the frame is reported, whatever else goes. */
    uint8_t frame_kind;
    /* What its sync word was off by: bits on the CQPSK chain, signs on the C4FM chain, 0 for an exact match. */
    uint8_t sync_bit_errors;
    /* A word within a tolerance on the C4FM chain, read with no recording armed: where it lies in the seam's raw
       history, measured only once its NID passed (dsd_frame_sync_p25p1_candidate_validated()). */
    dsd_matched_filter_seam_mark frame_word;
    /* Diagnostics, never reset: tolerant syncs the frame sync accepted (at the anchor, and hunt-wide on C4FM), and
       those whose NID passed the dispatcher's strict check (counted when the dispatcher reports the frame). */
    uint32_t tolerant_syncs;
    uint32_t tolerant_frames;
    uint32_t acquisition_syncs;
    uint32_t acquisition_frames;
    /* The last P25p1 frame reported was dropped behind a tolerant word (dsd_frame_sync_p25p1_candidate_rejected()),
       until the next accepted sync of any protocol: it synced nothing the engine may count
       (dsd_state_p25p1_frame_dropped()). */
    uint8_t frame_dropped;
} dsd_p25p1_sync_anchor;

/* What a P25 Phase 1 sync word the hunt accepted within a tolerance (on either chain) changed before its NID could say
 * whether it was a word at all, as it stood before the accept (frame_sync_accept_p25p1()): the slicer levels its lock
 * and warm start rewrote (the NID is read on them, a calibration on trial), whether the warm start set them (which
 * decides whether the frame holds them) and the crossing it dropped, the carrier flag, offset and lastsynctype, the
 * P25p1 frame span that stands NXDN96 and M17 down, the DMR slot 2 burst, ALG ID and stereo state and the frame type
 * label the accept writes, the CQPSK dibit map the try set, the frame NAC the NID read cleared, and the sync type the
 * engine then records (dsd_state::synctype, which the symbol reader's C4FM window and the dibit slicer read). Put back
 * when the dispatcher drops the frame on the stream it was accepted on (dsd_frame_sync_p25p1_candidate_rejected()); a
 * frame that validates keeps what the accept wrote. The hunt's pass position at the accept goes with it, for the hunt
 * to go on from. Written and read by the frame sync; decoder-thread private. */
typedef struct {
    float max;
    float min;
    float center;
    float umid;
    float lmid;
    float maxref;
    float minref;
    float maxbuf[1024]; /* dsd_state::maxbuf, minbuf, midx: the windows the warm start fills */
    float minbuf[1024];
    int midx;
    int jitter;
    int carrier;
    int offset;
    int lastsynctype;
    int synctype; /* dsd_state::synctype: the engine's last sync, which it overwrites with the candidate's */
    unsigned int dmrburstR;
    int payload_algidR;
    short int dmr_stereo;
    char ftype[16];
    uint32_t c4fm_frame_symbolcnt;
    int pass_symbols; /* the hunt's pass position at the word's last symbol (dsd_frame_sync_history_carry) */
    uint8_t c4fm_frame_valid;
    uint8_t c4fm_sync_levels; /* dsd_state::p25_p1_c4fm_sync_levels */
    uint8_t p25_cqpsk_dibit_map_idx;
    uint8_t p25_frame_nac_valid;
    uint8_t valid; /* held for the frame being decoded */
} dsd_p25p1_sync_candidate;

/* What a P25 Phase 2 sync word the hunt accepted within a tolerance changed before the window's verdict could say
 * whether it was a window at all, as it stood before the accept (frame_sync_accept_p25p2()): the lock's carrier flag,
 * offset and slicer extremes, the references processFrame() derives from them, lastsynctype, the polarity it wrote
 * (dsd_opts::inverted_p2), the CQPSK dibit map the try set and the sync type the engine then records
 * (dsd_state::synctype). Put back when processP2() rejects the window on the stream it was accepted on
 * (dsd_frame_sync_p25p2_window_dropped()); a window that passes keeps what the accept wrote. Written and read by the
 * frame sync; decoder-thread private. */
typedef struct {
    float max;
    float min;
    float maxref;
    float minref;
    int carrier;
    int offset;
    int lastsynctype;
    int synctype; /* dsd_state::synctype: the engine's last sync, which it overwrites with the window's */
    int inverted_p2;
    uint8_t p25_cqpsk_dibit_map_idx;
    uint8_t valid;
} dsd_p25p2_sync_candidate;

/* The P25 Phase 2 sync anchor: where the window after the last one a received I-ISCH placed starts (src/dsp/
 * frame_sync_p25p2_anchor.c). processP2() reads four timeslots after each 20-dibit sync, and on a continuous carrier the
 * next window's sync (an S-ISCH) ends 20 dibits after it, so the hunt, which matches sync words exactly, may there
 * accept one within DSD_P25P2_TOLERANT_SYNC_MAX_BIT_ERRORS bit errors, on the RTL CQPSK 6000/4 path only. Installed by
 * a window (exact or tolerant) whose own I-ISCH decoded to the channel and location its start predicts and no ISCH of
 * which contradicted it, from the sync-time context the frame sync captured when it accepted that window's sync, and
 * only when the stream is still that one and the receiver did not retune while the window was dispatched. Spent by the
 * first window the hunt reaches at or past the expected position and by any accepted sync; forgotten by a change of
 * anything in the context, a pending off-thread tune, an acquisition reset, the no-carrier pass and a trunk scan
 * target's restore (dsd_state_forget_p25p2_sync_anchor()). A window opened by a tolerant sync dispatches only when the
 * window verdict passes (p25p2_tolerant_window_verdict()). Written and read by the frame sync, which processP2() tells
 * what each window was (dsd_frame_sync_p25p2_window_decoded()). Decoder-thread private. */
typedef struct {
    dsd_p25_sync_context anchor; /* the validated window's sync */
    uint64_t expected_clock;     /* anchor.sync_clock plus the sync and the window: where the next sync starts */
    uint8_t start;               /* the superframe timeslot (0-11) the validated window started at */
    uint8_t valid;
    /* The sync of the window being decoded, as the frame sync accepted it, until processP2() reports the window. */
    dsd_p25_sync_context frame;
    uint8_t frame_start;    /* a tolerant sync's: the superframe timeslot its window must start at */
    uint8_t frame_valid;    /* captured, with no off-thread tune pending */
    uint8_t frame_tolerant; /* accepted within the tolerance: stands until the window is reported, whatever else goes */
    uint8_t sync_bit_errors; /* bits its sync word was off by: 0 for an exact (normal, inverted, rotated) match */
    /* Diagnostics, never reset: tolerant syncs the frame sync accepted, and the windows behind them whose verdict
       passed (counted when processP2() reports the window). */
    uint32_t tolerant_syncs;
    uint32_t tolerant_windows;
} dsd_p25p2_sync_anchor;

/* The highest frequency, in Hz, a trunking channel is stored or tuned at, the same on every platform: the largest value
 * a 32-bit long holds (long is 32-bit on Windows, and trunk frequencies are stored as long), which also fits the
 * uint32_t tuner path. No trunking band comes near it. A channel-map row, an over-the-air channel computation or a
 * cached control channel past it is refused rather than stored or tuned. */
#define DSD_TRUNK_FREQ_MAX_HZ 2147483647L

enum DSD_ATTR_PACKED {
    DSD_P25_MAC_FRAGMENT_MAX_OCTETS = 256,
    DSD_TRUNK_CHAN_MAP_SIZE = 0xFFFF,
    /* Scan-list slots stored inline in dsd_state. Protocol fixed-slot writers raw-index
     * trunk_lcn_freq[] below this; longer lists spill into the trunk_lcn_freq_ext heap
     * tail behind dsd_state_trunk_lcn_slot(). */
    DSD_TRUNK_LCN_EMBEDDED = 26,
    DSD_VERTEX_KS_MAP_MAX = 64,
    DSD_RTL_SYMBOL_CACHE_CAP = 512,
};

/** Authoritative per-slot P25 voice crypto classification. */
typedef enum DSD_ATTR_PACKED {
    DSD_P25_CRYPTO_UNKNOWN = 0,
    DSD_P25_CRYPTO_CLEAR = 1,
    DSD_P25_CRYPTO_ENCRYPTED_PENDING = 2,
    DSD_P25_CRYPTO_DECRYPTABLE = 3,
    DSD_P25_CRYPTO_BLOCKED = 4,
} dsd_p25_crypto_state;

/** Phase 1 traffic crypto tuple awaiting corroboration against clear service options. */
typedef struct {
    uint16_t keyid;
    uint8_t algid;
    uint8_t active;
} dsd_p25_p1_crypto_conflict_state;

/** Phase 2 per-slot ESS crypto tuple awaiting corroboration against clear service context. */
typedef struct {
    uint16_t keyid;
    uint8_t algid;
    uint8_t active;
} dsd_p25_p2_crypto_conflict_state;

/** Phase 1 carrier/call epoch whose post-lockout ESS repeats may be ignored. */
typedef struct {
    uint64_t call_epoch;
    int64_t frequency_hz;
    double recorded_m;
    uint32_t grant_generation;
    uint8_t valid;
} dsd_p25_p1_lockout_epoch_state;

/** Phase 2 ESS identity change held until boundary voice has drained. */
typedef struct {
    uint64_t mi;
    uint16_t keyid;
    uint8_t algid;
    uint8_t pending;
    /* The staged ESS decoded without soft erasures, so its RS parity checked it (p25_crypto_resolve_checked()). */
    uint8_t parity_checked;
} dsd_p25_p2_rekey_state;

typedef struct {
    uint8_t active;
    uint8_t opcode;
    uint8_t data_len;
    uint8_t collected;
    uint8_t data[DSD_P25_MAC_FRAGMENT_MAX_OCTETS];
} p25_mac_fragment_state_t;

/** Capacity of the P25 affiliation (registered unit) table, dsd_state::p25_aff_rid. */
#define P25_AFF_MAX 256

/**
 * Who an affiliation-table entry's local address was assigned to: the home identity (WACN, System ID, unit ID: the
 * SUID) a Unit Registration Response named, and the serving system it was heard on. A registration away from a unit's
 * home system gives it a local address unlike its unit ID (TIA-102.AABC-D §2.3.27); the deregistration names the
 * SUID, never that address. home_id 0 means the entry has no association (no unit has ID 0).
 */
typedef struct {
    uint32_t home_wacn;
    uint32_t home_id;
    uint32_t serving_wacn;
    uint16_t home_sys;
    uint16_t serving_sys;
} p25_aff_assoc_t;

/** Capacity of one Motorola alias assembly, in bit entries: the stored header layout, then the blocks by number. */
#define P25_APX_ALIAS_STORE_BITS  (24 * 128)
/** Longest received header kept for the benign-repeat compare (the Phase 2 MAC header; Phase 1 uses 72). */
#define P25_APX_ALIAS_HEADER_BITS 136

/**
 * One slot's Motorola (MFID 0x90) talker alias assembly. It owns its storage, so nothing that clears the shared
 * dmr_pdu_sf scratch (an LCW Call Termination or Talker EOT, the DMR and Harris assemblers) can wipe it. Blocks are
 * stored by number; the assembly completes once blocks 1..block_count are all present. It is bound to the call epoch
 * and tuning generation its header arrived in and survives that epoch's ACTIVE -> ENDED (Motorola sends the alias in
 * hangtime): a block from another epoch or carrier abandons it, and a header restarts it unless it repeats the one in
 * progress bit for bit within the same epoch and generation.
 */
typedef struct {
    uint8_t valid;
    uint8_t phase; /* 1 or 2: the header layout held in bits[] */
    uint8_t sequence;
    uint8_t block_count;
    uint8_t blocks_seen[32]; /* bit n set when block n (1..255) is stored */
    uint16_t header_len;     /* bits of header[] in use */
    uint64_t epoch;          /* call epoch the header arrived in; 0 when the slot had none */
    uint64_t tune_generation;
    uint8_t header[P25_APX_ALIAS_HEADER_BITS];
    uint8_t bits[P25_APX_ALIAS_STORE_BITS];
} p25_apx_alias_rx_state_t;

/**
 * The P25 Phase 1 L3Harris GPS update Part A (MFID $A4 LCO 42 or 44, TIA-102.AABF-D-1 §7.3.35) waiting for its Part B
 * (issue #800). It owns its storage, so a talker alias between the two halves cannot wipe it (spec N3). It pairs only
 * with the Part B of its own parity (42 with 43, 44 with 45; D14) heard on the same call epoch (never outside a call)
 * and source within the pairing window on the decode clock, and the report keeps the reception it began on
 * (@c origin). Any newer Part A replaces it; a Part B of the other parity, its use, another call epoch or source and
 * expiry clear it. Epochs are never given out twice on one state (dsd_state::call_epoch_floor), so one left by another
 * engine run matches no call of the next.
 */
typedef struct {
    uint8_t valid;
    uint8_t even;            /* 1 for LCO 44 (even-numbered update), 0 for LCO 42 */
    uint8_t hard;            /* its link control passed a hard RS decode (not a soft-erasure retry) */
    uint8_t octets[7];       /* Part A octets 2-8 */
    uint32_t source;         /* the bound call's source; 0 when none */
    uint64_t epoch;          /* the bound call's epoch; 0 when no call was open */
    uint64_t stored_mono_ms; /* dsd_decode_now_mono_ms() when stored */
    dsd_position_origin origin;
} p25_p1_harris_gps_part_a;

/** Fragments in one Kenwood NXDN talker alias, and the text octets they carry (the last two octets of fragment 4 are
 * not text). */
#define NXDN_ALIAS_FRAGMENTS  4
#define NXDN_ALIAS_TEXT_BYTES 14

/**
 * The Kenwood NXDN talker alias (PROP_FORM, MFID 0x68, 0x8204) being assembled: four fragments of four octets, stored
 * by number. It is bound to the slot, call epoch, call source and tuning generation its first stored fragment arrived
 * in; a fragment under any other binding, a fragment count other than four, or a fragment that differs from the one
 * already stored under its number restarts it. Only a complete assembly is ever published (nxdn_alias_complete()).
 */
typedef struct nxdn_alias_assembly {
    uint8_t seen_mask; /* bit n - 1 set when fragment n is stored; 0: no assembly */
    uint8_t slot;
    uint32_t source; /* ota_source_id of the bound call; 0 when no call was open */
    uint64_t epoch;  /* call epoch the assembly is bound to; 0 when no call was open */
    uint64_t tune_generation;
    uint8_t fragment[NXDN_ALIAS_FRAGMENTS][4];
} nxdn_alias_assembly;

/**
 * What of one slot's DMR talker alias (TS 102 361-2 clause 7.2.18) has arrived, and the call it belongs to: the
 * header and blocks 1 to 3, each with a checked embedded LC checksum, while the slot's call was the ACTIVE one with
 * this epoch and source on this tuning generation. A header of another format, length, text or binding restarts it; a
 * block under another binding, or one that differs from the block already held, ends it until the next header. The
 * alias is learned (dsd_alias_learn_radio()) once, when the header and every block up to the one decoded arrived and
 * the text visibly ended inside them: padding follows it, all three blocks are there, or it exactly fills them and
 * the Data Length agrees (dmr_talker_alias_lc_decode(); the Data Length alone is not trusted for where the text ends).
 * The pieces live in dmr_pdu_sf, which other decoders clear and reuse (dmr_reset_blocks(), the data assembler, NXDN
 * and P25 on slot 0), so each piece's bits are kept here as they were stored: a learn whose pieces no longer hold them
 * ends the assembly instead, and a block is shown and written into the history row only while the header and every
 * block up to it arrived here and still hold what arrived (else the last whole alias stays).
 */
typedef struct dmr_talker_alias_assembly {
    uint8_t mask;    /* bit 0 the header, bit n block n; 0: no assembly */
    uint8_t learned; /* the complete alias of this assembly was learned */
    uint32_t source; /* ota_source_id of the ACTIVE call the header arrived in; 0 when none was */
    uint64_t epoch;
    uint64_t tune_generation;
    uint8_t piece[4][7]; /* each piece's bits as stored (header 48 or 49, a block 56), packed MSB first */
} dmr_talker_alias_assembly;

/**
 * The M17 LSF being assembled from LICH chunks (src/protocol/m17/m17.c, issue #800): which chunks it holds (bit n: chunk
 * n of six) and what its first chunk was heard under -- the transmission (the slot 0 ACTIVE M17 call's epoch, 0 none;
 * an LSF frame, a packet frame, an EOT and the carrier's end begin another and empty the assembly), whether the
 * transmission was confirmed (dsd_state::m17_confirmed) and the reception (dsd_position_origin_capture()). A chunk heard
 * when any of them has changed resets the assembly; only one holding all six chunks under one binding, its CRC passed,
 * names a call or carries a position.
 */
typedef struct m17_lich_assembly {
    uint8_t held;
    uint8_t confirmed;
    uint64_t call_epoch;
    dsd_position_origin origin;
} m17_lich_assembly;

typedef struct {
    uint8_t mask;
    char last_alias[40];
    char last_saved_alias[40];
    uint32_t src;
    uint32_t tg;
    uint64_t epoch; //call epoch that was ACTIVE when block 0 keyed this fragment set; 0 when none was
    uint8_t fragment[4][8];
} p25_l3h_alias_phase1_state_t;

typedef enum DSD_ATTR_PACKED {
    DSD_EVENT_SEVERITY_UNKNOWN = 0,
    DSD_EVENT_SEVERITY_DEBUG = 1,
    DSD_EVENT_SEVERITY_INFO = 2,
    DSD_EVENT_SEVERITY_WARNING = 3,
    DSD_EVENT_SEVERITY_ERROR = 4
} dsd_event_severity;

typedef enum DSD_ATTR_PACKED {
    DSD_EVENT_CATEGORY_UNKNOWN = 0,
    DSD_EVENT_CATEGORY_STATUS = 1,
    DSD_EVENT_CATEGORY_VOICE = 2,
    DSD_EVENT_CATEGORY_DATA = 3,
    DSD_EVENT_CATEGORY_CONTROL = 4,
    DSD_EVENT_CATEGORY_SYSTEM = 5
} dsd_event_category;

/**
 * The admitted position report a history row carries (issue #800), set together with the row's gps_s text by the
 * position writers in <dsd-neo/core/events.h> and only from a report dsd_position_admit() admitted. Laid out without
 * padding, so a row stays comparable byte for byte.
 *
 * scope and identity_freq_hz are the row's sender identity (D7, the track key): the admitted report's sender scope
 * and identity discriminator, or, on a data notice without a position, the scope of the reception the notice was heard
 * on, stamped at emit. They may be set while valid is 0. Everything else is meaningful only while valid is 1. Where the
 * row was heard is Event_History::rx_scope.
 */
typedef struct {
    uint64_t proc_instance;   /**< dsd_position_fix::proc_instance of the report */
    uint64_t rev;             /**< dsd_position_fix::rev; the newest rev wins wherever two positions meet */
    int64_t rx_time_s;        /**< dsd_position_fix::rx_time_s (display only; never orders) */
    int64_t identity_freq_hz; /**< dsd_position_fix::identity_freq_hz: the discriminator of a P25 NAC scope, else 0 */
    int32_t lat_e7;           /**< degrees x 1e7, north positive */
    int32_t lon_e7;           /**< degrees x 1e7, east positive */
    uint32_t err_m;           /**< metres; DSD_POSITION_ERR_UNKNOWN (0) */
    uint16_t flags;           /**< dsd_position_flag */
    uint8_t valid;            /**< 1 while the row carries an admitted position */
    uint8_t rx_clock;         /**< dsd_position_fix::rx_clock */
    uint8_t kind;             /**< dsd_position_kind */
    uint8_t anonymous;        /**< 1 when the report names no source a row could check (hashed, unverified, or no ID
                                   and no callsign): it stays only while the row names no source either */
    uint8_t pad[2];           /**< always 0 */
    dsd_position_scope scope; /**< the sender scope (see above); DSD_POS_SCOPE_NONE when none was stamped */
} dsd_event_pos;

/**
 * Where a history row's call or notice was heard (issue #800, D7): the reception's scope (the alias scope, else a
 * feed-only EDACS, control-channel or tuned-frequency scope; dsd_position_scope_from_rxid()), its identity
 * discriminator (the tuned frequency for a P25 NAC scope, else 0), the tuned frequency it was read with and the
 * reception generation it was read under. A
 * call row takes it by the rule its site follows (Event_History::site_id: the live record only while the call is
 * active on the carrier it began on, the record as the call ended once it has), pinned once resolved; a data notice at
 * emit. A position lands on a row, or merges into it, only under the reception rule (dsd_position_same_reception()):
 * both scopes known and equal on one carrier, or the same generation with nothing that says otherwise; an unknown side
 * never matches across generations. Laid out without padding.
 */
typedef struct {
    int64_t identity_freq_hz; /**< the tuned frequency for a DSD_POS_SCOPE_P25_NAC scope, else 0 */
    /** The tuned frequency the reception was read with, whatever its scope (0 when unknown): two carriers are two
     * receptions, also of one system whose scope names no carrier. */
    int64_t tuned_hz;
    /** The reception generation the reception was read under (dsd_state_reception_generation(): the record's epoch,
     * the retunes and the P25 phase changes). */
    uint64_t rx_gen;
    dsd_position_scope scope; /**< DSD_POS_SCOPE_NONE when none is known */
    uint8_t resolved;         /**< 1 once the row's reception was read (a none scope included); pinned from then */
    uint8_t epoch_known;      /**< 1 when rx_gen was read (playing back files: the call's own, with no scope) */
    uint8_t pad[2];           /**< always 0 */
} dsd_event_rx_scope;

//event history (each item)
// NOLINTBEGIN(clang-analyzer-optin.performance.Padding)
// The dsd_state structure is intentionally organized by functional groups for clarity
// and cross-module stability rather than by strict padding minimization. Reordering
// hundreds of fields as suggested by the analyzer would be high-risk and harm
// readability/maintainability without measurable benefit. Suppress the padding
// warning for this aggregate while keeping all other clang-tidy checks active.
typedef struct {
    uint8_t write;       // If this event needs to be written to a log file
    uint8_t color_pair;  //this value corresponds to which color pair the line should be in ncurses
    uint8_t severity;    // neutral event severity for non-terminal frontends
    uint8_t category;    // neutral event category for non-terminal frontends
    uint8_t crc_invalid; // DSD_CRC_* provenance bits (crc_provenance.h); zero does not imply verification.
    int8_t systype;      //indentifier of which decoded system type this is from (P25, DMR, etc)
    int8_t subtype;      //subtype of systpe (VLC, TLC, PDU data, System Event, etc)
    uint32_t sys_id1;    //sys_id1 through 5 will be a hierarchy of system identifiers
    uint32_t sys_id2;    // For example, trunked P25 has WACN:SYS:NAC:RFSS:SITE
    uint32_t sys_id3;    //conventional may only use NAC, RAN, or Color Codes
    uint32_t sys_id4;    //
    uint32_t sys_id5;    //
    int8_t gi;           //group or individual
    uint8_t emergency;   // emergency indication observed during this call
    uint8_t priority;    // observed service priority
    uint8_t enc;         //clear or encrypted
    uint8_t enc_alg;     //alg if encrypted
    uint16_t enc_key;    //enc key id value, if encrypted (not key value or key variable)
    uint64_t mi;         //mi, or iv base value from OTA if provided
    uint16_t svc;        //other relevant svc opts if applicable
    uint32_t source_id;  //source radio id or other source value
    uint32_t target_id;  //group or individual target, or destination value
    char src_str[200];   //source, expressed as a string for M17, YSF, DSTAR, dPMR
    char src_home[24];   //display only: a roaming P25 radio's home identity, unit@system (never a source)
    uint64_t
        src_home_key; //the talker's full P25 home SUID (WACN, System ID, unit) when named, 0 otherwise: which radio's home the row shows
    char tgt_str[200]; //target, expressed as a string for M17, YSF, DSTAR, dPMR
    char t_name[200];  //this is the string present from any csv groupName import
    char s_name[200];  //same as above, but if loaded from a src value and not tg value
    char t_mode[200];  //mode, or A,B,D,DE from csv group import file
    char s_mode[200];  //mode, or A,B,D,DE from csv group import file
    // Name of the scan channel this transmission was heard on, or "" when the receiver was not
    // scanning a named channel. Resolved once per call epoch, on the epoch's first render, and
    // rendered as a bracketed prefix between the row's timestamp and its protocol token.
    char channel_label[DSD_CHANNEL_LABEL_SIZE];
    char service_label[DSD_SERVICE_LABEL_SIZE];
    dsd_receive_identity receive_identity;
    // Whether channel_label above has been resolved for this row. An unnamed channel resolves to
    // an empty label, which is an answer and not a missing one -- a -Y list with only some rows
    // named is ordinary -- so the emptiness alone cannot serve as "ask again", or a later render
    // of the same epoch would stamp whichever channel the scanner has since hopped to.
    uint8_t channel_label_resolved;
    // Set when the recording of the row's call must not be exported to rdio-scanner (DirWatch sidecar and API upload):
    // the talkgroup and radio policy's `stream` flags, judged by the event layer as the media gates judge the call each
    // time it resolves the row's labels (issue #773 D7). 0 for a row never judged, however it was built
    // (init_event_history(), a zeroed row), so it exports as before. Decoder-thread bookkeeping; not shown or persisted.
    uint8_t stream_blocked;
    // The talkgroup the row's call was judged on for that export: a patched P25 call's member talkgroup while its
    // membership is current, else the call's policy target, else target_id (a private call: target_id); 0 while the
    // call has not been judged. Bookkeeping as stream_blocked is.
    uint32_t policy_target_id;
    // Who held the tuner when this row's call was first rendered; frozen with channel_label, so a
    // call a later release or resume ends keeps the identity it began with. operator_tuned: the
    // operator held the receiver (a paused scan, a tuner release, a manual tune). scan_member: a scan was running,
    // whether or not it named the channel. Meaningful only once channel_label_resolved is set.
    uint8_t operator_tuned;
    uint8_t scan_member;
    uint32_t channel; // If this occurs on a trunking channel, which channel
    // The numbering channel was named in, a dsd_call_channel_kind (<dsd-neo/core/call_channel.h>): the DMR call's own
    // LSN, LPCN or LCN; DSD_CALL_CHANNEL_NONE for other protocols. Meaningful only with channel != 0, and set with it.
    uint8_t call_channel_kind;
    // An analog row's mode, a dsd_analog_mode (<dsd-neo/core/analog_mode.h>): NFM or AM as the demodulator ran, unknown
    // (0) on audio input. A row is analog by its systype (DSD_SYNC_ANALOG); the mode means nothing on any other row.
    uint8_t analog_mode;
    // The system and site the call was heard on: the site parts (dsd_rxid_site_snapshot(),
    // <dsd-neo/core/received_identity_site.h>) of the received identity record the sys_id parts come from, taken under
    // the same rule and frozen with them -- what the carrier sent while the call was heard, never a part of the moment
    // (access code, rest or free channel, RAS, vendor, control channel). Family NONE when nothing was received, and for
    // M17, dPMR, a TETRA direct mode call and --playfiles.
    dsd_received_identity site_id;
    // Frequency in Hz the call was heard on, or 0 when unknown. The call's own frequency (a grant's
    // channel, the followed voice channel) whenever the call has one; otherwise the receiver's tuned
    // frequency, taken once, on the epoch's first render while the call is active, and kept for the
    // rest of the epoch. A row is never given the tuner reading after its call has ended.
    int64_t freq_hz;
    // Which access code access_code is, a dsd_access_code_kind (<dsd-neo/core/access_code.h>);
    // DSD_ACCESS_CODE_NONE (0) when none is known. Refreshed from the decoder while the call is
    // active, never erased there by an unknown reading, and frozen once the call has ended.
    uint8_t access_code_kind;
    // The colour code, NAC, RAN or CAN the call was heard with; meaningful only when
    // access_code_kind is not DSD_ACCESS_CODE_NONE.
    uint16_t access_code;
    time_t event_time; //time event occurred
    // Decode-clock time (dsd_decode_now_realtime_s(), whole seconds) the transmission this row describes began, or 0
    // when unknown: wall time live, the capture's time in an I/Q replay.
    // event_time is restamped as last-activity on every render pass, so by commit it
    // reads as the call's end; the pair is what gives a frontend a real duration.
    time_t event_start_time;

    uint8_t pdu[128 * 24];   //relevant link control, or full PDU if data call (in bytes)
    char sysid_string[200];  //string comprised of system unique identifiers
    char alias[2000];        // If this event has a source radio talker alias or similar
    char gps_s[2000];        //gps, if returned, expressed as a string
    char text_message[2000]; // If this event is a decoded text message, then it goes here
    char event_string[2000]; //user legible and printable string for the event that happened
    char internal_str[2000]; //string that relates to a DSD-neo generated event (ENC LO, error notices, etc)
    // The admitted position gps_s describes, and the row's sender identity (issue #800). gps_s and pos are written
    // in one step by the position writers (<dsd-neo/core/events.h>); a text-only GPS write leaves pos without a
    // position (valid 0), so the two never disagree.
    dsd_event_pos pos;
    // The reception identity of the row's call or notice (issue #800), beside the sender identity in pos.scope.
    dsd_event_rx_scope rx_scope;
} Event_History;

//event history for number of each items above
// Ring length, shared with every consumer that walks the items: index 0 is the active
// call's row, retaining its enrichment until commit; indexes 1..DSD_EVENT_HISTORY_LEN-1
// are committed rows. Data-PDU payloads for notices live separately in staged.
#define DSD_EVENT_HISTORY_LEN 255

typedef struct {
    char gps_s[2000];
    char text_message[2000];
    // The admitted report gps_s describes (dsd_event_stage_position()), whole: the next data notice checks its typed
    // source against the notice's own before the row takes it. rev 0 = none; a text-only stage clears it.
    dsd_position_fix pos_fix;
} Event_History_Staged;

/* The one comparison of the two P25p1 demodulator chains an acquisition gets (frame sync's
 * frame_sync_p25p1_mod_compare_note()). The first NID-decoded P25p1 frame on the 4800/4 profile measures
 * what validated frames read on the chain that carried it over one search pass; a chain that let a frame go
 * by unread in it gets the other chain measured for as long. A CQPSK chain measured second, which starts cold,
 * keeps the profile if it read the carrier whole from its own first frame; otherwise the one that read more does.
 * Zero is "no comparison, no verdict". */
typedef struct {
    int phase;                 /* 0 none, 1 measuring the incumbent chain, 2 measuring the other chain */
    int incumbent_rf_mod;      /* the chain the first frame came on: 0 C4FM, 1 CQPSK */
    uint32_t incumbent_read;   /* symbols validated frames read in the incumbent's pass */
    int incumbent_frames;      /* validated frames in that pass after the one that opened it */
    int incumbent_missed;      /* a search after one of those frames as long as the frame */
    uint32_t last_frame_end;   /* dsd_state::symbolcnt the current pass's last validated frame ended at */
    uint32_t last_frame_read;  /* symbols that frame read */
    uint32_t trial_read;       /* symbols validated frames read in the other chain's pass */
    int trial_frames;          /* validated frames in that pass */
    int trial_missed;          /* a search after one of them, past the first, as long as the frame (CQPSK) */
    int counter_at_trial;      /* dsd_state::sps_hunt_counter when the other chain's pass began */
    uint32_t window_start;     /* dsd_state::symbolcnt the current window opened at */
    uint32_t seen_symbolcnt;   /* the dsd_state::p25_p1_validated_symbolcnt last read, or consumed at a boundary */
    uint32_t seen_carrier_seq; /* dsd_state::carrier_seq when that stamp was read: one from before opens nothing */
    uint32_t carrier_seq;      /* dsd_state::carrier_seq the comparison started on */
    /* What a finished comparison chose, kept with the learned modulation it set: a frame on that chain starts no
     * new comparison. Dropped wherever p25_p1_validated_rf_mod is forgotten. */
    int verdict_valid;
    int verdict_rf_mod;
} dsd_p25p1_mod_compare;

typedef struct Event_History_I {
    Event_History Event_History_Items[DSD_EVENT_HISTORY_LEN];
    uint64_t revision;
    // Count of push_event_history() calls on this slot. Every push -- call commits,
    // data and system notices, the startup banner -- shifts the ring by one, so a
    // row's depth can be recovered as 1 + (push_seq - the push_seq it was pushed at),
    // and a committed row's push stamp as push_seq - (its index - 1). That stamp is
    // stable for the row's whole life in the ring, which makes it the identity
    // frontends key their own mirrors on.
    uint64_t push_seq;
    // Count of mutations to the committed rows (indexes >= 1): pushes, reacquisition
    // merges, late enrichment, and full resets. Staged-row renders bump only
    // `revision`, so a consumer that mirrors committed rows only (the Qt call
    // history) can skip rescanning the ring while this is unchanged.
    uint64_t commit_rev;
    // Which ring this is: a nonzero nonce drawn once, when initState() allocates the ring, and shared by
    // its two slots. A state an embedding host reuses for another run keeps it, and its push_seq goes on
    // counting; a new state draws another. A frontend that keys its mirror on push stamps tells by it the
    // rows it already read from a new ring that repeats their stamps and content, as a capture replayed in
    // a fresh state does.
    uint64_t instance;
    // Decoder-thread scratch consumed by next data notice; snapshots incidental, no dirty marks; frontends never render
    Event_History_Staged staged;
} Event_History_I;

//new audio filter stuff from: https://github.com/NedSimao/FilteringLibrary
typedef struct {
    float coef[2];
    float v_out[2];
} LPFilter;

typedef struct {
    float coef;
    float v_out[2];
    float v_in[2];

} HPFilter;

/* One slot's digital voice high-pass (`-v 0x8`, issue #653): the transposed direct form II state of the 2nd-order
   Butterworth section dsd_voice_hpf_process() runs on 8 kHz vocoder frames, and the reception it last ran for, so a new
   transmission or protocol on the slot starts from clear state (<dsd-neo/core/voice_chain.h>). */
typedef struct {
    double s1;
    double s2;
    /* The last nonzero transmission (dsd_call_snapshot_transmission()) the slot's frames belonged to; 0 before the
       first. A fade the call state heals keeps it. */
    uint64_t transmission;
    int protocol_family; /* dsd_call_state_protocol_family() of the last frame; 0 before the first. */
} dsd_voice_hpf_state;

//end new filters

/**
 * @brief Post-filter sample trace used only by the symbol-timing diagnostic.
 *
 * `samples` holds the samples the symbol grid consumed, in order; `spans` holds
 * how many of them each completed symbol took, so a reader can walk real symbol
 * boundaries rather than assume a fixed samplesPerSymbol stride (the pre-sync
 * timing nudge makes symbols consume samplesPerSymbol +/- 1). Decoder-state setup
 * and teardown own both buffers, as they do the symbol history's; nothing is
 * written to them unless DSD_NEO_DEBUG_SYMBOL_TIMING is on.
 */
typedef struct {
    float* samples;
    uint8_t* spans;
    int sample_head;
    int sample_count;
    int span_head;
    int span_count;
} dsd_symbol_timing_trace;

/** Raw samples the symbol grid keeps behind it: enough to prime the longest
 *  matched filter (DSD_SPS_FILTER_MAX_TAPS) after a switch-off has handed back
 *  the samples the previous filter still had in flight. */
#define DSD_MATCHED_FILTER_HISTORY 2048

/**
 * The matched filter the symbol grid is reading through, and what it takes to
 * change it without moving the grid (issue #444).
 *
 * The grid reads the raw discriminator until a sync names a protocol and the
 * filter's output afterwards, which describes the signal one group delay in the
 * past. A change of `kind` or `sps` is therefore a discontinuity in the content
 * the grid samples, and `src/dsp/dsd_symbol.c` pays for it here: a filter
 * switching on is primed from `raw` and fed its delay's worth of samples whose
 * outputs are discarded; one switching off hands back the samples it still had
 * in flight, which the grid re-reads from `raw` (`replay` of them) before live
 * input resumes. Zeroed by initState() and again by
 * dsd_symbol_matched_filter_reset() alongside init_rrc_filter_memory(), since a
 * cleared filter with this saying it is primed would be the transient all over.
 */
typedef struct {
    int kind;  /**< A dsd_sps_filter_kind; an int because core does not see dsp headers. 0 is unfiltered. */
    int sps;   /**< Samples per symbol `kind` was designed for. */
    int delay; /**< Group delay of `kind` at `sps`, in samples; 0 when unfiltered. */
    float raw[DSD_MATCHED_FILTER_HISTORY]; /**< Raw samples the grid consumed, newest last; a ring. */
    int raw_head;                          /**< Next write index into `raw`. */
    int raw_count;                         /**< Samples held, saturating at the ring size. */
    int replay;                            /**< Samples still to be re-read from `raw` before live input. */
    /** dsd_state::symbol_clock of the symbol in which the grid last changed how it reads `raw`: a change of `sps`, or
        the end of a hand-back. Every symbol after it took its samples from `raw` live, one each, in order, at one
        span, which is what lets the sync anchor measure a word the hunt read there (src/dsp/symbol_anchor.c). A switch
        of `kind` alone does not count: the samples the switch-on consumes are recorded, and the seam keeps the content
        position, so the grid stays one span a symbol in content and `delay` maps it onto `raw`. */
    uint64_t steady_clock;
} dsd_matched_filter_seam;

typedef struct {
    uint8_t F1;
    uint8_t F2;
    uint8_t MessageType;

    /****************************/
    /***** VCALL parameters *****/
    /****************************/
    uint8_t CCOption;
    uint8_t CallType;
    uint8_t VoiceCallOption;
    uint16_t SourceUnitID;
    uint16_t DestinationID; /* May be a Group ID or a Unit ID */
    uint8_t CipherType;
    uint8_t KeyID;

    /*******************************/
    /***** VCALL_IV parameters *****/
    /*******************************/
    uint8_t IV[8];

    /*****************************/
    /***** Custom parameters *****/
    /*****************************/

    /* Used on DES and AES encrypted frames */
    uint8_t PartOfCurrentEncryptedFrame; /* Could be 1 or 2 */
    uint8_t PartOfNextEncryptedFrame;    /* Could be 1 or 2 */
    uint8_t CurrentIVComputed[8];
    uint8_t NextIVComputed[8];
} NxdnElementsContent_t;

//dPMR
/* Could only be 2 or 4 */
#define NB_OF_DPMR_VOICE_FRAME_TO_DECODE 2

typedef struct {
    unsigned char RawVoiceBit[NB_OF_DPMR_VOICE_FRAME_TO_DECODE * 4][72];
    unsigned int errs1[NB_OF_DPMR_VOICE_FRAME_TO_DECODE
                       * 4]; /* 8 x errors #1 computed when demodulate the AMBE voice bit of the frame */
    unsigned int errs2[NB_OF_DPMR_VOICE_FRAME_TO_DECODE
                       * 4]; /* 8 x errors #2 computed when demodulate the AMBE voice bit of the frame */
    unsigned char AmbeBit[NB_OF_DPMR_VOICE_FRAME_TO_DECODE * 4][49]; /* 8 x 49 bit of AMBE voice of the frame */
    unsigned char CCHData[NB_OF_DPMR_VOICE_FRAME_TO_DECODE][48];
    unsigned int CCHDataHammingOk[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned char CCHDataCRC[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CCHDataCrcOk[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int FrameNumbering[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CommunicationMode[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int Version[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    /* Per half (dpmr_resolve_half_scrambling(), issue #655): DPMR_HALF_CLEAR, DPMR_HALF_SCRAMBLED (Version 3), by the
       half's own Version when its CRC-7 passed, else by the transmission's last verified half or this frame's other
       one; DPMR_HALF_UNVERIFIED when no half has verified since the transmission's boundary: the bridge plays none of
       it. Version itself is the raw field. */
    unsigned int Scrambled[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int CommsFormat[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int EmergencyPriority[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int Reserved[NB_OF_DPMR_VOICE_FRAME_TO_DECODE];
    unsigned int SlowData[NB_OF_DPMR_VOICE_FRAME_TO_DECODE]; /* 18-bit slow data field */
    unsigned int ColorCode[NB_OF_DPMR_VOICE_FRAME_TO_DECODE / 2];
} dPMRVoiceFS2Frame_t;

/**
 * @brief Consolidated per-slot IDEN entry for P25 frequency resolution.
 *
 * Each entry holds the complete set of parameters needed to resolve a 16-bit
 * channel number to a frequency. Two arrays of this type exist in dsd_state:
 * one for FDMA/non-TDMA identifiers and one for TDMA identifiers. This
 * separation prevents multi-mode systems from cycling incompatible parameters
 * in a single slot.
 */
typedef struct {
    long int base_freq;       // base frequency in 5 Hz units (per IDEN_UP encoding)
    int chan_type;            // 4-bit channel type (TDMA: slots-per-carrier; 1 for FDMA default)
    int chan_spac;            // 10-bit channel spacing (in 0.125 kHz units)
    int trans_off;            // transmit offset
    uint8_t bw_vu;            // 4-bit VHF/UHF bandwidth (0=standard/not VHF-UHF, nonzero=VHF/UHF BW)
    uint8_t trust;            // 0=unknown, 1=unconfirmed, 2=confirmed on matching CC
    uint8_t populated;        // 0=empty, 1=has valid complete data from LCW/TSBK/MAC/PDU
    uint8_t flags;            // P25_IDEN_F_* provenance and offset encoding
    unsigned long long wacn;  // WACN provenance (system context when IDEN was learned)
    unsigned long long sysid; // SysID provenance
    unsigned long long rfss;  // RFSS ID provenance
    unsigned long long site;  // Site ID provenance
} p25_iden_entry_t;

#define P25_IDEN_F_UNTYPED        0x01U // no channel type was supplied; FDMA fallback
#define P25_IDEN_F_OFF_SPACING    0x02U // trans_off counts channel spacings, otherwise 250 kHz
#define P25_IDEN_F_SEEDED         0x04U // installed by the user band plan

/** Capacity of the user-supplied P25 band plan: four systems' worth of 16 identifiers. */
#define DSD_P25_BANDPLAN_MAX_ROWS 64

/* Why an input interruption stands (dsd_state::input_interrupt_reason). The values rank: a raise never lowers the
   reason that stands (dsd_state_raise_input_interrupt()). */
typedef enum {
    /* None of its own: a hunt read left a silent input's wait for a queued command, or the input ended; or a hunt read
       on a live RTL stream that came back idle (DSD_RTL_READ_IDLE) gave way to a queued command or a put-off
       publication (issue #834); or a P25 tick inside the hunt moved the chain under it (a retune, a new symbol
       profile), and the hunt handed back. The engine loop clears it at its next pass. */
    DSD_INTERRUPT_NONE = 0,
    /* A Signal search left the frame, or a live read gave up on a stalled input during a search visit: getSymbol()
       stands erasures in while the search runs. */
    DSD_INTERRUPT_SEARCH,
    /* A hunt read under a scan (trunk scan owns the tuner, or -Y runs) got no input for a bounded time (issue #834: a
       silent PCM input for DSD_ANALOG_STREAM_PAUSE_MIN_MS, a live RTL read that came back DSD_RTL_READ_IDLE, an idle
       analog monitor): the pass ends as a dead-air pass does, and the engine loop runs noCarrier(), which services the
       scan. It does not stand: no frame was cut. */
    DSD_INTERRUPT_SCAN_IDLE,
    /* A live read with no stream gave way to queued commands: sticky until the engine loop consumes it. */
    DSD_INTERRUPT_YIELD,
    /* The radio stream has a gap on the same carrier (a USB recovery, an rtl_tcp reconnect, or a capture's recorded
       one): sticky until the engine loop consumes it and runs the stream-gap carrier boundary
       (DSD_CARRIER_BOUNDARY_STREAM_GAP). */
    DSD_INTERRUPT_STREAM_GAP,
} dsd_input_interrupt_reason;

/* NXDN trunking: where the receiver followed a call to (dsd_state::nxdn_follow). */
typedef struct {
    long int freq_hz; /**< the voice channel's frequency; 0 none */
    uint16_t chan;    /**< its channel number (DFA OFN on a DFA site; Type-D repeater number) */
    uint8_t repeater; /**< Type-D go-to repeater (1-30); 0 on Type-C */
} dsd_nxdn_follow_route;

/* NXDN trunking: the call the receiver holds (dsd_state::nxdn_call). */
typedef struct {
    double follow_m;     /**< decode clock: when this identity became the held call; moves only when it changes */
    long int rx_freq_hz; /**< the receiver frequency it was heard or followed on; 0 not known */
    uint32_t target;     /**< talkgroup, or the destination of a private call */
    uint32_t source;     /**< source unit; 0 not known */
    uint8_t valid;
    uint8_t private_call;
    uint8_t data_call;
    uint8_t type_d; /**< a Type-D (IDAS) call: judged as Type-D admission judges it, with no source fallback */
    /**
     * The canonical call the identity names (dsd_call_snapshot_transmission() of slot 0's call), so it never outlives
     * that call: another call, or its end (on the followed route, past the hangtime), leaves the held call unknown.
     * 0 while it awaits its call: the first one to begin after call_floor, the canonical epoch when it was named.
     */
    uint64_t call_epoch;
    uint64_t call_floor;
    double call_seen_m; /**< decode clock: when the named call was last seen active, or when it ended */
    /** The named call is over and another (call_epoch) began on the followed route within the hangtime: valid is 0 (an
     * unknown held call) and the rest stays only so that naming that call as the same one keeps follow_m. */
    uint8_t gap;
} dsd_nxdn_call_identity;

/* NXDN Type-C: where the channel access parameters (dsd_state::nxdn_rcn, nxdn_base_freq, nxdn_step) came from
   (dsd_state::nxdn_ca). They are a site's, carried only by its SITE_INFO (TS 1-A §6.5.36), so they are kept apart from
   the site identity: <dsd-neo/core/nxdn_channel_access.h> owns every write. */
typedef struct {
    uint32_t location_id; /**< the Location ID of the SITE_INFO that set them; 0 none */
    /** Advances whenever the parameters, their site or their validity change: what was computed under one generation
     * does not hold under the next. */
    uint32_t generation;
    /** 1 while the parameters are a SITE_INFO's and still hold. nxdn_rcn stays as the last notation heard while they
     * are not (the message layouts still follow it), but no channel is resolved by DFA arithmetic. */
    uint8_t valid;
} dsd_nxdn_ca_source;

/* NXDN Type-C: the site the receiver chose ("this site", dsd_state::nxdn_site) and what the session knows of the system
   it decodes, forgotten with the channel access parameters (dsd_nxdn_ca_reset()). Only a SITE_INFO or SRV_INFO decoded
   while no traffic channel is followed names this site (TS 1-A §6.4.3.1-2 "for current site"): a CCH_INFO may name any
   site, and a broadcast heard on a followed channel may be another site's. <dsd-neo/core/nxdn_channel_access.h> owns
   every write but the foreign control stamp (nxdn_confirm_note_evidence()). */
typedef struct {
    uint32_t location_id; /**< this site's 24-bit Location ID, while known is 1 */
    uint8_t known;        /**< 1 once a SITE_INFO or SRV_INFO named this site */
    /** 1 once Type-C trunking decoded here (a CAC, a CCH_INFO or a SITE_INFO): the LICH values a composite control
     * channel (RTCH_C) shares with a Type-D RTCH2 are read as RTCH_C (nxdn_frame.c). */
    uint8_t type_c;
    /** Decode clock (dsd_decode_now_mono_s()): when a check of another channel's control traffic last passed on the
     * followed traffic channel (dsd_state::nxdn_frame_foreign); 0 never. */
    double foreign_control_m;
} dsd_nxdn_site_record;

enum { DSD_NXDN_DFA_LEARNED_MAX = 128 };

/* NXDN Type-C: the channel map rows DFA arithmetic wrote (dsd_state::nxdn_dfa_learned), all computed under the
   parameter generation recorded here. They are dropped when the parameters change, so an old site's frequency never
   answers for the new site's channel number. A row any other writer sets (an imported channel map, another protocol)
   leaves this record and is never dropped by it. */
typedef struct {
    uint16_t chan[DSD_NXDN_DFA_LEARNED_MAX];
    long int freq[DSD_NXDN_DFA_LEARNED_MAX]; /**< the frequency written, so a row changed behind the record stays */
    uint32_t generation;                     /**< dsd_nxdn_ca_source::generation the rows were computed under */
    uint16_t count;
} dsd_nxdn_dfa_learned;

/**
 * @brief One row of a user-supplied P25 band plan (docs/csv-formats.md, "P25 Band Plan CSV").
 *
 * `entry` is a ready-to-copy IDEN entry (trust 1, populated, rfss/site 0); `entry.wacn`/`sysid`
 * are the system the row applies to, both 0 for a row that applies everywhere. `is_tdma`
 * selects the table the row seeds, by the same rule p25_channel_type_slots_per_carrier() uses.
 */
typedef struct p25_bandplan_row {
    uint8_t iden;    // identifier 0-15
    uint8_t is_tdma; // 1 seeds p25_iden_tdma, 0 seeds p25_iden_fdma
    p25_iden_entry_t entry;
} p25_bandplan_row_t;

/** Voice-gated scan phase for -Y (issue #381). OFF = gate disabled; QUALIFY = synced
 * but no policy-allowed voice yet; VOICE = voice media active; TAIL = holding past
 * the last voice frame. */
typedef enum {
    DSD_SCAN_VOICE_GATE_OFF = 0,
    DSD_SCAN_VOICE_GATE_QUALIFY = 1,
    DSD_SCAN_VOICE_GATE_VOICE = 2,
    DSD_SCAN_VOICE_GATE_TAIL = 3,
} dsd_scan_voice_gate_phase;

/** Why the receiver is staying on the scanner's current row (issue #508). Frontend-neutral:
 * the decoder owns every deadline and the UI only renders what is published. NONE means
 * nothing holds the row -- for --trunk-scan that is exactly the old "not held" verdict. */
typedef enum {
    DSD_SCAN_STAY_NONE = 0,
    DSD_SCAN_STAY_RETUNE_PENDING = 1, /**< a backend retune request has not resolved */
    DSD_SCAN_STAY_RETUNE_RETRY = 2,   /**< retune failed; cooling down before retrying in place */
    DSD_SCAN_STAY_CC_ACQUIRE = 3,     /**< trunking SM is acquiring a control channel */
    DSD_SCAN_STAY_CALL_FOLLOW = 4,    /**< trunking SM is following a call, hangtime included */
    DSD_SCAN_STAY_VOICE = 5,          /**< conventional row: voice media is active */
    DSD_SCAN_STAY_ACTIVITY_HOLD = 6,  /**< conventional row: activity hold / voice tail running */
    DSD_SCAN_STAY_MANUAL_HOLD = 7,    /**< operator hold (Y): the dwell is paused, not expired */
    DSD_SCAN_STAY_IDLE_DWELL = 8,     /**< nothing holds it; the idle dwell / qualify window runs */
    DSD_SCAN_STAY_HANGTIME = 9,       /**< -Y legacy rule: waiting out -t since the last sync */
    DSD_SCAN_STAY_CARRIER = 10,       /**< analog row: its carrier is open (issue #526) */
    DSD_SCAN_STAY_TONE_PENDING = 11,  /**< analog row: carrier open, the tone policy still checking (issue #527) */
    DSD_SCAN_STAY_NO_LIST = 12,       /**< -Y with no channel map of the user's: nothing to step to (issue #697) */
} dsd_scan_stay_reason;

/** Whether the silent-channel skip (issue #834) is checking the scan visit on air, for the Scan Timing row: published
 * only while the visit waits out its idle dwell (trunk scan) or its idle dwell or hangtime (-Y), so a stay that
 * explains the visit by itself keeps its plain phrase. NONE: nothing to say (the setting off, a trunked target, a
 * check that ended: busy, skipped, timed out, refused by the tap, or activity heard). CHECKING: the check runs
 * (waiting for its capture, settling, measuring, or a quiet result waiting to be applied). NO_CHECK: the visit cannot
 * be checked, for the dsd_scan_quiet_reason published beside it. */
typedef enum {
    DSD_SCAN_QUIET_STATUS_NONE = 0,
    DSD_SCAN_QUIET_STATUS_CHECKING = 1,
    DSD_SCAN_QUIET_STATUS_NO_CHECK = 2,
} dsd_scan_quiet_status;

/** Why a scan visit gets no silent-channel check (DSD_SCAN_QUIET_STATUS_NO_CHECK). The receiver's reasons (INPUT,
 * TUNER, RATE) outrank the channel's (MODES, then WIDTH and NO_WIDTH). INPUT: audio input, an I/Q replay or I/Q stream,
 * or a build without radio support. TUNER: a centred capture, with no Fs/4 shift (a native Airspy, offset tuning, the
 * shift off). RATE: a capture rate the calibration did not cover. MODES: an untyped -Y row under decoders with no known
 * channel width (ProVoice, X2-TDMA, TETRA). WIDTH: an analog width the calibration did not cover. NO_WIDTH: an NFM
 * channel with no width set, so no definite channel to judge. */
typedef enum {
    DSD_SCAN_QUIET_REASON_NONE = 0,
    DSD_SCAN_QUIET_REASON_INPUT = 1,
    DSD_SCAN_QUIET_REASON_TUNER = 2,
    DSD_SCAN_QUIET_REASON_RATE = 3,
    DSD_SCAN_QUIET_REASON_MODES = 4,
    DSD_SCAN_QUIET_REASON_WIDTH = 5,
    DSD_SCAN_QUIET_REASON_NO_WIDTH = 6,
} dsd_scan_quiet_reason;

/** Live scan timing for the frontends' Scan Timing row (issue #508). Plain inline
 * scalars: it rides the vertex_ks_count..ui_msg snapshot copy range (ui_snapshot.c static
 * assert) and must never grow a pointer, or the byte-range copy would alias decoder memory. */
struct dsd_scan_timing_publication {
    double started_m;  /**< monotonic start of the live window; < 0 when there is none */
    double deadline_m; /**< monotonic expiry; < 0 = no live timer (suspended/paused/unanchored) */
    /** Monotonic expiry of the per-visit cap (issue #507); < 0 = no live cap, whether it is
     * disabled, not yet anchored, or suspended by a hold. Never zeroed into place: 0.0 would
     * read as a deadline at monotonic 0, which is long past. */
    double visit_deadline_m;
    uint32_t span_ms;  /**< full width of the live window; 0 when there is no timer */
    uint32_t dwell_ms; /**< effective idle dwell (or -Y qualify) for the row on air; 0 = n/a */
    uint32_t hold_ms;  /**< effective activity hold; 0 on trunked rows and when n/a */
    /** Effective per-visit cap for the row on air in ms; 0 = off (issue #507). */
    uint32_t visit_limit_ms;
    uint32_t hang_ms;     /**< active protocol's effective hangtime budget; 0 when n/a */
    uint8_t reason;       /**< dsd_scan_stay_reason */
    uint8_t conventional; /**< 1 = conventional / -Y row, so hold_ms means something */
    uint8_t quiet_status; /**< dsd_scan_quiet_status of the visit on air (issue #834) */
    uint8_t quiet_reason; /**< dsd_scan_quiet_reason, with DSD_SCAN_QUIET_STATUS_NO_CHECK; NONE otherwise */
};

/** Which sub-audible signalling the analog receiver has identified: a CTCSS tone (issue #522)
 * or a DCS code (issue #523). */
typedef enum {
    DSD_ANALOG_TONE_KIND_NONE = 0,
    DSD_ANALOG_TONE_KIND_CTCSS = 1,
    DSD_ANALOG_TONE_KIND_DCS = 2,
} dsd_analog_tone_kind;

/* dsd_state::dmr_mono_rx_slot (issue #637). */
enum { DSD_DMR_MONO_RX_NONE = 0, DSD_DMR_MONO_RX_PENDING = 1, DSD_DMR_MONO_RX_TS1 = 2, DSD_DMR_MONO_RX_TS2 = 3 };

/* dsd_state::x2tdma_slot_crypto: what the timeslot's X2-TDMA voice frames are known to be. X2-TDMA has no decryption,
   so an encrypted frame is undecryptable; an UNKNOWN one is never decodable, and plays only where clear and encrypted
   audio both would. */
enum { DSD_X2TDMA_CRYPTO_UNKNOWN = 0, DSD_X2TDMA_CRYPTO_CLEAR = 1, DSD_X2TDMA_CRYPTO_ENCRYPTED = 2 };

/** Where received-tone detection stands (issue #522).
 * INACTIVE: nothing has been processed since the last reset (a retune, row or target change,
 * input switch, mode change or stop), or detection is not running at all. It does not by
 * itself mean detection is off: whether detection runs is dsd_analog_tone_detection_active()
 * (runtime/analog_tones.h), which frontends and receive policy ask instead.
 * IDLE: detection runs but there is no carrier. ACQUIRING: carrier present, no verdict yet.
 * LOCKED: a supported tone is confirmed. NONE: carrier present and no supported tone found
 * (or the tone was lost). UNAVAILABLE: detection is on, but the input rate is one the
 * sub-audible front end cannot use (below 2400 Hz or above 320 kHz), so nothing can be
 * detected until the rate changes. */
typedef enum {
    DSD_ANALOG_TONE_STATE_INACTIVE = 0,
    DSD_ANALOG_TONE_STATE_IDLE = 1,
    DSD_ANALOG_TONE_STATE_ACQUIRING = 2,
    DSD_ANALOG_TONE_STATE_LOCKED = 3,
    DSD_ANALOG_TONE_STATE_NONE = 4,
    DSD_ANALOG_TONE_STATE_UNAVAILABLE = 5,
} dsd_analog_tone_state;

/** The configured tone policy's verdict on the reception (issue #527; src/dsp/analog_tone_policy.c).
 * OFF: no policy is in force (none configured, or detection is not running: the AM monitor, a digital mode), and
 * the ordinary carrier squelch alone decides. PENDING: a list policy is in force and nothing is decided yet --
 * no carrier, or a carrier inside its acquisition window. ALLOWED / REJECTED: decided, and re-evaluated for as long
 * as the transmission lasts. The monitor plays only OFF and ALLOWED, and only they are scan activity: a PENDING
 * carrier holds a scan row only while it lasts, leaving no tail, and a REJECTED one holds none. */
typedef enum {
    DSD_ANALOG_TONE_GATE_OFF = 0,
    DSD_ANALOG_TONE_GATE_PENDING = 1,
    DSD_ANALOG_TONE_GATE_ALLOWED = 2,
    DSD_ANALOG_TONE_GATE_REJECTED = 3,
} dsd_analog_tone_gate;

/** What the analog receiver hears below the voice band, for every frontend (issue #522).
 * Written only by the DSP tap on the decoder thread (src/dsp/analog_rx.c). Plain int
 * scalars: it rides the vertex_ks_count..ui_msg snapshot copy range (ui_snapshot.c static
 * assert), so it must never grow a pointer, and it holds no float, so the semgrep float-field
 * list does not change. The detector's working state lives in DSD_STATE_EXT_DSP_ANALOG_RX. */
struct dsd_analog_rx_publication {
    /** 1 while a carrier is open, held through the 200 ms hangover. On stdin, UDP and TCP input
     * and on a live radio stream the tap cannot clear it while no samples arrive, so a reader of
     * carrier_open or tone_state must also honour stale_after_ms, as dsd_app_rx_tone_view()
     * does. Kept on the AM monitor too, where no detection runs and tone_state stays INACTIVE
     * (issue #524). */
    int carrier_open;
    int tone_kind;       /**< dsd_analog_tone_kind; NONE unless tone_state is LOCKED */
    int tone_state;      /**< dsd_analog_tone_state */
    int ctcss_tenths_hz; /**< locked CTCSS tone in tenths of a hertz (1000 = 100.0 Hz); 0 = none */
    /** 1 while the locked CTCSS tone was confirmed only by allowing for transmitter tone error, off its table value by
        more than the detector's 0.5 Hz on-value gate (issue #643; 150.6 Hz read as 150.0). The tone policy may pass the
        reception on it at once, but rejects on it only when its window ends. 0 otherwise. */
    int ctcss_off_value;
    int dcs_code;     /**< locked DCS code as its value (023 octal = 19); 0 = none */
    int dcs_inverted; /**< 1 = the locked code is named in inverted polarity (the canonical member
                              of its alias class, runtime/analog_tones.h: never, for the supported set) */
    /** 1 while, with a carrier and nothing locked -- or only an off-value CTCSS tone (ctcss_off_value) -- the DCS
        detector holds a candidate code it has not confirmed: some slicer read a supported code's word once (issue
        #527). The tone policy waits past its window for it. Not tone_state's ACQUIRING, which turns NONE 500 ms into a
        carrier with nothing locked. */
    int dcs_candidate;
    int gate; /**< dsd_analog_tone_gate: the configured tone policy's verdict (issue #527) */
    /** 1 when gate was decided because no tone or code was confirmed within the acquisition window (an allow list's
        "no tone" rejection, a block list's "no tone" pass); 0 when a confirmed value decided it, or nothing is
        decided. */
    int gate_no_tone;
    /** 1 once a reception the policy rejected has ended -- its carrier's 200 ms hangover ran out, or its input paused,
        with gate REJECTED -- until the next carrier opens, the policy changes or the tap resets for any other reason
        (a retune, a row or target change, an input switch, a mode change). gate is back to PENDING by then; this keeps
        the rejection for the scanners (issue #527), so that traffic rejected between two of their passes does not hold
        the row on a window still running from before it (-t since the row landed or since traffic the policy passed, a
        trunk-scan activity hold). */
    int gate_rejected_ended;
    /** Bumped on every reset (retune, row or target change, input switch, mode change, stop,
     * input-rate change, carrier hangover, stream pause), so a reader can tell a new reception
     * from the one it last saw. */
    uint32_t generation;
    /** Bumped each time the verdict locks a tone or code it did not hold the block before: a first lock, a lock after
     * none (within one generation too: a tone lost and found again under one carrier), or another tone or code, after
     * a DCS lock's precedence over a CTCSS one; never while one lock holds, and never reset (issue #802). A reader that
     * sees the same generation and lock_epoch twice has seen one unbroken lock in between, as far as the tap's blocks
     * can tell. */
    uint32_t lock_epoch;
    /** Bumped on every hard boundary the tap crosses: an announced reset (dsd_analog_rx_reset(): a retune, a row or
     * target change, an input switch or TCP reconnect, a mode change, stop), a retune or receive-profile change the
     * tap's own generation check found, a detected stream pause, an input-rate move and a switch between the FM and AM
     * monitors (issue #756). Unlike generation, the carrier hangover running out never moves it, so a reader that saw
     * it move since its last block knows the input crossed such a boundary in between, even inside one block. */
    uint32_t boundaries;
    /** Monotonic ms on the tap's clock (dsd_realtime_mono_ms(); a test build may install a test clock in its place,
     * dsd_analog_rx_clock_s()) after which this publication no longer describes the channel if the tap has not run
     * again since. Decoder-thread readers ask dsd_analog_rx_stale_now(), so the deadline and the time it is compared
     * with come from one clock. Set only on input that may pause: stdin,
     * UDP and TCP, whose producer may stop sending between transmissions, and live RTL-family
     * radio streams, which stop when their source does (an rtl_tcp server that went away, a
     * stalled device). Then no samples arrive for the sample-time hangover to count, and a
     * frontend reads the publication past this point as no carrier
     * (app_control/rx_tone_view.h). 0 = never stale (files, Pulse and IQ replay deliver
     * continuously). */
    uint64_t stale_after_ms;
};

// dsd_state is a C aggregate, not a C++ class: it is allocated once and zeroed by
// initState() before anything reads it, and C code — which is most of its users —
// has no constructors to write. A C++ TU that includes this header would otherwise
// report every one of its ~600 members, one finding per field of a struct nobody
// default-constructs. Scoped to this struct rather than to the file, which is what
// a --suppress on the command line could only do: the seventeen other types
// declared here, and every real C++ class in the tree, still get checked.
//
// Inert on cppcheck 2.21 — the check does not fire on a struct with no member
// functions at all — so this is insurance against a version that does, not a live
// carve-out. Unmatched suppressions are already suppressed tree-wide.
// cppcheck-suppress-begin uninitMemberVarNoCtor
struct dsd_state {
    int* dibit_buf;
    int* dibit_buf_p;
    int* dmr_payload_buf;
    int* dmr_payload_p;
    // Per-dibit signed soft metrics. Aligned with dmr_payload_buf.
    dsd_dibit_soft_t* dmr_soft_buf;
    dsd_dibit_soft_t* dmr_soft_p;
    int repeat;
    short* audio_out_buf;
    short* audio_out_buf_p;
    short* audio_out_bufR;
    short* audio_out_buf_pR;
    float* audio_out_float_buf;
    float* audio_out_float_buf_p;
    float* audio_out_float_bufR;
    float* audio_out_float_buf_pR;
    struct mbe_parameters* cur_mp;
    struct mbe_parameters* prev_mp;
    struct mbe_parameters* prev_mp_enhanced;
    struct mbe_parameters* cur_mp2;
    struct mbe_parameters* prev_mp2;
    struct mbe_parameters* prev_mp_enhanced2;
    // 64-bit state placed early to reduce padding
    unsigned long long int payload_mi;
    unsigned long long int payload_miR;
    unsigned long long int payload_miN;
    unsigned long long int payload_miP;
    unsigned long long int K;
    unsigned long long int K1;
    unsigned long long int K2;
    unsigned long long int K3;
    unsigned long long int K4;
    uint8_t hytera_key_segments;
    unsigned long long int R;
    unsigned long long int RR;
    uint8_t scalar_key_present[2];
    uint8_t basic_key_present;
    unsigned long long int H;

    /* The DMR talkgroup key autoload's working key (keyring_dmr_tg_autoload_apply()): the K, K1..K4, H,
       basic_key_present and hytera_key_segments it replaced (a key set directly, or none), restored for a call whose
       talkgroup has no key, and the ones it installed; it owns the working key (active) until anything else writes
       it, which hands it back first (dsd_dmr_tg_autoload_hand_back()), so a key written since is left alone. Both
       slots share the one working key, so each slot keeps the talkgroup whose key its own call last keyed from
       (slot_tg, 0: none), which a frame of a call no LC has named yet keys from again, and that key (slot_key and
       slot_key_flags, laid out as baseline; flags all 0: the slot's call keyed from no talkgroup), which a frontend
       shows on the slot's row from its snapshot, which holds no keyring (dsd_dmr_slot_call_key()). The slot's
       terminator, the no-carrier pass and every carrier boundary but a stream gap forget both. Key material: wiped
       with the keys (dsd_key_state_secure_wipe()). Written on the decoder thread only. */
    struct {
        unsigned long long int baseline[6];
        unsigned long long int installed[6];
        uint8_t baseline_flags[2];
        uint8_t installed_flags[2];
        uint8_t active;
        uint32_t slot_tg[2];
        unsigned long long int slot_key[2][6];
        uint8_t slot_key_flags[2][2];
    } dmr_tg_autoload;

    unsigned long long int HYTL;
    unsigned long long int HYTR;
    long int bit_counterL;
    long int bit_counterR;
    unsigned long long int p2_wacn;
    unsigned long long int p2_sysid;
    unsigned long long int p2_cc; //p1 NAC
    /* 1 once p2_cc is proven on the carrier being decoded: a burst descrambled with it (a scrambled FACCH or SACCH, or an
     * ESS) passed its Reed-Solomon check, or a CRC-checked network status broadcast named it (issue #575): a call
     * carried by unscrambled FACCH/SACCH never tests the seed, which -X or another carrier may have left. Each such
     * proof also names the carrier's proven NAC (p2_proven_nac), which is what a Phase 2 call reads. 0 at every
     * carrier boundary and whenever p2_cc, p2_wacn or p2_sysid changes (issue #804); p2_cc itself, the descrambling
     * key, is never reset for it. */
    uint8_t p2_cc_verified;
    /* The NAC the latest checked Phase 2 proof on the carrier being decoded named, -1 for none (issue #802): the seed a
     * burst descrambled with passed its Reed-Solomon check, or the NAC a CRC-checked network status broadcast carries,
     * whatever seed is configured. The latest proof wins. This, not p2_cc, is a Phase 2 call's received NAC
     * (dsd_access_code_current()). Set only through dsd_state_note_p2_proven_nac(), cleared with p2_cc_verified by
     * dsd_state_forget_p2_proof(). */
    int p2_proven_nac;
    unsigned long long int p2_siteid;
    unsigned long long int p2_rfssid;
    long int p25_cc_freq;        // P25 control-channel frequency from network status
    long int trunk_cc_freq;      // generic trunk-owner control-channel frequency
    int trunk_recovery_protocol; // validated owner; runtime trunk-scan recovery enum, survives raw sync loss
    unsigned long long int edacs_site_id;
    time_t last_cc_sync_time;    //use this to start hunting for CC after signal lost
    time_t p25_last_cc_msg_time; //last decoded P25 control-channel message
    time_t last_vc_sync_time;    //flag for voice activity bursts, tune back on con+ after more than x seconds no voice
    // Timestamp of last tune to a VC (used to provide a short startup grace
    // window so we don't bounce back to CC before MAC_PTT/ACTIVE/audio arrives)
    time_t p25_last_vc_tune_time;
    // Monotonic twins for SM timing (seconds)
    double last_cc_sync_time_m;
    double p25_last_cc_msg_time_m;
    double last_vc_sync_time_m;
    double p25_last_vc_tune_time_m;
    time_t rtl_fsk_reacquire_last_sync_time;
    double rtl_fsk_reacquire_last_sync_m;
    double rtl_fsk_reacquire_gap_start_m;
    double rtl_fsk_reacquire_last_request_m;
    time_t last_t3_tune_time;   // last time a DMR T3 grant was received (wall clock)
    double last_t3_tune_time_m; // same as above, monotonic seconds
    // DMR: rate-limit for single-fragment SLCO logging per slot
    time_t slco_sfrag_last[2];
    //event history itemized per slot
    Event_History_I* event_history_s;
    // Decoder-thread-only scoped DSD_CRC_* provenance bits (crc_provenance.h) for the content being decoded;
    // dispatch ORs its bits in and must save and restore each slot.
    uint8_t event_crc_invalid[2];
    // DMR header-chain DSD_CRC_* bits (failed, or RAS-accepted), retained until the protocol resets the assembly.
    uint8_t data_header_crc_invalid[2];
    /* The last call epoch each slot's call state gave out (src/core/util/call_state.c), kept on the state across the
       call-state extension's life: a new extension (another engine run on this state) goes on from it, so an epoch is
       never given out twice on one state. A record a protocol keys to a call epoch or transmission (issue #800) thus
       never matches a later run's call, and the call state needs to know nothing of those records. */
    uint64_t call_epoch_floor[2];
    // Codec2 contexts (NULL when codec2 unavailable; unconditional for ABI stability)
    struct CODEC2* codec2_3200; // M17 fullrate
    struct CODEC2* codec2_1600; // M17 halfrate
    void* rc2_context;
    struct RtlSdrContext* rtl_ctx; // RTL-SDR stream context (NULL when unused; unconditional for ABI stability)
    time_t ui_msg_expire;          // epoch seconds when ui_msg should stop displaying
    // AES key segments
    unsigned long long int A1[2];
    unsigned long long int A2[2];
    unsigned long long int A3[2];
    unsigned long long int A4[2];
    // DMR LRRP 64-bit values
    unsigned long long int dmr_lrrp_source[2];
    unsigned long long int dmr_lrrp_target[2];
    // 1 when the slot's last data header addressed a talkgroup (G/I bit set). The header's G/I
    // bit is gone by the time the assembled PDU decrypts, and DMR radio ids share the
    // talkgroup's 24-bit space, so the --dmr-tg-key-csv lookup needs this recorded alongside
    // the target it qualifies.
    uint8_t dmr_data_target_is_group[2];
    // P25 trunking freq storage
    long int p25_vc_freq[2];
    /* With trunking off, the voice channel frequency a grant update named for the target of a call active on this
       carrier, kept per slot with that target (issue #575): a call takes it only when it has that target, never another
       call's (p25_conventional_grant_frequency()). */
    long int p25_conventional_grant_freq[2];
    uint32_t p25_conventional_grant_target[2];
    long int trunk_vc_freq[2]; // generic trunk-owner voice-channel frequencies
    // Trunking LCNs and maps
    long int trunk_lcn_freq[DSD_TRUNK_LCN_EMBEDDED];
    long int trunk_chan_map[DSD_TRUNK_CHAN_MAP_SIZE];
    uint16_t trunk_chan_map_used[DSD_TRUNK_CHAN_MAP_SIZE];
    uint32_t trunk_chan_map_used_count;
    uint64_t trunk_chan_map_seq;
    /* Scan-list tail beyond the DSD_TRUNK_LCN_EMBEDDED inline slots (NULL until a longer list is
     * imported). dsd_state_trunk_lcn_slot() abstracts both segments. Never inside
     * a UI_SNAPSHOT_COPY_RANGE: the first range ends at trunk_lcn_freq and members
     * from trunk_chan_map on are copied explicitly. */
    long int* trunk_lcn_freq_ext;
    size_t trunk_lcn_freq_ext_capacity;
    /* Optional operator-supplied name per scan-list row, indexed by LCN row index the
     * way dsd_state_trunk_lcn_slot() indexes the frequencies. NULL until a channel-map
     * CSV opts in with a `name` header column, and shorter than the list when only the
     * first rows are named -- read it through dsd_state_trunk_lcn_name_get(). Never
     * inside a UI_SNAPSHOT_COPY_RANGE, for the same reason as trunk_lcn_freq_ext above:
     * a byte copy of the pointer would alias the decoder's buffer into the snapshot. */
    char (*trunk_lcn_name)[DSD_CHANNEL_LABEL_SIZE];
    size_t trunk_lcn_name_capacity;
    /* Session-only "avoid" flag per scan-list row, indexed like trunk_lcn_name. NULL until
     * the operator avoids a row, and shorter than the list is normal -- read it through
     * dsd_state_trunk_lcn_avoid_get(). Never persisted; chan_map_adopt(),
     * svc_clear_channel_map() and DSD_APP_CMD_SCAN_AVOID_CLEAR drop it. Never inside a
     * UI_SNAPSHOT_COPY_RANGE, for the same reason as the two stores above. */
    uint8_t* trunk_lcn_avoid;
    size_t trunk_lcn_avoid_capacity;
    /* Sparse per-row key set per scan-list row, indexed like trunk_lcn_name. NULL until a
     * channel-map CSV opts in with a key-file or direct-key header column. Read it through
     * dsd_state_trunk_lcn_keys_get(); returned pointers are decoder-thread-only and invalidated
     * by later store growth. Never inside a UI_SNAPSHOT_COPY_RANGE, for the same reason as the
     * stores above -- and additionally because key material is never deep-copied into the
     * snapshot. */
    dsd_key_set* trunk_lcn_keys;
    size_t trunk_lcn_keys_capacity;
    /* Scan key swap state: the lazily captured global keys plus the active row set copy.
     * Sits in the same uncopied gap as the stores above. */
    dsd_key_set scan_keys_baseline;
    dsd_key_set scan_keys_active;
    uint8_t scan_keys_active_set;
    /* The avoided --trunk-scan targets the coordinator published (issue #672), trunk_scan_avoid_count entries in a heap
     * store of trunk_scan_avoid_capacity; NULL until the first publication. Only the coordinator fills it (its reserve
     * helper, stamping trunk_scan_avoid_rev); the coordinator's detach, initState() and freeState() release it. The
     * LCN umbrella free (dsd_state_trunk_lcn_free()) leaves it alone: a live state's list changes only with a new
     * trunk_scan_avoid_rev or, at initState(), a new state_instance, which the snapshot's gated copy keys on. Never
     * inside a UI_SNAPSHOT_COPY_RANGE, for the same reason as the stores above. */
    dsd_trunk_scan_avoid_entry* trunk_scan_avoids;
    size_t trunk_scan_avoid_count;
    size_t trunk_scan_avoid_capacity;
    /* Whether a frequency typed by hand could pick each --trunk-scan target (issue #644): one dsd_scan_entry_reason
     * byte per target, in the coordinator's target order (lists in order, each in its file's order), as
     * trunk_scan_entry_reason() decides it; trunk_scan_entry_reason_count entries in a heap store of
     * trunk_scan_entry_reason_capacity. Only the coordinator fills it, stamping trunk_scan_entry_rev when a byte or the
     * count changes; its detach, initState() and freeState() release it. Never inside a UI_SNAPSHOT_COPY_RANGE, as the
     * stores above. */
    uint8_t* trunk_scan_entry_reasons;
    size_t trunk_scan_entry_reason_count;
    size_t trunk_scan_entry_reason_capacity;
    // DMR Tier III: simple provenance/trust for learned LCN->freq mappings
    // 0=unset, 1=learned (unconfirmed), 2=trusted (confirmed on-current-site CC)
    uint8_t dmr_lcn_trust[0x1000];
    // DMR late entry MI
    uint64_t late_entry_mi_fragment[2][8][3];
    // Multi-key array
    unsigned long long int rkey_array[0x1FFFF];
    unsigned char rkey_array_loaded[0x1FFFF];
    // TETRA air-interface keys, one per network (--tetra-key). Kept here, outside every ui_snapshot.c copy range,
    // for the same reason as rkey_array.
    dsd_tetra_air_key tetra_air_keys[DSD_TETRA_AIR_KEY_SLOTS];
    // DMR talkgroup -> key ID override map (--dmr-tg-key-csv): a mapped talkgroup
    // selects its key id in place of the OTA-signaled one at key-activation time.
    // payload_keyid* stay the OTA truth; the map only steers the keyring lookup.
    //
    // Declared beside the keyring it indexes rather than beside the other DMR crypto state, for the
    // same reason rkey_array lives here: ui_snapshot.c copies positional byte ranges of dsd_state on
    // every telemetry publish and consume, and this write-once CLI table is not something the UI
    // renders. This region falls between two of those ranges, so it costs the snapshot nothing.
    uint32_t dmr_tg_key_map_tg[DSD_DMR_TG_KEY_MAP_MAX];
    uint8_t dmr_tg_key_map_kid[DSD_DMR_TG_KEY_MAP_MAX];
    int dmr_tg_key_map_count;
    // Per-slot applied-notice latch: one notice per call epoch. Epoch 0 is never a live call
    // (dsd_call_state_get only reports a hit for a non-zero epoch), so it doubles as "never noted".
    uint64_t dmr_tg_key_note_epoch[2];
    /* Own latch, not shared with dmr_tg_key_note_epoch: the applied and skipped notices report
       opposite outcomes, so one latch let whichever fired first silence the other for the whole
       epoch -- even after the situation changed (a key imported mid-call, for instance). */
    uint64_t dmr_tg_key_skip_epoch[2];
    // Temporary audio buffers
    float audio_out_temp_buf[160];
    float* audio_out_temp_buf_p;
    float audio_out_temp_bufR[160];
    float* audio_out_temp_buf_pR;
    //analog/raw signal audio buffers (float path for better SNR, convert to int16 at output)
    float analog_out_f[960]; // float buffer for analog monitor path
    short analog_out[960];   // int16 buffer for analog monitor output
    int analog_sample_counter;
    /* The auto squelch's gate flag for each sample of analog_out_f (DSD_SQUELCH_FLAG_CLOSED, 0 open), as the RTL stream
       read it with the sample, and the monitor sink's gain, which ramps between closed and open samples. */
    uint8_t analog_out_flags[960];
    /* The block before the monitor sink gate, handed to the NFM call while -P records with a pre-roll (issue #668,
       dsd_analog_call_block::heard): a scratch the block is copied into, never allocated per block. */
    float analog_heard_f[960];
    float analog_sink_gain;
    /* The level path's ramp-in after a tone verdict part-way through a block (issue #668): the samples after the block's
       ineligible start ramp up from silence over the sink gate's 5 ms, as under the auto squelch, carried on into the
       next block from analog_level_gain while analog_level_ramp is set. Off (0) otherwise: the level path plays each
       block whole. */
    uint8_t analog_level_ramp;
    float analog_level_gain;
    /* The speaker's own fade-in after blocks the monitor processed only for a per-transmission NFM recording (issue
       #637): the sink gain kept running for the recording, so the speaker ramps in from analog_speaker_gain when it
       opens mid-transmission. Off (0) otherwise, when the sink gain's own ramp is the speaker's. */
    uint8_t analog_speaker_ramp;
    float analog_speaker_gain;
    /* The rate the analog block being collected runs at, and what it started under: the PCM input rate and stream
       generations and, on RTL input, the stream generation of its samples (issue #633). A sample collected at another
       rate marks the block mixed: it neither plays nor goes to the -6 WAV. */
    int analog_block_rate_hz;
    uint32_t analog_block_rate_gen;
    uint32_t analog_block_pcm_gen;
    uint32_t analog_block_rtl_gen;
    uint8_t analog_block_mixed;
    /* The rate the analog sinks last said they had no memory to convert, so that is said once per rate. */
    int analog_sink_nomem_hz;
    //new stereo short sample storage
    short s_l[160]; //single sample left
    short s_r[160]; //single sample right
    /* Per slot: 1 when the vocoder left the current frame's short samples out of s_l/s_r (it staged silence, or
       skipped short staging), 0 when dsd_voice_stage_short_left/right() staged them there. The P25 Phase 2 playout
       reads it to tell decoded audio from silence (issue #651). */
    uint8_t mbe_short_silenced[2];
    /* Per slot: the vocoder's verdict on the slot's last voice frame (issue #655), 1 when it is muted: by encryption
       (judged by the protocol that owns the call, after the frame's keystream), the user's encrypted-audio mute,
       reverse mute (-q), or DMR mono not playing the slot. Short staging, the per-call WAV, MBE capture and the DMR
       mixes all read it, so they agree; see dsd_voice_crypto_audible() in <dsd-neo/core/audio.h>. */
    uint8_t mbe_slot_muted[2];
    short s_l4[18][160]; //quad sample for up to a P25p2 4V
    short s_r4[18][160]; //quad sample for up to a P25p2 4V
    /* Per slot, per frame of the DMR superframe mix (s_l4/s_r4 rows 0-2): 1 when the row holds the slot's own audio the
       vocoder staged this burst, 0 for silence, a frame it left out, or nothing yet. The two-slot mono mix sums only
       fresh rows, so a silent or duplicated slot never counts as a second talker (issue #518). */
    uint8_t s4_fresh[2][3];
    //new stereo short sample storage tapped from 48_k internal upsampling
    short s_lu[160 * 6];     //single sample left
    short s_ru[160 * 6];     //single sample right
    short s_l4u[4][160 * 6]; //quad sample for up to a P25p2 4V
    short s_r4u[4][160 * 6]; //quad sample for up to a P25p2 4V
    int audio_out_idx;
    int audio_out_idx2;
    int audio_out_idxR;
    int audio_out_idx2R;
    float center;
    int jitter;
    int synctype;
    /* The protocol that owns a shared vocoder invocation; synctype may temporarily select another decoder. */
    int receive_context_protocol;
    uint8_t receive_context_active;
    float min;
    float max;
    float lmid;
    float umid;
    float minref;
    float maxref;
    float lastsample;
    float sbuf[128];
    int sidx;
    float maxbuf[1024];
    float minbuf[1024];
    double maxbuf_sum;
    double minbuf_sum;
    int minmax_sum_window;
    int midx;
    char err_str[64];
    char err_buf[64];
    char err_strR[64];
    char err_bufR[64];
    char fsubtype[16];
    char ftype[16];
    /* Free-running count of symbols getSymbol() has produced. Unsigned because it is only
     * ever incremented and differenced modulo 2^32: a signed counter overflowed after about
     * 5.2 days at 4800 symbols/s, which is undefined behaviour and aborts a UBSan build
     * (#395). Readers must treat it as wrapping -- compare differences, never magnitudes. */
    uint32_t symbolcnt;
    /* Symbols the grid produced, on every input path, since the state was set up. Unlike symbolcnt no protocol resets
       it, so a DMR slot measures elapsed superframes on it (issue #729). Only DSP advances it. */
    uint64_t symbol_clock;
    /* 1 while getSymbol() reads a symbol's samples: a carrier change that runs then (an I/Q replay retune) splits that
       symbol between the two carriers (dsd_state_note_carrier_change()). */
    uint8_t symbol_read_active;
    /* Bumped whenever symbol_clock stops describing one continuous received stream: an RTL stream flush or an input
       switch (DSP bumps it) or a scan target change (the engine does). Carrier changes are compared on carrier_seq. A
       span measured across two epochs is no span. */
    uint32_t symbol_clock_epoch;
    uint32_t symbol_clock_input; /* dsd_opts::pcm_input_generation the last symbol was read under (DSP's) */
    /* A rigctl peer confirmed a retune (issue #834): the audio input still holds the frequency left's samples, which
       the decoder thread drops at its next input read (dsd_symbol_apply_input_drop()), as an RTL retune's flush
       drops them. Decoder-thread owned: a tune off it posts a mark instead, which the decoder thread takes at its
       next input read (frame_sync_take_unflushed_retunes()), or at the tune notice's reconcile if no read came first
       (dsd_frame_sync_apply_off_thread_tunes()), and sets this then. A post an input replacement retired is never
       taken (dsd_frame_sync_forget_unflushed_retunes()). */
    uint8_t input_drop_pending;
    /* dsd_opts::pcm_input_generation when the drop was asked for: a drop meant for an input since replaced (an input
       switch, a reopened stream) is cleared unrun. */
    uint32_t input_drop_generation;
    /* Where the input stood before the retune was asked for (dsd_input_backlog_mark()): the drop takes only what was
       queued by then, never what arrived after it. The newest mark asked for on the input, kept once carried out: an
       older one asked for later never replaces it (dsd_frame_sync_request_input_drop()). */
    dsd_input_cut input_drop_cut;
    /* Set while the DSP sync anchor (state-ext slot 12, src/dsp/symbol_anchor.c) records or holds a move for the grid;
       the grid looks the anchor up only then. */
    uint8_t symbol_anchor_hot;
    uint32_t
        datascope_symbolcnt_mark; /* symbolcnt at the datascope's last refresh: the refresh never resets symbolcnt */
    int symbolc;
    uint8_t symbol_replay_format;         /* DSD_SYMBOL_REPLAY_FORMAT_* */
    uint8_t symbol_replay_header_checked; /* header probe already done for current symbol file */
    uint8_t symbol_replay_has_soft;       /* current replay record supplied soft metrics */
    dsd_dibit_soft_t symbol_replay_soft;
    float symbol_replay_soft_symbol;
    /* The symbol the replay reader (soft capture or float symbol file) just gave had no usable stored amplitude
       (NaN, infinite, out of range, or past the end) and stands in as 0: an erasure, whatever the thresholds. */
    uint8_t symbol_replay_symbol_unusable;
    unsigned int symbol_replay_soft_records;
    unsigned int symbol_capture_soft_records;

    /* RTL DSP direct-output cache. The RTL demod thread produces direct FSK/CQPSK
       blocks; this lets getSymbol() consume them without one ring read per sample. */
    float rtl_symbol_cache[DSD_RTL_SYMBOL_CACHE_CAP];
    int rtl_symbol_cache_pos;
    int rtl_symbol_cache_len;
    int rtl_symbol_cache_output_kind;
    int rtl_symbol_cache_channel_profile;
    int rtl_symbol_cache_symbol_rate_hz;
    int rtl_symbol_cache_levels;
    uint32_t rtl_symbol_cache_generation;
    int rtl_symbol_cache_published_pending;
    /* The I/Q replay batch the cached samples come from: the capture time it spans, its sample count, and the batch
       index of rtl_symbol_cache[0]. Each sample the cache hands out runs the decode clock's media time to its own
       capture time (issue #572); a count of 0, as after a live read, runs nothing. */
    uint64_t rtl_symbol_cache_media_start_ns;
    uint64_t rtl_symbol_cache_media_duration_ns;
    uint32_t rtl_symbol_cache_media_count;
    uint32_t rtl_symbol_cache_media_first_index;
    /* The centre in Hz that batch was captured on, which each sample the cache hands out publishes as
       dsd_opts::iq_replay_center_freq (issue #575); 0, as after a live read, publishes nothing. */
    uint32_t rtl_symbol_cache_center_hz;
    /* The stream's discontinuity count the cached samples carry (D5): an I/Q replay batch's own, a live read's as read
       after it. The cache hands none of them out while it is newer than the count the decoder has taken
       (rtl_stream_gap_seq). */
    uint64_t rtl_symbol_cache_boundary_seq;
    int rtl_fsk_sps_num;
    int rtl_fsk_sps_den;
    int rtl_fsk_sps_accum;

    /* C4FM timing assist (clock loop hinting). Lightweight EL/M&M error drives
       occasional ±1 nudges of symbolCenter; disabled by default. */
    int rf_mod;
    /* M17 polarity auto-detection: 0=unknown, 1=normal, 2=inverted.
     * Set when preamble detected; overridden if user specifies -xz. */
    int m17_polarity;
    /* Multi-rate sync hunting: cycle through symbol-rate candidates when no sync found.
     * The hunt spends a symbol budget rather than counting sync attempts, because an
     * isolated sync that no protocol turns into a frame must not buy the profile more
     * time (see frame_sync_no_sync_sps_hunt()).
     * sps_hunt_counter: symbols the search burned that no frame handler claimed. Symbols
     *   spent looking for a sync count up; symbols a handler consumed on one sync are
     *   debited back, floored at zero, so a profile carrying traffic sits at zero and a
     *   profile matching nothing reaches its dwell. The budget belongs to the profile, so
     *   zeroing this alone is not a complete reset: a profile change owes this and
     *   sps_hunt_symbolcnt_mark together. frame_sync_apply_sps_hunt_profile() does both
     *   whenever it moves the index, so its callers need not -- but it is not the only way
     *   sps_hunt_idx moves, and the sites that assign the index directly still owe both
     *   themselves (#394). Most of them still do not: the app-control and engine
     *   retune paths (svc_publish_symbol_profile(), set_cc_symbol_timing(),
     *   dsd_engine_select_p25_sps_profile(), no_carrier_apply_p25_cc_symbolrate() and the
     *   two trunk-scan target helpers) zero the counter and leave the anchor where it was,
     *   which is harmless only because whatever that anchor then credits is debited from the
     *   counter they just zeroed and floored there; the -m2/-m3/-m4 branches of the CLI 'm'
     *   case do neither, and are benign only because they run before the first
     *   getFrameSync(). dsd_frame_sync_sps_hunt_restart_dwell() is the one that pays in
     *   full, and is what a new direct assigner should call.
     * sps_hunt_counter_at_entry: sps_hunt_counter as this search cycle began, so a frame
     *   the engine declined to dispatch can hand back exactly what that cycle's search
     *   charged and nothing else (DSD_FRAME_VERDICT_WITHHELD, #392). Restoring to a
     *   snapshot rather than subtracting a count keeps it exact without a second counter:
     *   charging happens only inside frame_sync_advance_sync_window(), between this being
     *   stamped and the verdict being read. The restore is clamped so it can only lower the
     *   counter, which is what makes it safe against the resets that fire in between -- a
     *   profile change, a retune, a trunk-scan target switch -- none of which this can undo.
     * sps_hunt_symbolcnt_mark: dsd_state::symbolcnt as getFrameSync() last returned, so
     *   the next call can measure what the handler consumed in between. It shares that
     *   field's unsigned wrapping type, so the difference stays exact across the counter's
     *   2^32 rollover. Credit is per sync and only counts once it reaches a frame's worth,
     *   which is what keeps the dwell independent of how often an unproductive matcher fires.
     *   Re-anchored alongside the counter whenever frame_sync_apply_sps_hunt_profile() moves
     *   the index, so a fresh budget is never paired with an anchor taken under the outgoing
     *   profile. Inside getFrameSync() the mark is already current at every such call, so that
     *   half is contract rather than repair; it is what a direct assigner would have to do for
     *   itself.
     * sps_hunt_last_frame_verdict: what the last frame handler made of what it consumed,
     *   as a dsd_frame_verdict (engine/protocol_dispatch.h). A field rather than a return
     *   value because frame sync reads it at the next getFrameSync() entry, not at the
     *   call site. Zero is DSD_FRAME_VERDICT_PRODUCTIVE, so a handler that reports nothing
     *   -- and a zeroed dsd_state -- is credited as having decoded a frame; only a
     *   protocol that ran a check and failed it debits nothing (#391), and only one whose
     *   check proves the profile restarts the dwell outright (#400). A frame the engine
     *   declined to dispatch at all is neither, and refunds its own search instead (#392).
     *   Strictly per frame,
     *   so unlike the two fields above it owes a profile change nothing: processFrame()
     *   re-stamps it on every dispatch and
     *   frame_sync_sps_hunt_note_handler_consumption() clears it on every read, so it
     *   cannot survive into the profile that follows.
     * sps_hunt_idx: current rate/profile index
     * (0=4800/4-level, 1=2400/4-level, 2=9600/binary, 3=6000/4-level, 4=4800/binary) */
    int sps_hunt_counter;
    uint32_t sps_hunt_symbolcnt_mark;
    int sps_hunt_last_frame_verdict;
    int sps_hunt_counter_at_entry;
    int sps_hunt_idx;
    /* 1 while a Signal search probe identifies an Auto detection (issue #804): the unlocked hunt then steps in the
     * search order and spends the search dwell (dsd_frame_sync_sps_hunt_dwell_passes()). The hunt samples
     * dsd_frame_sync_hook_signal_search_probe() into it when it changes profile or resets its acquisition, and again
     * when a dwell it shortened is spent, never per symbol: a probe that evidence ended since leaves the carrier that
     * confirmed its ordinary dwell, and the next step the ordinary order. */
    uint8_t sps_hunt_search_order;
    /* Parity toggle for the P25p1 modulation probe: which modulation the next hunt re-entry
     * into the 4800/4-level profile watches. Zero-init keeps the first re-entry on C4FM.
     * p25_p1_mod_probe_active marks the one dwell a probe is on trial for, so the modulation
     * votes cannot take the demodulator back before the trial has had a chance to decode
     * anything -- entering GFSK needs a single vote, which is a few dozen symbols. */
    int p25_p1_mod_probe_next_qpsk;
    int p25_p1_mod_probe_active;
    /* The chain comparison the first validated P25p1 frame of an acquisition starts (see
     * dsd_p25p1_mod_compare). While it runs, p25_p1_mod_probe_active keeps the votes off both windows. */
    dsd_p25p1_mod_compare p25_p1_mod_compare;
    /* Where the last accepted dPMR FS2 sync sat in dsd_state::symbolcnt, and whether one has
     * been seen at all. dPMR and NXDN48 are the two candidates on the 2400/4 profile, and their
     * matchers are not comparable: FS2 is one exact 12-symbol pattern, while the NXDN matcher
     * takes five variants per polarity over ten sign-sliced symbols and so fires on about 1% of
     * arbitrary windows. The 372 dibits behind an accepted FS2 are dPMR's frame, and an NXDN
     * accept inside them consumes symbols that frame needed and warm-starts the slicer from ten
     * symbols of dPMR payload -- which is what left AUTO decoding corrupted dPMR identities that
     * the native preset reads cleanly (#374). The span is read by src/dsp only, through
     * dsd_frame_sync_suppress_nxdn48_sync(); the stamp wraps with symbolcnt and is compared as a
     * modular difference, so a rollover mid-frame stays exact. */
    uint32_t dpmr_fs2_frame_symbolcnt;
    uint8_t dpmr_fs2_frame_valid;
    /* NXDN96 frame synchronization: the frame sync word hits lately seen (where in dsd_state::symbolcnt, and the
     * polarity, as the sync type) and the lock a transmission's accepted FSWs keep (src/dsp/dsd_frame_sync.c), moved
     * by the LICHs their frames read (dsd_nxdn96_sync_note_lich()). Cleared with the M17 join history (no carrier, an
     * M17 EOT, an acquisition reset, any carrier change: dsd_state_note_carrier_change(), every accepted trunk retune),
     * by S1 wrong LICHs in a row, and at a carrier boundary inside an NXDN frame. The decoder thread's: a retune made
     * off it leaves the clear to the frame sync (dsd_frame_sync_apply_off_thread_tunes()). */
    dsd_nxdn96_sync nxdn96_sync;
    /* NXDN48's accept (two sign hits at any distance, src/dsp/dsd_frame_sync.c): where its last hit was
     * (dsd_state::symbolcnt) and of which polarity (the sync type, 0 none), and whether the hit an accept took had one
     * of its polarity one frame before it, as a transmission's frames do: the frame's checks may then confirm it at
     * once (nxdn_confirm_note_frame_start()). */
    uint32_t nxdn48_hit_symbol;
    int nxdn48_hit_type;
    uint8_t nxdn48_accept_corroborated;
    /* The same idea one profile up, where 4800/4 carries P25p1, DMR, NXDN96, YSF and M17 at once.
     * P25p1's sync is one of two exact 24-symbol patterns, so it fires on noise about once per
     * 8.4 million windows; NXDN96's takes five variants per polarity over ten sign-sliced symbols
     * and fires on roughly 1%, and M17's preamble is any alternating run at all. Inside the frame
     * a P25p1 sync opened, those two are wrong by construction, and what they cost is measurable:
     * on tests/fixtures/iq/p25p1_c4fm_cc.iq.json the native preset decodes 26 NIDs and AUTO
     * decoded none, every sync reading NAC 000 duid:EE, because the false accepts consume the
     * symbols the frame needed, warm-start the slicer from P25 payload, and clobber the
     * lastsynctype that keeps use_symbol()'s C4FM threshold tracker engaged between syncs (#388).
     * Stamped only when the C4FM chain carried the sync: on CQPSK the NID is sliced by the QPSK
     * chain and the NXDN matcher's level blend is the wideband tracker that chain relies on, so a
     * CQPSK accept clears the span instead of opening one. A GFSK vote landing mid-span leaves it
     * standing -- the flap is what the span exists to survive. Read by src/dsp only, through
     * dsd_frame_sync_suppress_4800_4_for_p25p1_frame(); compared as a modular difference, so a
     * symbolcnt rollover mid-frame stays exact. */
    uint32_t p25_p1_c4fm_frame_symbolcnt;
    uint8_t p25_p1_c4fm_frame_valid;
    /* Whether the C4FM P25p1 sync last accepted set the slicer levels from its word (the warm start ran and returned
     * DSD_WARM_START_OK): with small tracker windows use_symbol() then holds those levels through the frame. Set by
     * every P25p1 accept (frame_sync_p25p1_c4fm_warm_start()). */
    uint8_t p25_p1_c4fm_sync_levels;
    /* Which SPS profile a protocol last passed a content check on, when, and whether any has
     * been recorded at all. The two spans above cover a frame another protocol is in the middle
     * of; this one covers the transmission a protocol has been decoding, which is the case
     * neither of them reaches: under AUTO the hunt rotates off 2400/4 while an NXDN48 call is
     * still on air, and by the time it comes round to 4800/4 the NXDN96 and M17 matchers there
     * claim the transmission that never stopped (#445).
     *
     * The flag, not the index, says whether anything is armed -- profile index 0 is 4800/4, so a
     * zeroed state would otherwise read as a proof on that profile at symbol zero. Protocol-blind
     * on purpose: dPMR's CCH CRC-7 and NXDN's confirmation CRCs both prove 2400/4, and a live
     * transmission of either faces the same claimants on the profile the hunt steps to.
     *
     * Written by the protocol handlers through dsd_frame_sync_note_profile_proof(), deliberately
     * not derived from DSD_FRAME_VERDICT_PROFILE_PROVEN: that verdict restarts the hunt's dwell,
     * and measurement on the #445 capture showed doing so for NXDN costs more decoded calls than
     * it wins (see src/engine/dispatch/dispatch_nxdn.c). Recording the proof is separable from
     * acting on it, and only the recording is wanted here.
     *
     * Not cleared with the carrier, and must not be: every step of the hunt runs noCarrier(), so
     * clearing it there would erase the stamp exactly when the transmission it vouches for is
     * still on air. It expires on its own instead. Read by src/dsp only, through
     * dsd_frame_sync_suppress_4800_4_for_2400_4_transmission(); compared as a modular difference,
     * so a symbolcnt rollover stays exact. */
    int profile_proof_idx;
    uint32_t profile_proof_symbolcnt;
    uint8_t profile_proof_valid;
    int lastsynctype;
    int lastp25type;
    int offset;
    int carrier;
    char tg[25][16];
    int tgcount;
    uint8_t eh_index;
    uint8_t eh_slot;
    int nac;
    int errs;
    int errs2;
    int errsR;
    int errs2R;
    int mbe_file_type;
    int mbe_file_c0_valid; /* the last .amb record read carried its C0 error count (DSD_MBE_AMB_ERR_FLAG) */
    int optind;
    // CLI argv/argc snapshot for file playback modes (set by frontend)
    int cli_argc_effective;
    char** cli_argv;
    // User config autosave state (set by frontend when config is active)
    int config_autosave_enabled;
    char config_autosave_path[1024];
    int numtdulc;
    int firstframe;
    char slot0light[8];
    /* Display only: the gain the digital voice chain last applied on slot 1 and slot 2, in dB over the decoder's level
       (`-g 1`), set by every chained frame (<dsd-neo/core/voice_chain.h>); and the analog monitor's, in dB over `-n
       50`. Their adaptation state stays with the decoder (state extensions). */
    float aout_gain;
    float aout_gainR;
    float aout_gainA;
    int samplesPerSymbol;
    int symbolCenter;
    char algid[9];
    char keyid[17];
    int currentslot;
    int hardslot;
    int p25kid;
    int payload_algid;
    int payload_algidR;
    int payload_keyid;
    int payload_keyidR;
    int payload_mfid;
    int payload_mfidR;
    int p25vc;
    int M;

    //AES Key Segments
    int aes_key_loaded[2];
    uint8_t aes_key_segments[2];

    //xl specific, we need to know if the ESS is from HDU, or from LDU2
    int xl_is_hdu;

    unsigned int debug_audio_errors;
    unsigned int debug_audio_errorsR;
    unsigned int debug_header_errors;
    unsigned int debug_header_critical_errors;

    // NID BCH correction statistics (P25 Phase 1)
    unsigned int nid_corrections_total; /**< Running total of NID BCH corrections applied */
    unsigned int nid_failures_total;    /**< Running total of NID decode failures */
    unsigned int nid_parity_overrides;  /**< Count of accepted final parity-bit mismatches */

    int debug_mode; //debug misc things

    // Last dibit read
    int last_dibit;
    uint8_t p25_cqpsk_dibit_map_idx; // OP25-compatible CQPSK orientation map

    //input sample buffer for monitoring Input
    short input_sample_buffer;  //HERE HERE
    short pulse_raw_out_buffer; //HERE HERE

    unsigned int dmr_color_code;
    unsigned int dmr_t3_syscode;
    unsigned int nxdn_last_ran;
    /* 1 while nxdn_last_ran holds a value that is not a decoded RAN, which the terminal shows in its place: an IDAS
     * (Type-D) carrier's SCCH area bit, or the fixed 7 a DCR transmission is given. 0 once a RAN field
     * (CAC, FACCH2/UDCH, SACCH, site information) writes it. Every write of a value sets it (the (unsigned)-1 resets
     * need not), and only a RAN is read as the carrier's access code (issue #575). */
    uint8_t nxdn_last_ran_stand_in;
    /* The NXDN data call header bound to the assembly in dmr_pdu_sf[0] (src/protocol/nxdn/nxdn_data_call.c, issue
     * #800 B6): the reception (origin) and carrier (carrier_seq) the checked header was heard on, and when (decode
     * clock). A payload assembles under the header only while all three still hold; a failed FACCH2/UDCH or
     * FACCH3/UDCH2 CRC and a rejected header drop it. origin.valid is 0 when no header is bound. */
    dsd_position_origin nxdn_data_origin;
    uint64_t nxdn_data_header_ms;
    uint32_t nxdn_data_carrier_seq;
    unsigned int nxdn_cipher_type;
    unsigned int nxdn_key;

    /* NXDN cipher-classification hysteresis (src/protocol/nxdn/nxdn_enc_class.c). The cipher
     * field reaches the decoder from several channels (VCALL, SACCH-2, SCCH) whose FEC/CRC can
     * accept a miscorrected payload, and under --enc-lockout a single non-clear observation
     * used to write a session-permanent blocking talkgroup entry and force the channel
     * released. Observations apply tentatively and must repeat before they can flip an
     * established classification or arm the lockout; user-forced scrambler modes and the
     * keyloader apply as authoritative. Values are the observed cipher plus one; 0 = none. */
    uint8_t nxdn_cipher_class;         /* applied cipher observation + 1; 0 = unclassified */
    uint8_t nxdn_cipher_class_est;     /* classification corroborated (authoritative or repeat) */
    uint8_t nxdn_cipher_class_pending; /* quarantined contradicting candidate + 1; 0 = none */
    /* The same hysteresis over the over-the-air observations alone: a forced cipher (nxdn_cipher_force()) never
     * touches it, so it says what the air corroborated, which is what a call record may show as received. */
    uint8_t nxdn_cipher_rx_class;
    uint8_t nxdn_cipher_rx_est;
    uint8_t nxdn_cipher_rx_pending;

    /* NXDN frame-content confirmation (src/protocol/nxdn/nxdn_confirm.c). A sync word plus
     * a LICH is not enough to believe a frame: both are weak enough that receiver noise
     * clears them regularly. Until the frame body passes a CRC, the decoder holds back
     * everything a listener would read as a real transmission -- the scanner hold, voice,
     * the RAN, the call record. See issue #398.
     * nxdn_confirmed: this transmission has produced CRC-verified content.
     * nxdn_confirm_weak_streak: consecutive frames carrying only short-CRC evidence.
     * nxdn_confirm_frame_evidence: strongest nxdn_evidence seen since begin_frame().
     * nxdn_confirm_scch_streak: consecutive frames carrying a CRC-good SCCH, whatever else they carried; the Type-D
     * site test of the control-channel hunt reads it (nxdn_confirm_note_scch()).
     * nxdn_confirm_frame_scch: this frame carried one.
     * nxdn_confirm_scch_generation: the trunk tuning generation the run counts in; a completed tune restarts it.
     * nxdn_confirm_frame_isolated: this frame does not run on from a frame read one frame before it
     * (nxdn_confirm_note_frame_start()), so it starts the streaks over.
     * nxdn_confirm_strong_waits: nor did its sync word follow another one frame before it, so its strong check waits,
     * unless another check of the frame passed too (nxdn_confirm_frame_checks counts them).
     * nxdn_confirm_strong_pending: the last frame read, an isolated one, passed a strong check, which confirms the
     * transmission if the next frame runs on from it.
     * nxdn_confirm_spacing_due: the frame just started ran on from such a frame and so confirmed it
     * (nxdn_confirm_note_frame_start()); nxdn_confirm_begin_frame() hands it to nxdn_confirm_frame_spaced, this frame's
     * spacing proof, counted once as proof of the frame before's content (nxdn_confirm_frame_content_counted()).
     * nxdn_confirm_last_frame_valid / nxdn_confirm_last_frame_symbol: where the last frame read began
     * (dsd_state::symbolcnt), the run's measure. */
    uint8_t nxdn_confirmed;
    uint8_t nxdn_confirm_weak_streak;
    uint8_t nxdn_confirm_frame_evidence;
    uint8_t nxdn_confirm_scch_streak;
    uint8_t nxdn_confirm_frame_scch;
    uint8_t nxdn_confirm_frame_isolated;
    uint8_t nxdn_confirm_strong_waits;
    uint8_t nxdn_confirm_frame_checks;
    uint8_t nxdn_confirm_strong_pending;
    uint8_t nxdn_confirm_spacing_due;
    uint8_t nxdn_confirm_frame_spaced;
    uint8_t nxdn_confirm_last_frame_valid;
    uint32_t nxdn_confirm_last_frame_symbol;
    uint64_t nxdn_confirm_scch_generation;

    NxdnElementsContent_t NxdnElementsContent;

    char ambe_ciphered[49];
    char ambe_deciphered[49];

    unsigned int color_code;
    unsigned int color_code_ok;
    uint8_t dmr_confidence_locked;
    uint8_t dmr_confidence_color_code;
    uint8_t dmr_confidence_candidate_cc;
    uint8_t dmr_confidence_candidate_count;
    uint8_t dmr_confidence_voice_sync_seen[2];
    uint8_t dmr_confidence_voice_open[2];
    uint8_t dmr_confidence_voice_count[2];
    uint8_t dmr_confidence_mismatch_count;
    /* RAS signature bursts heard on this carrier (dmr_ras.c), saturating at the two that confirm RAS on it; the
       confirmation shows through the received identity (DSD_RXID_DMR_RAS). Decoder thread only; dmr_ras_reset() clears
       it at every carrier change. */
    uint8_t dmr_ras_signatures;
    /* Decode-clock seconds DMR content last passed the colour-code confidence gate (dmr_confidence.c), 0 never. Written
       only from processFrame() under the P25 SM tick guard and never cleared, not even by a carrier boundary: a startup
       control-channel hunt restarts its window from it (issue #703). */
    double dmr_confidence_lock_m;
    /* Decode-clock seconds the slot's own voice last passed the confidence gate with the slot's voice gate open
       (dmr_confidence_note_voice_burst()), 0 never; cleared with the slot's voice gate. A followed call's hangtime runs
       from it: a voice sync alone, which a rejected burst can carry, never holds the call. */
    double dmr_confidence_voice_m[2];
    /* Decode-clock seconds an NXDN frame's own CRCs last confirmed its transmission (nxdn_confirm_end_frame()), 0
       never. Decoder thread only, never cleared: the NXDN control-channel hunt and the P25 startup hunt restart their
       windows from it. */
    double nxdn_confirm_lock_m;
    unsigned int PI;
    unsigned int PI_ok;
    unsigned int LCSS;
    unsigned int LCSS_ok;

    unsigned int dmr_fid;
    unsigned int dmr_so;
    unsigned int dmr_flco;

    unsigned int dmr_fidR;
    unsigned int dmr_soR;
    unsigned int dmr_flcoR;

    /* Live slot crypto captured by the DMR terminator handler just before its reset, so the
     * heal of a voice burst mis-typed as a terminator can restore exactly what the vocoder was
     * decrypting with. Deliberately limited to what the canonical dsd_call_snapshot cannot
     * supply -- the FID and service options the Basic Privacy gates require, the MI as the
     * superframe machinery last advanced it (the snapshot's MI can lag it), and the vendor
     * late-entry mode (dmr_le_vendor); ALGID and key id
     * are read back from the snapshot the reacquire hook receives, so they have one source of
     * truth. Indexed by slot; epoch ties each capture to the ended epoch it belongs to, so a
     * stale stash can never be applied to a later call, and the engine's retune/no-carrier
     * resets clear dmr_heal_valid alongside the payload crypto so no stash outlives the channel
     * it was captured on. Owned by src/protocol/dmr; the canonical layer never touches it. */
    unsigned long long int dmr_heal_mi[2];
    unsigned long long int dmr_heal_epoch[2];
    unsigned int dmr_heal_fid[2];
    unsigned int dmr_heal_so[2];
    uint8_t dmr_heal_le_vendor[2];
    /* The slot's dmr_crypto_inherited mark and tuple at the stash, restored with the live values on a heal. */
    uint8_t dmr_heal_inherited[2];
    int dmr_heal_inherited_algid[2];
    int dmr_heal_inherited_keyid[2];
    uint8_t dmr_heal_valid[2];
    /* The voice crypto continuity (dmr_vc_*, dmr_crypto_pi_verified) as the stash found it (issue #729). */
    uint8_t dmr_heal_vc_ref_state[2];
    uint64_t dmr_heal_vc_ref_clock[2];
    uint32_t dmr_heal_vc_ref_epoch[2];
    uint32_t dmr_heal_vc_ref_carrier[2];
    uint8_t dmr_heal_vc_untrusted[2];
    uint8_t dmr_heal_pi_verified[2];
    /* The live ALG ID and key id DMR last published into each slot's call epoch, whether or not the record took them
     * as the call's own (dsd_call_crypto_update::carried). The heal restores these for that epoch, which is what the
     * decoder has always restored: the call record no longer holds carried values. */
    uint64_t dmr_live_pub_epoch[2];
    int dmr_live_pub_algid[2];
    int dmr_live_pub_keyid[2];

    /* Per-slot DMR encryption-classification hysteresis (src/protocol/dmr/dmr_enc_class.c).
     * The service-option privacy bit arrives through channels of very different reliability --
     * a voice LC header behind a 16-bit masked CRC, an embedded LC behind a 5-bit checksum, and
     * on RAS systems no verifiable CRC at all -- so the classification the enc lockout and the
     * audio gate act on is corroborated here: strong evidence applies at once, weak evidence
     * applies tentatively and must repeat before it can flip an established classification or
     * arm the lockout. Indexed by slot. */
    uint8_t dmr_enc_class[2];         /* applied classification: 0 none, 1 clear, 2 encrypted */
    uint8_t dmr_enc_class_est[2];     /* classification corroborated (strong LC or matching repeat) */
    uint8_t dmr_enc_class_pending[2]; /* quarantined contradicting candidate (0 none, 1 clear, 2 enc) */
    /* The receiver moved off a carrier or released its call, and the slot's call has not said yet whether it is
     * encrypted (dmr_enc_class_hold()): its voice is held, as an X2-TDMA call's opening frames are, until its own LC or
     * PI header says (dmr_enc_class_release_hold()). 0 when a run starts, whatever an earlier run on the same state
     * left (a host may run one state more than once). */
    uint8_t dmr_enc_class_held[2];
    /* Whether the receiver has landed on a carrier yet in this run (any landing: the run's first stream, a tune, a scan
       row or park; dsd_engine_note_run_start()). The run's first landing holds no DMR slot's voice; every later one,
       any carrier boundary or trunk-scan park, does. A run starts landed unless a trunk scan configured for it
       (--trunk-scan) is to make its first landing (a -Y run lands where its stream opens, decoding there until its
       first step); a state outside any run (initState()) counts as landed. */
    uint8_t run_landed;

    /* Per-slot, per-call DMR vendor late-entry mode (DMR_LE_VENDOR_* in <dsd-neo/protocol/dmr/dmr.h>, 0 none), set
     * from verified Kirisun/Hytera Enhanced signalling. The user's late-entry setting stays in opts->dmr_le, which
     * decoding never writes (issue #657). */
    uint8_t dmr_le_vendor[2];

    /* A checked DMR PI header decoded while no call was active on the slot (its voice LC header was lost): the ALG ID
     * and key id it carried, with the DSD_CALL_CRYPTO_RX_* bits it received (<dsd-neo/core/call_state.h>), held for the
     * call the next checked LC opens on the slot, which receives them (dmr_flco.c). Cleared when they transfer, at the
     * slot's terminator, a carrier boundary, a retune and the no-carrier reset (dmr_pi_precall_reset()). Owned by
     * src/protocol/dmr. */
    uint8_t dmr_pi_precall_rx[2];
    uint8_t dmr_pi_precall_algid[2];
    uint16_t dmr_pi_precall_kid[2];
    /* Decode-clock instant each held PI was decoded; it transfers only within DMR_PI_PRECALL_HOLD_S. */
    double dmr_pi_precall_m[2];
    /* The slot's live ALG ID and key id as a call found them when it replaced one whose terminator was missed. The
     * decoder keeps decrypting with them, as it always has; they are the replaced call's, so while the live values
     * still equal them the new call publishes them as carried (dsd_call_crypto_update::carried), never as its own.
     * Cleared by any PI header, a late-entry SB identifier, once the live values change or are the decoder's own choice
     * for the new call (forced or key-inferred), and with the held PI (dmr_pi_precall_reset()). */
    uint8_t dmr_crypto_inherited[2];
    int dmr_crypto_inherited_algid[2];
    int dmr_crypto_inherited_keyid[2];

    char slot1light[8];
    char slot2light[8];
    int directmode;

    int dmr_stereo_payload[144];    //load up 144 dibit buffer for every single DMR TDMA frame
    uint8_t dmr_stereo_reliab[144]; //parallel reliability for stereo cache (0..255)
    int data_header_blocks[2];      //collect number of blocks to follow from data header per slot
    int data_block_counter[2];      //counter for number of data blocks collected
    uint8_t data_header_valid[2];   //flag for verifying the data header if still valid (in case of tact/burst fec errs)
    uint8_t data_header_padding[2]; //collect number of padding octets in last block per slot
    uint8_t data_header_format[2];  //collect format of data header (conf or unconf) per slot
    uint8_t data_header_sap[2];     //collect sap info per slot
    uint8_t data_p_head[2];         //flag for dmr proprietary header to follow
    uint8_t data_header_dd_format[2];   //transient per-slot DMR Defined Data format
    uint8_t data_header_bit_padding[2]; //transient per-slot DMR short-data padding in bits

    //new stuff below here
    uint8_t data_conf_data[2];   //flag for confirmed data blocks per slot
    uint8_t data_block_poc[2];   //padding octets in the header (needed for Data PDU Decryption)
    uint16_t data_byte_ctr[2];   //number of bytes acculumated
    uint8_t data_ks_start[2];    //where the start of the keystream should be applied to PDU data
    uint8_t udt_uab_reserved[2]; //UDT: header UAB indicates reserved/unknown count (use CRC-based EOM)
    uint8_t dmr_pdu_sf
        [2][24 * 128]; //unified pdu 'superframe' //[slot][byte] -- increased capacity to 127(+1) full rate blocks
    uint8_t cap_plus_csbk_bits[2][12 * 8 * 8]; //CSBK Cap+ FL initial and appended block bit storage, by slot
    uint8_t cap_plus_block_num[2];             //received block number storage -- per timeslot
    uint8_t cap_plus_csbk_crc_invalid[2];      //DSD_CRC_* flags of every fragment in cap_plus_csbk_bits, by slot
    // Per-block CRC verdict on confirmed data: 1 good, 0 failed, DMR_DATA_BLOCK_CRC_RAS (2) a confirmed block whose
    // CRC9 failed but which -F accepted as RAS. Block 0 is the header and only ever holds 0 or 1; blocks 1..127
    // follow it (Blocks to Follow is 7 bits, TS 102 361-1 table 9.34).
    uint8_t data_block_crc_valid[2][128];
    // Confirmed data sequence tracking (DBSN expected per slot)
    uint8_t data_dbsn_expected[2];
    uint8_t data_dbsn_have[2];
    char dmr_embedded_signalling
        [2][7]
        [48]; //embedded signalling 2 slots by 6 vc by 48 bits (replacing TS1SuperFrame.TimeSlotRawVoiceFrame.Sync structure)

    char dmr_cach_fragment[4][17]; //unsure of size, will need to check/verify
    int dmr_cach_counter;          //counter for dmr_cach_fragments 0-3; not sure if needed yet.

    //dmr talker alias new/fixed stuff
    uint8_t dmr_alias_format[2];                     //per slot
    uint8_t dmr_alias_block_len[2];                  //per slot
    uint8_t dmr_alias_char_size[2];                  //per slot
    dmr_talker_alias_assembly dmr_alias_assembly[2]; /* per slot: what of the alias arrived, for learning */
    char dmr_alias_block_segment[2][4][7]
                                [16]; //2 slots, by 4 blocks, by up to 7 alias bytes that are up to 16-bit chars
    char dmr_embedded_gps[2][600];    //2 slots by 99 char string for string embedded gps
    char dmr_lrrp_gps[2][600];        //2 slots by 99 char string for string lrrp gps
    char dmr_site_parms[200];         //string for site/net info depending on type of DMR system (TIII or Con+)
    /* Per slot: the reception the last checked or accepted DMR data or UDT header (dmr_dheader()) began its assembly
       on, captured with that first fragment (dsd_position_origin_capture()). A position report the assembly carries
       (LIP, binary UDT NMEA) is admitted against it, so a retune or target switch before the last block refuses it. */
    dsd_position_origin dmr_data_origin[2];
    /* Per slot: the identity of the burst that standard header came in (dsd_position_dmr_air()). Its blocks, and a
       proprietary header that extends it, are taken only from a burst of the same sender kind on the same over-the-air
       slot, on the reception dmr_data_origin still matches (issue #800, fail closed): the single-slot decoder carries
       both slots on one lane, and two independently checked bursts are not one transmission by their CRCs alone. */
    uint8_t dmr_data_air[2];
    /* Per slot: whether the target of the data header that began the assembly is a talkgroup, as its check left it
       (issue #800): the DMR standard data header's G/I bit, an NXDN data call header's call type (broadcast or
       group); 0 for a P25 data packet (its LLID names a radio). Position producers (LRRP, LOCN, LIP over UDP, ASCII
       NMEA, NXDN GPS) qualify the header's target by it. dmr_data_target_is_group is not it: a Motorola proprietary
       header (MNIS) clears that one for the decryption-key lookup, and NXDN and P25 headers keep it 0. Cleared with
       the header's source and target. */
    uint8_t dmr_data_checked_group[2];
    /* The reception the current P25 Phase 1 multi-block packet (processMPDU()) began on, captured when its header
       block was read. A position report the packet carries (LRRP, SAP 48 NMEA) is admitted against it, so a retune or
       received-identity change before the last block refuses it. */
    dsd_position_origin p25_mdpu_origin;
    /* Per slot: the evidence a checked full LC (a voice LC header or a late-entry embedded LC whose own check passed,
       not a RAS acceptance; dmr_flco) gave for the source of the slot's ACTIVE call, and for its target while the call
       had that target, bound to the call's transmission and the reception it was heard under. The embedded GPS LC
       borrows it only through dsd_position_attribution_grant() (<dsd-neo/core/position_attribution.h>): never across a
       relock to another colour code, another system or another transmission.
       Cleared by every voice LC header (a new transmission: only that header, checked, names its source) and at every
       carrier change (dsd_state_note_carrier_change(): a carrier boundary, a trunk-scan target switch, a scan step, a
       user's move); one left by another engine run matches no call of the next (dsd_state::call_epoch_floor). */
    dsd_position_attribution dmr_lc_attribution[2];

    //Generic Talker Alias String
    char generic_talker_alias[2][500];
    /* The canonical call epoch each slot's alias above was published for (dsd_event_enrich_alias()), and the reception
       generation it was published under (dsd_state_reception_generation()); epoch 0 when a decoder set the text
       outside call enrichment. A P25 alias is shown and kept only for its own call. */
    uint64_t generic_talker_alias_epoch[2];
    uint64_t generic_talker_alias_rx_gen[2];
    /* The P25 Phase 1 call epoch whose last accepted voice-user link control named its source as a local address
       (p25_p1_voice_user_local 1) or as one needing a Source ID Extension (0): a change between the two on one call is
       another radio with the same number, whose alias is not the earlier one's. */
    uint64_t p25_p1_voice_user_epoch;
    uint8_t p25_p1_voice_user_local;

    dPMRVoiceFS2Frame_t dPMRVoiceFS2Frame;

    /* dPMR frame-content confirmation (src/protocol/dpmr/dpmr_confirm.c). The 12-symbol
     * FS2 word matches about one noise window in 2048, and what stood behind it was not a
     * check: identity publishing accepted a CCH whose two leading Hamming(12,8) blocks
     * merely reported correctable, which 44% of noise superframes do. Until a CCH half
     * passes its CRC-7 the decoder publishes no identity, no call row and no voice.
     * See issue #407.
     * dpmr_confirmed: this transmission has produced a CRC-verified CCH.
     * dpmr_confirm_weak_streak: consecutive frames carrying one passing half only.
     * dpmr_confirm_frame_evidence: strongest dpmr_evidence seen since begin_frame().
     * dpmr_confirm_last_frame_symbol/_valid: symbolcnt where the last FS2 frame began
     * (dpmr_confirm_note_frame_start()), so a weak streak counts only frames that run on. */
    uint8_t dpmr_confirmed;
    uint8_t dpmr_confirm_weak_streak;
    uint8_t dpmr_confirm_frame_evidence;
    uint8_t dpmr_confirm_last_frame_valid;
    uint32_t dpmr_confirm_last_frame_symbol;
    /* The scrambling the current dPMR transmission's last CRC-verified CCH half signalled (issue #655): 0 none yet,
       1 clear, 2 scrambled (Version 3). A half whose CRC-7 failed takes it; a transmission boundary forgets it. */
    uint8_t dpmr_scrambled;

    /* How recently a dPMR CCH CRC-7 passed, for the SPS hunt's profile accounting
     * (src/engine/dispatch/dispatch_dpmr.c). The flag, not the stamp, opens the window,
     * so a zeroed state reads as no evidence rather than evidence at symbol zero. */
    int dpmr_cch_evidence;
    uint32_t dpmr_cch_evidence_symbolcnt;

    //new audio filter structs
    LPFilter RCFilter;
    HPFilter HRCFilter;
    LPFilter RCFilterL;
    LPFilter RCFilterR;
    /* The digital voice high-pass per slot (0 left, 1 right); see dsd_voice_hpf_state. */
    dsd_voice_hpf_state voice_hpf[2];

    int dpmr_color_code;

    short int dmr_stereo;    //need state variable for upsample function
    short int dmr_mono_slot; //mono output slot: -1=unknown, 0=TS1/left, 1=TS2/right
    short int dmr_ms_mode;
    /* The over-the-air slot of the repeater carrier the single-slot DMR decoder (dmrMS(), -fr/-nm conventional)
       follows on its one lane (issue #637), from a CACH TACT that passed its Hamming check: DSD_DMR_MONO_RX_NONE when
       that decoder follows no two-slot carrier (two-slot decoding, direct mode), PENDING until two bursts in a row name
       it. dmr_mono_rx_candidate is the slot the last checked TACT named. */
    uint8_t dmr_mono_rx_slot;
    uint8_t dmr_mono_rx_candidate;
    /* 1/2 when the DMR sync word just matched is direct mode's TS1/TS2 one, which names the burst's slot; 0 for any
       other DMR sync (issue #637). */
    uint8_t dmr_dm_sync_slot;
    /* The voice channel whose tune forgot the control channel's codes, so that the codes it holds now it proved itself
       (dsd_engine_update_vc_tune_state(), issue #637); 0 when the last tune kept them. */
    long receive_codes_fresh_freq;
    unsigned int dmrburstL;
    unsigned int dmrburstR;
    int dropL;
    int dropR;
    int DMRvcL;
    int DMRvcR;
    /* DMR voice crypto continuity per slot (src/protocol/dmr/dmr_vcrypt.c, issue #729). */
    uint8_t dmr_vc_ref_state[2];    /* DMR_VC_REF_NONE, _FIRST (a PI prepared superframe 0) or _VALID */
    uint64_t dmr_vc_ref_clock[2];   /* symbol_clock at the voice sync of the superframe the current IV is for */
    uint32_t dmr_vc_ref_epoch[2];   /* symbol_clock_epoch that clock was read in */
    uint32_t dmr_vc_ref_carrier[2]; /* carrier_seq it was read under */
    uint8_t dmr_vc_untrusted[2];    /* the slot's MI chain is unknown: encrypted voice is muted until re-keyed */
    int dmr_voice_ks_pos[2]; /* 1 + the frame's position 0..17 in its superframe; 0 when the caller is not DMR voice */
    uint64_t dmr_ks_key_tag[2];         /* fingerprint of the ALG ID and key the slot's keystream was generated with */
    uint8_t dmr_ks_tag_burst[2];        /* 1 + the burst (0..5) the fingerprint was last taken in; 0 when one is due */
    unsigned long long dmr_vc6_seed[2]; /* Hytera Enhanced: the superframe's MI while VC6 decodes after its step */
    uint8_t dmr_vc6_seed_valid[2];
    uint8_t dmr_le_frag_mask[2];       /* VC bursts (bit n = VCn) whose late-entry fragments this superframe holds */
    uint8_t dmr_le_candidate_valid[2]; /* a late-entry MI that disagreed with a trusted chain waits for confirmation */
    unsigned long long dmr_le_candidate_mi[2];
    uint8_t dmr_crypto_pi_verified[2];   /* the ALG ID and key id are the current call's from CRC-checked signalling */
    uint8_t dmr_inverted_voice_evidence; /* failed data bursts in a row that read as voice at the other polarity */
    uint8_t dmr_voice_sync_run;    /* adjacent BS bursts in a row whose sync field was the voice sync (dmr_bs.c) */
    uint64_t dmr_voice_sync_clock; /* symbol clock at the end of the run's last sync field */
    uint32_t dmr_voice_sync_epoch; /* symbol clock epoch of that reading */

    //keystream octet and bit arrays
    uint8_t ks_octetL[129 * 18];         //arbitary size, but large enough for the largest packed PDUs
    uint8_t ks_octetR[129 * 18];         //arbitary size, but large enough for the largest packed PDUs
    uint8_t ks_bitstreamL[128 * 18 * 8]; //arbitary size, but large enough for the largest PDUs
    uint8_t ks_bitstreamR[129 * 18 * 8]; //arbitary size, but large enough for the largest PDUs
    int octet_counter;

    //AES Specific Variables
    uint8_t aes_key[32]; //was 64 for some reason
    uint8_t aes_iv[16];
    uint8_t aes_ivR[16];

    //NXDN DES and AES, signal new VCALL_IV and new IV
    uint8_t nxdn_new_iv; //1 when a new IV comes in, else 0
    /* NXDN's working register, its own (P25 Phase 2 and DMR keep slot 2's MI in payload_miN, which NXDN once shared):
       the Scramble LFSR (dPMR's too), loaded from the key and run on, or the DES/AES IV a VCALL_IV carried. No other
       protocol reads or writes it, so a key-derived value here never reaches another protocol's metadata. */
    unsigned long long int nxdn_payload_mi;
    /* 1 while nxdn_payload_mi holds the IV a CRC-verified VCALL_IV carried over the air; 0 once anything else wrote it
       (a key load, a scrambler step: nxdn_reset_payload_seed_if_forced(), LFSRN(); a reset). Only such an IV is ever an
       NXDN call's MI (nxdn_published_mi()): the key-loaded register never is. */
    uint8_t nxdn_iv_on_air;
    uint16_t nxdn_pn95_seed;

    /* NXDN's (and P25 Phase 1's) own "encrypted and no key" flag for slot 0, kept for NXDN's lockout. The audio,
       recording and capture verdict is mbe_slot_muted (issue #655); the vocoder no longer writes these. */
    short int dmr_encL;
    short int dmr_encR;

    //P2 variables
    int p2_hardset;         //flag for checking whether or not P2 wacn and sysid are hard set by user
    int p2_scramble_offset; //offset counter for scrambling application
    int p2_vch_chan_num;    //vch channel number (0 or 1, not the 0-11 TS)
    int ess_b[2][96];       //external storage for ESS_B fragments
    int16_t ess_b_llr[2][96];
    int fourv_counter[2]; //external reference counter for ESS_B fragment collection
    /* The slot's ESS_B is the carrier left's (issue #575): set by p25p2_frame_forget_carrier(), cleared when the slot's
       next 4V burst collects a fragment. A 2V burst decodes no ESS while it is set. */
    uint8_t p25_p2_ess_b_stale[2];
    int p2_is_lcch; //flag to tell us when a frame is lcch and not sacch
    // Authoritative P25 voice crypto classification. Slot 0 is also used by P25 Phase 1.
    dsd_p25_crypto_state p25_crypto_state[2];
    // Retained Phase 1 carrier requires the next transmission's LCW identity before media or lockout.
    int p25_p1_identity_pending;
    // Canonical anonymous epoch opened for the retained-carrier transmission awaiting identity.
    int p25_p1_identity_epoch_started;
    // Definitive Phase 1 HDU crypto arrived after the last authoritative LCW identity.
    int p25_p1_hdu_crypto_fresh;
    // Per slot: the live ALG ID and key id as a conventional call found them when it replaced one whose terminator was
    // missed. The decoder keeps them, as it always has; while they are unchanged the new call publishes them as
    // carried, never as its own (p25_crypto_live_is_inherited()). Cleared by the slot's own resolution, a new
    // classification and p25_crypto_reset_slot().
    uint8_t p25_crypto_inherited[2];
    int p25_crypto_inherited_algid[2];
    int p25_crypto_inherited_keyid[2];
    // One non-clear HDU/LDU2 tuple contradicted explicit-clear Phase 1 service options.
    dsd_p25_p1_crypto_conflict_state p25_p1_crypto_conflict;
    // One non-clear Phase 2 ESS tuple contradicted explicit-clear service context.
    dsd_p25_p2_crypto_conflict_state p25_p2_crypto_conflict[2];
    // Exact carrier/canonical epoch ended by Phase 1 encryption lockout.
    dsd_p25_p1_lockout_epoch_state p25_p1_lockout_epoch;
    // Sticky Phase 2 media rejection, cleared only after the slot receives an accepted assignment/activity.
    int p25_p2_media_rejected[2];
    // ESS identity changes staged until the paired-timeslot audio drain completes.
    dsd_p25_p2_rekey_state p25_p2_rekey[2];
    // P25p2 per-slot audio gating (set on MAC_PTT/ACTIVE, cleared on MAC_END/IDLE/SIGNAL)
    int p25_p2_audio_allowed[2];
    /* P25 Phase 2 voice playout: per-slot queues played per burst pair in both output formats (issue #651).
       Decoder-thread private; ui_snapshot skips it. */
    dsd_p25p2_playout p25p2_playout;
    // P25p2 currently active voice slot (0 or 1), -1 when unknown/idle
    int p25_p2_active_slot;
    // P25p2 recent MAC_ACTIVE/PTT timestamps per slot (guards early bounce)
    time_t p25_p2_last_mac_active[2];
    // Monotonic twins for last MAC_ACTIVE/PTT per slot
    double p25_p2_last_mac_active_m[2];
    // P25p2 recent MAC_END_PTT timestamps per slot (transmission boundaries)
    time_t p25_p2_last_end_ptt[2];
    // P25p1 recent TDU/TDULC transmission-boundary timestamp
    double p25_p1_last_tdu_m;
    /* The P25 Phase 1 call the last terminator (a TDU or TDULC) ended (p25p1_terminator_note_end()), 0 for none, and
       where on the stream the next terminator of the same end would stand: the terminators of one end follow each
       other back to back, each data unit's sync starting where the last one ends (TIA-102.BAAA-A 8.2). The symbol
       clock that terminator would reach its link control at, with the clock's epoch and the carrier it was read on. A
       TDULC's link control speaks for the call its end closed; decoder-thread private. */
    uint64_t p25_p1_terminator_end_epoch;
    uint64_t p25_p1_terminator_end_next_clock;
    uint32_t p25_p1_terminator_end_clock_epoch;
    uint32_t p25_p1_terminator_end_carrier_seq;

    // P25 Phase 2 RS(63,35) metrics (hexbits, t=14)
    unsigned int p25_p2_rs_facch_ok;
    unsigned int p25_p2_rs_facch_err;
    unsigned int p25_p2_rs_facch_corr; // total corrected symbols over accepts
    unsigned int p25_p2_rs_sacch_ok;
    unsigned int p25_p2_rs_sacch_err;
    unsigned int p25_p2_rs_sacch_corr; // total corrected symbols over accepts
    unsigned int p25_p2_rs_ess_ok;
    unsigned int p25_p2_rs_ess_err;
    unsigned int p25_p2_rs_ess_corr;     // total corrected symbols over accepts
    unsigned int p25_p2_soft_erasure_ok; // soft-decision RS successful recoveries
    // P25P1 soft decision counters
    unsigned int p25_p1_soft_hamming_ok; // soft Hamming corrections
    unsigned int p25_p1_soft_golay_ok;   // soft Golay corrections (hard would have failed)
    unsigned int p25_p1_soft_rs_ok;      // soft RS erasure corrections (hard would have failed)
    /* 1 while the LDU1 or TDULC link control being handled passed only a soft-erasure RS retry: its service options
       are not checked evidence that the call is encrypted (dsd_call_crypto_update::enc_observed), and its GPS and
       voice-user identity are not checked provenance (issue #800, spec 2.20). */
    uint8_t p25_p1_lcw_soft;
    p25_p1_harris_gps_part_a p25_p1_harris_part_a; /* L3Harris GPS Part A waiting for its Part B */
    /* The identity a P25 Phase 1 voice-user link control (LCO 0x00, 0x03, Motorola LCGRGR) that passed a hard RS decode
       named for slot 0's ACTIVE Phase 1 call: the evidence a GPS link control of that call borrows its source, target
       and group flag by (dsd_position_attribution_grant()). Cleared by every HDU. */
    dsd_position_attribution p25_p1_lc_attribution;
    unsigned int p25_p2_soft_ess_ok; // soft ESS corrections
    unsigned int p25_p2_soft_ess_max_depth;
    unsigned int p25_p1_soft_combined_ok;
    //iden freq storage for frequency calculations
    // Bitmask per IDEN slot indicating which modulation classes have been seen:
    //   bit 0x01 marks an FDMA/non-TDMA entry
    //   bit 0x02 marks a TDMA entry for channel types 3, 4, or 5
    // Values: 0=unknown, 1=FDMA only, 2=TDMA only, 3=both FDMA and TDMA
    uint8_t p25_chan_tdma_explicit[16];
    uint8_t p25_lcw_retune_disabled_warned; // 1 once "LCW retune disabled" warning emitted
    int p25_chan_iden;

    // Dual-array IDEN storage: separate FDMA and TDMA entries per slot.
    // This prevents multi-mode systems from cycling incompatible parameters
    // in a single slot when both TDMA and FDMA IDEN updates share the same
    // 4-bit identifier ID.
    p25_iden_entry_t p25_iden_fdma[16]; // FDMA/non-TDMA frequency-band entries
    p25_iden_entry_t p25_iden_tdma[16]; // TDMA frequency-band entries

    // User-supplied band plan (--p25-bandplan, [trunking] p25_bandplan_csv, a trunk-scan
    // target's p25_bandplan_csv, or the terminal/Qt import). Rows seed empty IDEN slots at
    // trust 1 through dsd_state_p25_bandplan_seed(); p25_update_system_identity() re-applies
    // them after a WACN/SYS change wipes the tables, and an over-the-air IDEN_UP still
    // overwrites a seeded slot. Under trunk scan each target's snapshot carries its own.
    p25_bandplan_row_t p25_bandplan_rows[DSD_P25_BANDPLAN_MAX_ROWS];
    int p25_bandplan_row_count;

    //p25 frequency storage for trunking and display in ncurses
    int p25_cc_is_tdma;  // control channel modulation: 0=FDMA (C4FM), 1=TDMA (QPSK)
    int p25_sys_is_tdma; // system hint: 1 when P25p2 voice observed (TDMA present)

    /* P25 trunk (RTL): CQPSK DSP chain selection for TDMA voice channels.
     *
     * - p25_vc_cqpsk_pref: learned preference (-1=unknown/auto,
     *   1=prefer OP25-style CQPSK+TED chain). Value 0 is treated as no learned
     *   TDMA preference so automatic retry logic does not force P25p2 through
     *   the FM/QPSK slicer.
     * - p25_vc_cqpsk_override: one-shot retry override applied on next VC tune (-1=none).
     *
     * These are ignored when the user explicitly forces CQPSK via env/config (DSD_NEO_CQPSK).
     */
    int p25_vc_cqpsk_pref;
    int p25_vc_cqpsk_override;

    /* Which demodulator last carried a P25p1 frame whose 63-bit NID BCH decoded, and when:
     * -1 never validated, 0 the C4FM path, 1 the CQPSK path. A validated frame is the only
     * direct evidence of what the signal actually is -- the SNR and sync-hamming heuristics
     * that drive the modulation votes are indirect -- so this outranks them while it is fresh.
     * System knowledge like p25_cc_is_tdma rather than acquisition state, so
     * dsd_frame_sync_reset_mod_state(), retunes and no-carrier resets leave it alone; only
     * initState(), the trunk-scan per-target snapshot and a CQPSK dwell that decodes nothing
     * reset it. Besides a decoded NID, the end of a chain comparison (p25_p1_mod_compare) sets it
     * to the chain that validated more. Freshness is measured in symbols because the hold it feeds only applies on the
     * fixed-rate 4800/4-level profile. Ignored whenever opts->mod_cli_lock is set. */
    int p25_p1_validated_rf_mod;
    uint32_t p25_p1_validated_symbolcnt;
    /* The C4FM P25p1 sync word the unlocked hunt last read from a binary profile (frame_sync_p25p1_word_hint_due()),
     * when one is held (_seen): where (dsd_state::symbolcnt), its sync type and the profile it was read on. A second
     * one of the same polarity within a P25p1 frame of it moves the hunt to 4800/4. */
    uint32_t p25p1_word_hint_symbol;
    int p25p1_word_hint_type;
    int p25p1_word_hint_profile;
    uint8_t p25p1_word_hint_seen;
    /* The 4800/4 symbols a word hint's step skipped of the rotation (the rest of the binary profile's dwell and the
     * dwells between it and 4800/4), which the 4800/4 dwell it opened is owed on top of its own, so the profiles after
     * 4800/4 come round no earlier than without the hint. Dropped with any change of profile, a dwell's expiry or
     * restart, a proof of the profile, and with the sync join histories; 0 on every other dwell. */
    int p25p1_word_hint_dwell_extra;

    /* That the signal on the current SPS profile is P25p1 at all, and when it last proved it:
     * a decoded 63-bit NID BCH, whatever the DUID turned out to be. A separate stamp from the
     * pair above rather than a reuse of it, because that pair answers a different question and
     * is scoped to it -- it is gated on opts->mod_cli_lock and on the frame having arrived
     * through the C4FM or CQPSK path, and a CQPSK dwell that decodes nothing withdraws it --
     * and none of that applies to a profile that has demonstrably carried P25p1. Stamped
     * unconditionally by every decoded NID, never by a failing one.
     *
     * What it buys is a bounded benefit of the doubt for the failures around a reception
     * (dsd_dispatch_handle_p25p1()): a P25p1 sync whose NID fails inside a window of one that
     * decoded is still evidence the profile is right, and the SPS hunt takes it as such (#400).
     * p25_p1_nid_evidence is what opens the window, not the stamp, so a zeroed dsd_state reads
     * as no evidence rather than as evidence at symbol zero. Acquisition state, so noCarrier()
     * clears it: evidence is per transmission, and the next carrier proves itself again. Left
     * alone by retunes, unlike a confirm module's flag, because a retune zeroes the hunt's
     * budget anyway -- the most a stale window can do there is re-zero a counter already at
     * zero, for at most the window's length. */
    int p25_p1_nid_evidence;
    uint32_t p25_p1_nid_evidence_symbolcnt;
    /* The NAC of the P25p1 frame being decoded (issue #804): set by its NID when the BCH accepted it and the NAC is no
     * reserved value (not 0x000 or 0xFFF, as state->nac takes it), so a network status in the same frame can be paired
     * with the NAC it was received under. p25_frame_nac_valid is 0 from every P25p1 sync until its NID decodes, after a
     * NID that failed, was cut by an input interruption or was split by a carrier boundary, and at every carrier
     * boundary; p25_frame_nac is meaningless then. */
    uint16_t p25_frame_nac;
    uint8_t p25_frame_nac_valid;
    /* The NAC the carrier's Phase 1 NIDs established, and a costly NAC change awaiting the next NID. */
    dsd_p25p1_carrier_nac p25_p1_carrier_nac;
    /* Where the P25p1 data unit after the last validated one starts, and the sync of the frame being decoded. */
    dsd_p25p1_sync_anchor p25_p1_sync_anchor;
    dsd_p25p1_sync_candidate p25_p1_sync_candidate;
    /* What a tolerant P25p2 accept changed, held until the window's verdict (dsd_p25p2_sync_candidate). */
    dsd_p25p2_sync_candidate p25_p2_sync_candidate;
    /* Where the P25p2 window after the last one an I-ISCH placed starts, and the sync of the window being decoded. */
    dsd_p25p2_sync_anchor p25_p2_sync_anchor;
    /* The length in dibits of the P25p1 data unit being decoded as its decoder read it, for a TSDU (its block count, by
     * the CRC-checked last block) and a PDU (its header's block count, by the header's CRC); 0 while unknown. The
     * dispatcher clears it before each frame (p25p1_block_unit_dibits()). */
    uint32_t p25_p1_unit_dibits;

    // Candidate evaluation tracking (current freq and start time in monotonic seconds)
    long p25_cc_eval_freq;
    double p25_cc_eval_start_m;
    // Persisted CC cache bookkeeping
    uint8_t p25_cc_cache_loaded; // 1 once we attempted to load per-system cache

    // Trunk SM metrics (shared by P25 and DMR trunking)
    unsigned int p25_sm_tune_count;      // number of VC tunes via SM
    unsigned int p25_sm_release_count;   // number of release requests via SM
    unsigned int p25_sm_cc_return_count; // number of actual returns to CC via SM
    unsigned int p25_sm_queued_count;    ///< number of Queued Response (QUE_RSP) messages received
    unsigned int p25_sm_deny_count;      ///< number of Deny Response (DENY_RSP) messages received
    // One-shot flag to force immediate return-to-CC on physical/policy release;
    // cleared by the SM after handling.
    int p25_sm_force_release;
    int trunk_sm_force_release; // protocol-agnostic force-release latch
    // Timestamp of last p25_sm_release() (0 when none yet)
    time_t p25_sm_last_release_time;
    // Last SM status/reason tag (e.g., "after-tune", "release-deferred-gated") and timestamp
    char p25_sm_last_reason[32];
    time_t p25_sm_last_reason_time;
    // Ring buffer of recent SM tags (for ncurses diagnostics)
    int p25_sm_tag_count;      // number of valid entries (<= 8)
    int p25_sm_tag_head;       // next write index (monotonic)
    char p25_sm_tags[8][32];   // recent tags (text)
    time_t p25_sm_tag_time[8]; // per-tag timestamp
    // Watchdog start time for prolonged post-hang gating on P25p2 VCs
    time_t p25_sm_posthang_start;
    // Monotonic twin for post-hang watchdog (seconds)
    double p25_sm_posthang_start_m;

    // High-level SM mode for UI/telemetry. A retained traffic carrier is ARMED
    // before first voice, FOLLOW while either slot is active, and HANG between
    // transmissions until the inactivity timer expires.
    int p25_sm_mode;

    // Encrypted-target lockout ledger (session-permanent; core/enc_lockout.h).
    // Entries at the current key epoch block encrypted voice-grant tuning;
    // key imports bump the epoch so each target re-verifies with one probe.
    dsd_enc_lockout_entry enc_lockout_entries[DSD_ENC_LOCKOUT_MAX];
    uint64_t enc_lockout_key_epoch;
    // Monotonic confirmation ticket handed to each armed/refreshed entry; the
    // eviction LRU orders on this rather than on one-second wall clock.
    uint64_t enc_lockout_seq;
    // P25 Phase 1 control/data channel FEC/CRC telemetry (for BER display)
    // NOTE: This does not reflect IMBE voice quality. Voice frames have their own
    // Golay/Hamming/RS protection and IMBE ECC; see P1 Voice metrics and
    // debug_{audio,header}_* counters.
    unsigned int p25_p1_fec_ok;  // count of TSBK/MDPU header CRC/FEC successes
    unsigned int p25_p1_fec_err; // count of TSBK/MDPU header CRC/FEC failures
    // P25 Phase 1 voice/header FEC telemetry (Reed-Solomon outcome for HDU/LDU/TDULC)
    unsigned int p25_p1_voice_fec_ok;  // count of successful RS decodes (HDU/LDU/TDULC)
    unsigned int p25_p1_voice_fec_err; // count of failed RS decodes (HDU/LDU/TDULC)
    // P25 Phase 1 DUID/frame-type histogram (since last tune/reset)
    unsigned int p25_p1_duid_hdu;
    unsigned int p25_p1_duid_ldu1;
    unsigned int p25_p1_duid_ldu2;
    unsigned int p25_p1_duid_tdu;
    unsigned int p25_p1_duid_tdulc;
    unsigned int p25_p1_duid_tsbk;
    unsigned int p25_p1_duid_mpdu;

    // P25 Phase 1 voice error moving average (last N IMBE frames)
    uint8_t p25_p1_voice_err_hist[64];
    int p25_p1_voice_err_hist_len;          // ring capacity (<=64), default 50
    int p25_p1_voice_err_hist_count;        // populated frames this call (<=capacity)
    int p25_p1_voice_err_hist_pos;          // ring head
    unsigned int p25_p1_voice_err_hist_sum; // sum of values in window

    // P25 Phase 1 session-lifetime voice telemetry (not reset on retune/no-carrier)
    uint64_t p25_p1_accepted_frames;
    uint64_t p25_p1_clean_frames;
    uint64_t p25_p1_corrected_frames;
    uint64_t p25_p1_concealed_frames;
    uint64_t p25_p1_accepted_corrections;
    uint64_t p25_p1_suppressed_tail_frames;
    uint64_t p25_p1_excluded_tail_corrections;

    /*
     * P25 status symbol classification.
     *
     * Accumulates 2-bit status symbol values during P25 Phase 1 frame
     * processing and produces a classification (infrastructure vs subscriber)
     * for diagnostics and optional auto-PPM gating. Status-derived direction is
     * advisory by default because some systems do not emit reliable direction
     * hints. See <dsd-neo/protocol/p25/p25_status_symbol.h> for the accumulator
     * API.
     */

    /** Accumulated status symbol values for the current data unit (2-bit each). */
    uint8_t p25_ss_buf[P25_STATUS_ACCUM_MAX];
    /** Number of status symbols collected so far in current data unit. */
    uint8_t p25_ss_count;
    /** Current data unit has an active accumulator; preserves NID status handoff from dispatcher. */
    uint8_t p25_ss_frame_active;
    /** Classification of the most recently completed data unit (p25_ss_classification_t). */
    uint8_t p25_ss_classification;
    /** Advisory AFC gate decision: 1 = allow PPM update, 0 = suppress if opt-in gate is enabled. */
    uint8_t p25_afc_gate_allow;
    /** A completed data unit has populated the advisory AFC gate decision. */
    uint8_t p25_afc_gate_valid;
    /** Count of frames classified as AFC-allowable (infrastructure). */
    unsigned int p25_afc_allowed_count;
    /** Count of frames classified as AFC-suppressible (subscriber/unknown). */
    unsigned int p25_afc_suppressed_count;

    /*
     * P25 Protection Parameter state (from TSBK 0x3F, LCW 0x65)
     *
     * Stores the most recently announced encryption algorithm and key ID on
     * the control channel.
     */
    uint8_t p25_prot_valid; ///< 1 once an announcement has been received
    uint8_t p25_prot_algid; ///< Active encryption Algorithm ID (0 = none received)
    uint16_t p25_prot_kid;  ///< Active encryption Key ID (0 = none received)

    /*
     * P25 protected-control-channel state (from MBT 0x3E Protection Parameter
     * Broadcast). This is intentionally separate from voice/call protection
     * state above.
     */
    uint8_t p25_cc_prot_valid; ///< 1 once a protected CC broadcast has been received
    uint8_t p25_cc_prot_algid; ///< Control-channel protection Algorithm ID

    /*
     * P25 Time and Date Announcement state (TSBK 0x35 bridged as MAC-like 0x75)
     *
     * Stores the most recently decoded system UTC time and local time offset.
     */
    uint8_t p25_sys_time_valid;        ///< 1 once a valid date/time has been received
    time_t p25_sys_time;               ///< Decoded UTC time
    uint8_t p25_sys_time_offset_valid; ///< 1 once a local time offset has been received
    int16_t p25_sys_time_offset;       ///< Local time offset in minutes from UTC

    /*
     * P25 System Service Broadcast and current-site status metadata.
     */
    uint8_t p25_sys_services_valid;
    uint32_t p25_sys_services_available;
    uint32_t p25_sys_services_supported;
    uint8_t p25_sys_services_request_priority;
    uint8_t p25_site_lra_valid;
    uint8_t p25_site_lra;
    uint8_t p25_site_network_active_valid;
    uint8_t p25_site_network_active;

    // P25 Phase 2 voice error moving average per slot (errs2 from AMBE decode)
    uint8_t p25_p2_voice_err_hist[2][64];
    int p25_p2_voice_err_hist_len;      // ring capacity (<=64), default 50
    int p25_p2_voice_err_hist_count[2]; // populated frames per slot this call
    int p25_p2_voice_err_hist_pos[2];
    unsigned int p25_p2_voice_err_hist_sum[2];

    // P25 regroup/patch tracking (active super group IDs); see <dsd-neo/core/p25_patch.h>.
    // Tracks up to DSD_P25_PATCH_MAX concurrent SGIDs; updates come from MFID A4/90 regroup PDUs.
    int p25_patch_count;
    uint16_t p25_patch_sgid[DSD_P25_PATCH_MAX];
    uint8_t p25_patch_is_patch[DSD_P25_PATCH_MAX];   // 1=two-way patch, 0=simulselect
    uint8_t p25_patch_active[DSD_P25_PATCH_MAX];     // 1=active, 0=inactive
    time_t p25_patch_last_update[DSD_P25_PATCH_MAX]; // decode time of the last refresh (display only)
    // Freshness on the listening clock: last message naming the SG, last membership message.
    double p25_patch_seen_listen_s[DSD_P25_PATCH_MAX];
    double p25_patch_members_listen_s[DSD_P25_PATCH_MAX];
    // Recency for ordering and eviction, from p25_patch_seq_counter.
    uint32_t p25_patch_seq[DSD_P25_PATCH_MAX];
    uint32_t p25_patch_seq_counter;
    // Listening clock: seconds of continuous control-channel reception, and the previous reading (0 = broken).
    double p25_patch_listen_s;
    double p25_patch_listen_last_m;
    // The system the table belongs to (valid while p25_patch_owner_known).
    uint32_t p25_patch_owner_wacn;
    uint16_t p25_patch_owner_sysid;
    uint8_t p25_patch_owner_known;
    // Membership (best-effort): WGIDs and WUIDs per SG
    uint8_t p25_patch_wgid_count[DSD_P25_PATCH_MAX];
    uint16_t p25_patch_wgid[DSD_P25_PATCH_MAX][DSD_P25_PATCH_GROUP_MAX];
    uint8_t p25_patch_wuid_count[DSD_P25_PATCH_MAX];
    uint32_t p25_patch_wuid[DSD_P25_PATCH_MAX][DSD_P25_PATCH_RADIO_MAX];
    // Optional crypt/state context from GRG commands
    uint16_t p25_patch_key[DSD_P25_PATCH_MAX]; // Key ID
    uint8_t p25_patch_alg[DSD_P25_PATCH_MAX];  // ALG (vendor-specific)
    uint8_t p25_patch_ssn[DSD_P25_PATCH_MAX];  // SSN
    // Whether p25_patch_key[i] has been explicitly set by a GRG command
    uint8_t p25_patch_key_valid[DSD_P25_PATCH_MAX];

    // P25 affiliated RIDs tracking (simple fixed-size table)
    // Tracks up to 256 recent unit registrations (RIDs) with last-seen time for aging.
    // Entries are added on Unit Registration Accept and removed on Deregistration Ack
    // or when the last-seen exceeds an aging threshold.
    int p25_aff_count;                     // number of active entries
    uint32_t p25_aff_rid[P25_AFF_MAX];     // RID values (the local address a registration assigned)
    time_t p25_aff_last_seen[P25_AFF_MAX]; // last seen timestamp per RID
    // Per entry: the home SUID the address was assigned to and the serving system (p25_aff_register_assigned()).
    p25_aff_assoc_t p25_aff_assoc[P25_AFF_MAX];

    // P25 Group Affiliation tracking: RID↔TG observations with aging
    int p25_ga_count;
    uint32_t p25_ga_rid[512];
    uint16_t p25_ga_tg[512];
    time_t p25_ga_last_seen[512];

    // P25 neighbors seen via Adjacent Status (best-effort)
    // Track a small set of recently announced neighbor/control candidates for UI purposes.
    // Uses p25_nb_entry_t struct with per-neighbor site metadata (CFVA, SysID, RFSS, Site).
    int p25_nb_count;                          // number of active neighbor entries
    p25_nb_entry_t p25_nb_entries[P25_NB_MAX]; // neighbor entries with metadata

    // P25 current-site secondary control channels seen via SCCB.
    int p25_secondary_cc_count;
    p25_secondary_cc_entry_t p25_secondary_cc_entries[P25_SECONDARY_CC_MAX];

    // P25 channel announcements that arrived before their IDEN table.
    int p25_pending_announcement_count;
    p25_pending_announcement_t p25_pending_announcements[P25_PENDING_ANNOUNCEMENT_MAX];

    // P25 source unit WACN from LCW 0x49 (Source ID Extension)
    uint32_t p25_src_nid; // 20-bit WACN from SUID extension

    // P25 Phase 2 standard MAC multi-fragment assembly, one in-flight message per TDMA slot.
    p25_mac_fragment_state_t p25_mac_frag[2];
    // P25 OTA alias receive sequencing, kept with decoder state to avoid cross-instance mixing.
    p25_apx_alias_rx_state_t p25_apx_alias_rx[2];
    p25_l3h_alias_phase1_state_t p25_l3h_alias_phase1[2];

    //experimental symbol file capture read throttle
    int use_throttle;                        //only use throttle if set to 1
    uint64_t symbol_replay_next_deadline_ns; //0 when uninitialized

    /* Input switches on the decoder thread (issue #634).
       input_interrupted: a frame-sync hunt read gave way to a queued command once its input had been silent for a
       stream pause; getFrameSync() returns at once and the engine loop applies the command. A Signal search also sets
       it inside a frame, when it leaves the frame or a live read gives up on a stalled input: getSymbol() then stands
       erasures in for every symbol until the engine loop consumes it, and the frame decoders drop the frame
       (dsd_state_frame_read_lost()). So does a gap in the radio stream (DSD_INTERRUPT_STREAM_GAP), until the engine
       loop has consumed it and reset the decoding the gap cut.
       input_boundary: the stream the decoder read was replaced (a switch, a rollback that restarted it, a loss, a
       fallback); the engine ends the reception (noCarrier() and an explicit end of every call) before it decodes the
       new stream.
       input_fallback_pending: the file or TCP input ended; the frame being decoded reads zeros until it ends, and the
       engine loop then switches to the Pulse input, unless a command replaced the ended input meanwhile. */
    int input_interrupted;
    /* Why input_interrupted stands (dsd_input_interrupt_reason); the engine loop clears both. */
    int input_interrupt_reason;
    /* The radio stream's discontinuity count the decoder has taken up to (D5): the symbol reader raises a stream-gap
       interruption when the samples a read returned carry a newer one, and the EDACS analog call loop and the M17
       encoder, which read the stream themselves, take it up there. The engine sets it to the stream's count at each
       stream start (dsd_engine_note_stream_source()). */
    uint64_t rtl_stream_gap_seq;
    /* A sample the one-sample RTL reader read past a stream gap, handed out once the engine has consumed the gap:
       whether one is held, the sample, its squelch flag, and the stream generation it was read under (a sample held
       across a generation change is dropped). */
    uint8_t rtl_gap_held;
    uint8_t rtl_gap_held_flag;
    float rtl_gap_held_sample;
    uint32_t rtl_gap_held_generation;
    /* The EDACS analog call loop's reads while the RTL device has no stream (issue #518 D4: DSD_RTL_READ_NO_STREAM),
       or while a TCP or UDP sender is quiet past a stream pause (issue #667 D12), which it plays as silence at the
       input's rate for the time that passes: whether such a run is on (the input delivered nothing since it began),
       when it began (realtime ms), the silent samples that time has paid for so far and those still owed, and whether
       the triplet being collected took any from a missing RTL stream (it then has no RF power). Decoder-thread
       owned. */
    uint8_t edacs_no_stream_active;
    uint8_t edacs_no_stream_seen;
    uint64_t edacs_no_stream_since_ms;
    uint64_t edacs_no_stream_paid;
    uint64_t edacs_no_stream_owed;
    int input_boundary;
    /* The carrier boundary's count (issue #575): dsd_engine_carrier_boundary() bumps it whenever the receiver leaves a
       carrier. A decoder that buffers several bursts or frames before it decodes them notes it when collection starts,
       and drops what it buffered, as on a sync loss, when it moved meanwhile: those bursts belong to the carrier left.
       It drops them as well when an input interruption cut them (dsd_state_frame_read_lost()). */
    uint32_t carrier_seq;
    /* The symbol_clock of the last symbol not wholly the new carrier's when the receiver last left a carrier
       (dsd_state_note_carrier_change(): a carrier boundary or a trunk-scan target switch; one more than the clock when
       the change split the symbol being read, set back by the frame-sync hunt when that read left with none), valid
       once carrier_change_seen is set. What the frame sync's history and the decoders' rolling buffers hold from before
       it is the carrier left's (dsd_state_carrier_settling()). */
    uint64_t carrier_change_symbol_clock;
    uint8_t carrier_change_seen;
    /* The frame processFrame() is dispatching (issue #661): its synctype, which a decoder borrowing another protocol's
       vocoder (YSF, scrambled dPMR) leaves alone while it changes synctype, and carrier_seq when dispatch began.
       frame_dispatch_active is 0 outside a dispatch. MBE capture attributes a frame to this protocol, and refuses one
       read across a carrier boundary. */
    int frame_dispatch_active;
    int frame_dispatch_synctype;
    uint32_t frame_dispatch_carrier_seq;
    /* The radio source the stream last started on, as dsd_engine_note_stream_source() keys it; 0 before any start. */
    uint64_t carrier_source_key;
    /* The carrier on air is two-slot TDMA: since the last acquisition reset, a frame of DMR (base station, mobile or
       direct mode), P25 Phase 2 or X2-TDMA decoded with its check passed (a DMR colour-code lock or CRC-checked burst,
       a P25 Phase 2 Reed-Solomon block, an X2-TDMA voice superframe whose further sync words agree or that follows another), never a bare
       sync. Decoder-thread owned; frontends read it from the snapshot to keep the second slot's place on screen. A
       sync loss keeps it; dsd_frame_sync_reset_acquisition(), the carrier boundary and a trunk-scan target switch
       (dsd_engine_forget_carrier_decoding()), a decoded P25 Phase 1 NID, a decode-mode change and the start and end
       of a run clear it. */
    uint8_t tdma_carrier;
    /* The last whole X2-TDMA voice superframe (processX2TDMAvoice()): the carrier count it was read on and the symbol
       count where it ended. A superframe whose sync follows it with no hunt gap chains to it, which is how a direct
       mode carrier, whose other timeslot carries no sync word, proves it is X2-TDMA. x2tdma_superframe_valid is 0
       when there is none, and after an acquisition reset. */
    uint8_t x2tdma_superframe_valid;
    uint32_t x2tdma_superframe_carrier_seq;
    uint32_t x2tdma_superframe_end_symbol;
    /* The timeslots (bit 0 the first, bit 1 the second) whose encryption verdict that superframe learned with no call
       open (direct mode's uncorroborated first superframe): the superframe chained to it keeps that verdict for its
       first burst on the same timeslot when it opens the call there (x2tdma_note_slot_crypto()). */
    uint8_t x2tdma_superframe_pre_call_crypto;
    /* Per timeslot: the encryption the timeslot's X2-TDMA voice frames are judged by (DSD_X2TDMA_CRYPTO_*), set by
       processX2TDMAvoice() before each burst's frames, and the call's transmission (dsd_call_snapshot_transmission())
       it was read in. A superframe signals its encryption in its second burst, after the first burst's three frames:
       those take the previous superframe's value of the same transmission, and are UNKNOWN in its first superframe.
       The vocoder mutes, records, captures and learns from the frames by it (mbe_frame_judge()). */
    uint8_t x2tdma_slot_crypto[2];
    uint64_t x2tdma_slot_crypto_transmission[2];
    /* An X2-TDMA voice superframe of the current transmission proved itself (processX2TDMAvoice()), on the carrier
       count x2tdma_corroborated_carrier_seq: its voice plays from every superframe after it, a hunt gap between them
       included. A sync loss (noCarrier()), an acquisition reset and the carrier boundary forget it. */
    uint8_t x2tdma_corroborated;
    uint32_t x2tdma_corroborated_carrier_seq;
    int input_fallback_pending;

    //dmr trunking stuff
    int dmr_rest_channel;
    int dmr_mfid;     //just when 'fid' is used as a manufacturer ID and not a feature set id
    uint32_t tg_hold; //single TG to hold on when enabled

    //edacs
    int ea_mode;

    /* ProVoice frame-content confirmation (src/protocol/provoice/provoice_confirm.c). Nothing
     * in a ProVoice frame can fail a check -- no CRC, no BCH, no parity -- so the evidence is
     * that the stream keeps arriving: each frame sits behind its own exact 32-symbol sync
     * word, and two in a row confirm the transmission (issues #391, #421).
     *
     * provoice_confirmed: this transmission has produced verified content.
     * provoice_confirm_weak_streak: consecutive frames decoded behind their own sync word.
     * provoice_confirm_frame_evidence: strongest provoice_evidence seen since begin_frame(). */
    uint8_t provoice_confirmed;
    uint8_t provoice_confirm_weak_streak;
    uint8_t provoice_confirm_frame_evidence;
    /* Where the last frame began (provoice_confirm_note_frame_start()): a frame runs on only from one read a frame
       before it. */
    uint8_t provoice_confirm_last_frame_valid;
    uint32_t provoice_confirm_last_frame_symbol;

    unsigned short esk_mask;
    uint32_t edacs_sys_id;
    uint32_t edacs_area_code;
    int edacs_lcn_count; //running tally of lcn's observed on edacs system
    int edacs_cc_lcn;    //current lcn for the edacs control channel
    int edacs_tuned_lcn; //the vc we are currently tuned to...above variable is for updating all in the matrix
    int edacs_a_bits;    //  Agency Significant Bits
    int edacs_f_bits;    //   Fleet Significant Bits
    int edacs_s_bits;    //Subfleet Significant Bits
    int edacs_a_shift;   //Calculated Shift for A Bits
    int edacs_f_shift;   //Calculated Shift for F Bits
    int edacs_a_mask;    //Calculated Mask for A Bits
    int edacs_f_mask;    //Calculated Mask for F Bits
    int edacs_s_mask;    //Calculated Mask for S Bits
    /* The trunk tune request of the grant tuned to edacs_tuned_lcn while it is still in flight (0 once landed, or for a
       tune that completed when asked): edacs_trunk_tick() rolls the grant back when it fails. */
    uint64_t edacs_tune_request;
    /* The return to the control channel EDACS asked for (eot_cc(), a failed grant's rollback) while it is still in
       flight: edacs_trunk_tick() asks for it again when it fails, so no failure is left withholding every frame. */
    uint64_t edacs_cc_return_request;
    /* dsd_state::carrier_seq when each was asked for: a carrier boundary since (a typed tune, an input or device
       switch) hands the receiver to another owner, so EDACS no longer recovers from that tune's failure. */
    uint32_t edacs_tune_carrier_seq;
    uint32_t edacs_cc_return_carrier_seq;

    //trunking lcn freq list
    int lcn_freq_count;
    int lcn_freq_roll; //number we have 'rolled' to in search of the CC
    /* The -Y scan session (issue #671): it moves whenever a -Y scan ends (dsd_engine_channel_scan_leave(): a stop, a
       list replacement, a trunk-scan start), pauses or resumes, so a row tune that timed out under one scan never
       commits its row in the next, nor after a pause. */
    uint32_t lcn_scan_session;
    /* Where the list is, apart from where it goes next (issue #666). lcn_freq_roll is the cursor: the next step starts
       there, and a step may move it before its row lands (a skip, a wrap, a failed or pending tune) or past a 0 Hz
       placeholder it parks on, so roll - 1 is not always the row heard. lcn_on_air_row is the last non-zero row an
       accepted step selected (-1 none), with the row's frequency at the time: a row since removed or changed reads as
       none (dsd_state_lcn_heard_row()). -2 is none after a hard-failed step found no row recorded: unlike -1, the row
       heard does not fall back to roll - 1, a row never tuned. lcn_back_retry_row is the row a hard-failed backward
       step tried (-1 none). */
    int lcn_on_air_row;
    long int lcn_on_air_freq;
    long int lcn_back_retry_freq;
    int lcn_back_retry_row;
    int is_con_plus; //con_plus flag for knowing its safe to skip payload channel after x seconds of no voice sync

    //new nxdn stuff
    int nxdn_part_of_frame;
    int nxdn_ran;
    int nxdn_sf;
    uint8_t
        nxdn_sacch_non_superframe; //flag to indicate whether or not a sacch is a part of a superframe, or an individual piece
    /* The channel the NXDN frame being decoded is on, from its LICH (nxdn_frame(), one of nxdn_frame_channel in
     * <dsd-neo/protocol/nxdn/nxdn.h>), set only while that frame's channels decode: element parsers whose layout or
     * meaning depends on the channel read it, never anything retained from an earlier frame. */
    uint8_t nxdn_frame_channel;
    /* 1 while the channels being decoded are another channel's control traffic heard on the followed traffic channel
     * (a CAC, or a composite control channel's frame, while the receiver follows a call elsewhere than this site's
     * control channel, dsd_nxdn_control_heard_is_foreign()): they are decoded for the log only, and their checks stamp
     * dsd_nxdn_site_record::foreign_control_m instead of confirming the transmission. */
    uint8_t nxdn_frame_foreign;
    uint8_t nxdn_sacch_frame_segment[4][18]; //part of frame by 18 bits
    uint8_t nxdn_sacch_frame_segcrc[4];
    nxdn_alias_assembly nxdn_alias_prop; /* the Kenwood alias being assembled (nxdn_alias_decode_prop()) */
    uint8_t nxdn_alias_arib_total_segments;
    uint8_t nxdn_alias_arib_seen_mask;
    uint8_t nxdn_alias_arib_segments[4][6];
    uint8_t nxdn_dcr_sf_message_type; // DCR SACCH2 SF message type; 0xFF means unknown.

    //site/srv/cch info

    char nxdn_location_category[14];
    uint32_t nxdn_location_sys_code;
    uint16_t nxdn_location_site_code;
    /* An IDAS (Type-D) site's identity, kept apart from the Type-C location ID above, whose categories it does not
     * share (NXDN TS 1-E §6.6.2, §6.6.5): the 19-bit System ID of a Type-D SRV_INFO, and the 8-bit Site Code (1-250)
     * of that message or of an SCCH site ID message. 0 is "not received" for both (System ID 0 is the null ID, Site
     * Code 0 is reserved). Written only from confirmed content. */
    uint32_t nxdn_idas_system_id;
    uint8_t nxdn_idas_site_code;

    //channel access information
    uint8_t nxdn_rcn;
    uint8_t nxdn_base_freq;
    uint8_t nxdn_step;
    uint8_t nxdn_bw;
    dsd_nxdn_ca_source nxdn_ca;
    dsd_nxdn_dfa_learned nxdn_dfa_learned;
    dsd_nxdn_site_record nxdn_site;

    // NXDN trunking: last observed call grant mapping (for UI/logging)
    uint16_t nxdn_grant_chan;
    long int nxdn_grant_freq;
    /* NXDN trunking: the voice channel route the receiver last followed a grant or busy repeater message to
     * (nxdn_element.c). It names only where the receiver went, never which call is on it, and holds only while the
     * receiver is still tuned there (trunk_is_tuned with trunk_vc_freq[0] == freq_hz). Travels with a trunk scan
     * target. */
    dsd_nxdn_follow_route nxdn_follow;
    /* NXDN trunking: the call the receiver holds, as the talkgroup policy's preemption judges it: the followed grant's,
     * then reconciled from verified VCALLs and SCCH identities that belong to the receiver's repeater. Travels with a
     * trunk scan target. */
    dsd_nxdn_call_identity nxdn_call;

    //multi-key array
    int keyloader;            //let us know the keyloader is active
    char key_profile_ref[64]; /**< Opaque material-source identity, safe for frontend metadata. */

    //dmr late entry mi

    //dmr manufacturer branding and sub_branding (i.e., Motorola and Con+)
    char dmr_branding[20];
    char dmr_branding_sub[80];

    //Bitmap Filtering Options
    int audio_smoothing;

    //YSF Fusion Call Strings and Info
    uint8_t ysf_dt; //data type -- VD1, VD2, Full Rate, etc.
    uint8_t ysf_fi; //frame information -- HC, CC, TC
    uint8_t ysf_cm; //group or private call
    /* Sticky for the transmission: set once a FICH passes its Golay+CRC-16, cleared with the
     * rest of the YSF strings on noCarrier(). A later FICH failure still lays the payload out
     * from the previous frame's dt/fi and still synthesizes voice from it, so once one FICH
     * has confirmed the transmission those frames are decoding, not validating nothing (#391). */
    uint8_t ysf_fich_confirmed;
    char ysf_rm1[6];
    char ysf_rm2[6];
    char ysf_rm3[6];
    char ysf_rm4[6];
    char ysf_txt[21][21]; //text storage blocks

    //DSTAR Call Strings and Info
    char dstar_txt[60];
    char dstar_gps[60];

    /* D-STAR frame-content confirmation (src/protocol/dstar/dstar_confirm.c). A voice sync
     * commits 1992 symbols, and nothing inside them is checkable on its own: the AMBE error
     * counts are soft corrections, not a verdict. A CRC-16/X.25 -- the RF header, or the
     * header rebroadcast in slow data -- proves the transmission; a superframe that carries
     * only filler has to repeat instead (issues #391, #421).
     *
     * dstar_confirmed: this transmission has produced verified content.
     * dstar_confirm_weak_streak: consecutive superframes carrying no check of their own.
     * dstar_confirm_frame_evidence: strongest dstar_evidence seen since begin_frame(). */
    uint8_t dstar_confirmed;
    uint8_t dstar_confirm_weak_streak;
    uint8_t dstar_confirm_frame_evidence;
    /* The D-STAR transmission (issue #800). dstar_tx_seq advances at every transmission boundary: an RF header, decoded
     * or not, and the carrier's end (dstar_confirm_reset(), noCarrier()); the slow-data assemblies, in their protocol
     * extension (src/protocol/dstar/dstar_sd_state.h), are bound to it and reset when it moves. dstar_tx_call_epoch is the slot 0 call a header of this
     * transmission whose CRC passed named with a MY callsign; 0 until one has, after an RF header (the call left ACTIVE,
     * its terminator missed, may be another radio's), and after a checked header whose MY field is blank. Slow data
     * reaches a call (its text, a D-PRS source, a D-PRS position) only when that call is the one named here.
     * dstar_tx_call_origin is the reception that header was heard on: once the reception generation moves (a retune,
     * another system's frame noted between the header and the slow data), the header names no call any more
     * (dstar_slow_data.c dstar_tx_named_call()), whatever stays ACTIVE. */
    uint32_t dstar_tx_seq;
    uint64_t dstar_tx_call_epoch;
    dsd_position_origin dstar_tx_call_origin;

    //M17 Storage
    uint8_t m17_lsf[360];
    m17_lich_assembly m17_lich; /* what the LICH chunks in m17_lsf were heard under */
    uint8_t m17_pkt[850];

    // Soft symbol buffer for Viterbi decoding (M17, NXDN, etc.)
    // Stores raw float symbol values alongside dibits for soft-decision FEC
    float soft_symbol_buf[512];  // Ring buffer for soft symbols
    int soft_symbol_head;        // Write index (wraps at 512)
    int soft_symbol_frame_start; // Index where current frame started
    uint8_t m17_pbc_ct;          //pbc packet counter
    uint8_t m17_str_dt;          //stream contents
    uint8_t m17_bert_locked;
    uint16_t m17_bert_lfsr;
    uint16_t m17_bert_lock_count;
    uint16_t m17_bert_window_bits;
    uint16_t m17_bert_window_errors;
    uint32_t m17_bert_bits;
    uint32_t m17_bert_errors;
    uint32_t m17_bert_resyncs;

    /* M17 preamble candidate (src/dsp/dsd_frame_sync.c). A preamble is an alternating symbol
     * run and nothing more, so matching one only latches a candidate here; the LSF or BERT sync
     * word that must follow it within DSD_FRAME_SYNC_M17_CANDIDATE_TTL evaluations is what the
     * decoder acts on (issue #399).
     *
     * m17_pre_run: consecutive windows that matched a preamble marker at either polarity.
     * m17_pre_candidate: 0 none, 1 normal polarity, 2 inverted.
     * m17_pre_candidate_ttl: M17 evaluations left before the candidate lapses. */
    uint8_t m17_pre_run;
    uint8_t m17_pre_candidate;
    uint8_t m17_pre_candidate_ttl;
    /* 1 when the link setup frame just read passed its CRC and declared stream mode (TYPE bit 0, the packet/stream
     * indicator, is 1), so the frames behind it are stream frames and never packet frames; 0 before any LSF, after one
     * that failed its CRC and after a packet-mode one. Frame sync reads it for the sync right after an LSF (issue
     * #834). */
    uint8_t m17_lsf_stream_mode;
    /* M17 joined mid-transmission (src/dsp/dsd_frame_sync.c): the windows that lately held a stream, LSF, packet or BERT
     * sync word exactly, with the word (kind 1-4) and where (dsd_state::symbolcnt). The same word exactly one and two
     * 192-symbol frames before a window joins the transmission there, for that frame alone: the history is cleared
     * when a join is taken, and with the NXDN96 sync above. */
    dsd_sync_hit_history m17_join_hits;

    /* M17 frame-content confirmation (src/protocol/m17/m17_confirm.c). The preamble that opens
     * the sync chain is only an alternating symbol run, so the frame body has to prove itself
     * before the decoder acts on it (issue #399).
     *
     * m17_confirmed: this transmission has produced CRC-verified content.
     * m17_confirm_weak_streak: consecutive frames carrying only a clean LICH.
     * m17_confirm_frame_evidence: strongest m17_evidence seen since begin_frame(). */
    uint8_t m17_confirmed;
    uint8_t m17_confirm_weak_streak;
    uint8_t m17_confirm_frame_evidence;

    uint8_t m17_can; //can value that was decoded from signal
    int m17_can_en;  //can value supplied to the encoding side
    int m17_rate;    //sampling rate for audio input
    int m17_vox;     //vox enabled via PWR value

    uint8_t m17_meta[16]; //packed meta
    uint8_t m17_text_meta_control_or;
    uint8_t m17_text_meta_expected_bitmap;
    uint8_t m17_text_meta_received_bitmap;
    uint8_t m17_text_meta[52];
    uint8_t m17_enc;               //enc type
    uint8_t m17_enc_st;            //scrambler or data subtye
    uint8_t m17_payload_decrypted; //current encrypted payload was successfully decrypted
    uint8_t m17_signature_advertised;
    uint8_t m17_signature_digest[16];
    uint8_t m17_signature[64];
    uint8_t m17_signature_received_mask;
    uint8_t m17_signature_complete;
    uint8_t m17_signature_bad_sequence;
    uint8_t m17_signature_public_key[64];
    uint8_t m17_signature_public_key_loaded;
    uint8_t m17_signature_verification_status;
    int m17encoder_tx;  // If TX (encode + decode) M17 Stream is enabled
    int m17encoder_eot; //signal if we need to send the EOT frame

    //misc str storage
    char str50a[50];
    char str50b[50];
    char str50c[50];
    char m17dat[50];  //user supplied m17 data input string
    char m17sms[824]; //user supplied sms text string

    // tyt_ap value 1 means active
    int tyt_ap;
    int tyt_bp;
    int tyt_ep;
    int baofeng_ap;
    int csi_ee;
    uint8_t csi_ee_key[9];
    // retrevis rc2
    int retevis_ap;

    //kenwood scrambler on DMR with forced application
    int ken_sc;

    //anytone bp
    int any_bp;

    //generic ks
    int straight_ks;
    int straight_mod;
    int straight_frame_mode; // 0=continuous bitstream, 1=frame-aligned (offset/step)
    int straight_frame_off;  //frame-aligned start offset (bits)
    int straight_frame_step; //frame-aligned per-frame step (bits)

    uint8_t static_ks_bits[2][882];
    int static_ks_counter[2];

    // Vertex ALG 0x07 interim key->keystream mapping table.
    unsigned long long vertex_ks_key[DSD_VERTEX_KS_MAP_MAX];
    uint8_t vertex_ks_bits[DSD_VERTEX_KS_MAP_MAX][882];
    int vertex_ks_mod[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_mode[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_off[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_frame_step[DSD_VERTEX_KS_MAP_MAX];
    int vertex_ks_count;
    int vertex_ks_active_idx[2];
    int vertex_ks_counter[2];
    uint8_t vertex_ks_warned[2];

    // DMR: consecutive EMB decode failures per slot (hysteresis for robustness)
    uint8_t dmr_emb_err[2];

    /* ─────────────────────────────────────────────────────────────────────────
     * Symbol History and DMR Resample-on-Sync Support
     *
     * Implements SDRTrunk-style threshold calibration and CACH resampling to
     * improve first-frame decode accuracy. See dmr_sync.h for details.
     * ───────────────────────────────────────────────────────────────────────── */

    /** Symbol history circular buffer for retrospective resampling.
     *  Stores symbol-rate floats (one per dibit decision), not raw audio samples. */
    float* symbol_history;
    int symbol_history_size;  /**< Circular-buffer size in symbols */
    int symbol_history_head;  /**< Write index into circular buffer */
    int symbol_history_count; /**< Symbols written (for underflow check) */

    /** Post-filter sample trace backing the symbol-timing diagnostic;
     *  written only while DSD_NEO_DEBUG_SYMBOL_TIMING is on.
     *  See dsp/symbol_timing_debug.h. */
    dsd_symbol_timing_trace timing_trace;

    /** The matched filter the symbol grid reads through and the raw history a
     *  switch is paid from; see dsd_matched_filter_seam. */
    dsd_matched_filter_seam matched_filter;

    // Advisory-only input level health for ncurses/status snapshots.
    dsd_input_level_snapshot input_level;
    // Decode time of the last input-level warning, which its cooldown runs against (dsd_input_level_publish()).
    time_t input_level_last_toast_time;
    dsd_input_level_status input_level_last_toast_status;
    dsd_input_level_source input_level_last_toast_source;

    /* Which --trunk-scan target the receiver is parked on, published for the frontends.
     * Zeroed while trunk scan is off or before the first target is selected. */
    char trunk_scan_active_id[DSD_CHANNEL_LABEL_SIZE];
    /* The parked target's `label` column, "" when it has none (issue #782): what names the channel being heard, so a
     * target list whose ids are internal (the Qt/Android scan lists use entry UIDs) still names it for a person. */
    char trunk_scan_active_label[DSD_CHANNEL_LABEL_SIZE];
    uint16_t trunk_scan_active_ordinal; /**< 1-based position in the target list; 0 = none */
    uint16_t trunk_scan_target_count;   /**< Targets in the list, for an "n of m" readout */

    /* On-the-fly scan controls (issue #380), published beside the target id so they ride
     * the same snapshot range. lcn_scan_hold is authoritative for -Y: app_control writes
     * it and the scanner rotation reads it. lcn_avoid_count mirrors the avoid store for the
     * status line and is maintained by dsd_state_trunk_lcn_avoid_set()/_clear(). The
     * trunk_scan_* trio is written by the trunk-scan coordinator, which owns the truth. */
    uint8_t lcn_scan_hold; /**< 1 = -Y rotation held on the row on air */
    /* The -Y hold is an entry hold (issue #644): a frequency typed by hand picked the row on air, and `y` continues the
       scan rather than stopping it. Set only with lcn_scan_hold, on the confirmed landing of the row picked; never
       saved. */
    uint8_t lcn_scan_entry_hold;
    /* A -Y scan the operator paused (issue #671): its list, cursor, avoids and session edits are kept while
     * scanner_mode is 0, so the receiver stays where the operator put it until a resume
     * (dsd_engine_channel_scan_pause(), _resume()). lcn_scan_resume_pending: a resume's row tune timed out; until it
     * lands the scan stays paused and no row is named. operator_tuned: the operator moved the receiver off its session
     * (a scan pause, a tuner release of trunking, any accepted manual tune but a P25 control-channel selection); a
     * resume and a new session clear it, a stop does not. */
    uint8_t lcn_scan_paused;
    uint8_t lcn_scan_resume_pending;
    uint8_t operator_tuned;
    uint16_t lcn_avoid_count; /**< Avoided -Y rows within lcn_freq_count */
    uint8_t trunk_scan_hold;  /**< 1 = --trunk-scan dwell paused on the active target */
    /* The --trunk-scan hold is an entry hold (issue #644), as lcn_scan_entry_hold is for -Y: set with trunk_scan_hold
       on the confirmed park of the target a typed frequency picked; never saved. */
    uint8_t trunk_scan_entry_hold;
    /* A --trunk-scan the operator paused (issue #671): the coordinator keeps its targets, snapshots, avoids, session
     * edits and hold, but no target is on air and nothing it owns tunes or decodes, until a resume re-parks the target
     * it left (dsd_engine_trunk_scan_pause_locked(), _resume_locked()). dsd_opts::trunk_scan_enabled stays 1 (the
     * configured setting); dsd_trunk_scan_owns_tuner() is the running predicate. */
    uint8_t trunk_scan_paused;
    uint8_t trunk_scan_active_avoided; /**< 1 = the parked target is itself avoided (fallback) */
    uint16_t trunk_scan_avoided_count; /**< Avoided --trunk-scan targets */
    /* The tuner gain a --trunk-scan target without its own rtl_gain runs, which the gain controls edit and a save
     * writes, and whether the parked target's own rtl_gain overrides it; written by the coordinator beside the trio
     * above. Valid while trunk_scan_target_count > 0. */
    int16_t trunk_scan_configured_gain;     /**< dB in driver units; 0 = AGC */
    uint8_t trunk_scan_gain_override;       /**< 1 = the parked target runs its own rtl_gain */
    uint8_t trunk_scan_configured_autogain; /**< 1 = the configured tuner autogain is on */
    /* The trunking setting (dsd_opts::trunk_enable) the session runs outside the scan, which each target's type
     * overrides while it is parked and shutdown puts back; a save writes it. Written by the coordinator beside the
     * configured gain. Valid while trunk_scan_target_count > 0. */
    uint8_t trunk_scan_configured_trunk_enable; /**< 1 = trunking configured on */
    /* The --trunk-scan target lists (issue #697), written by the coordinator at its start, at each list switched on
     * or off and at each hop, and cleared when it detaches. trunk_scan_lists[i] is list i + 1 (its name, whether it
     * is on, and its target count); trunk_scan_lists_seq moves at every start and change of them and never repeats a
     * value in the process. A target whose id several lists' files hold is one target in each of them.
     * trunk_scan_active_list: the list (1-based) that names the target on air, the lowest-numbered list holding it
     * that is on, else the lowest-numbered list holding it; 0 when none is on air (paused included).
     * trunk_scan_active_lists: every list holding the target on air (bit N-1: list N), on or off; 0 when none is on
     * air (paused included). trunk_scan_active_list_off: every list holding that target is off, so the receiver stays
     * there only until another target can take it, as it stays on an avoided one (trunk_scan_active_avoided; either
     * can hold, or both). trunk_scan_rotation_count: the distinct targets of the lists that are on, avoided ones
     * included; trunk_scan_rotation_ordinal: the target on air's 1-based position among them, 0 while its lists are
     * off or none is on air. The identity ordinal (trunk_scan_active_ordinal, the position among every loaded target)
     * does not move when a list does. A list's targets count the ones it shares, and
     * trunk_scan_membership_counts[m - 1] is how many distinct targets are in exactly the lists of membership mask m
     * (bit N-1: list N): the distinct total of any set of lists sums the masks that meet it. Written at the start,
     * since the lists' files never change while the scan runs. */
    uint8_t trunk_scan_list_count;
    uint8_t trunk_scan_active_list;
    uint8_t trunk_scan_active_list_off;
    uint8_t trunk_scan_active_lists;
    uint16_t trunk_scan_rotation_ordinal;
    uint16_t trunk_scan_rotation_count;
    uint32_t trunk_scan_lists_seq;
    dsd_trunk_scan_list_publication trunk_scan_lists[DSD_TRUNK_SCAN_MAX_LISTS];
    uint16_t trunk_scan_membership_counts[DSD_TRUNK_SCAN_MEMBERSHIP_MASKS];
    /* The scan row on air, for the "this channel" editors (issue #518): the scanner that owns it (dsd_scan_row_scanner,
     * 0 = none), the scan session (a new one for every trunk-scan coordinator and -Y scan, so an edit opened on one never
     * lands on the next), the row (a --trunk-scan target's index, a -Y channel map row), the session-edit fields
     * (DSD_SCAN_ROW_FIELD_*, runtime/scan_row_edit.h) it can take, those it runs a session edit of, and those its list
     * row sets itself. Written by the trunk-scan coordinator and the -Y channel scan beside the fields above. */
    uint32_t scan_row_session;
    int32_t scan_row_index;
    uint8_t scan_row_scanner;
    uint16_t scan_row_editable;
    uint16_t scan_row_edited;
    uint16_t scan_row_listed;
    /* The number dsd_opts::scan_row_scope_seq took when the row's options were installed (dsd_scan_mode_options()). */
    uint32_t scan_row_scope_seq;
    /* Identities and revisions of the two avoid stores (issue #672), all drawn from dsd_state_rev_next(), which never
     * repeats a value in the process, so a frontend copy keyed on them never mistakes another state's or list's value
     * for its own. state_instance: stamped once per initState(). lcn_list_rev: the positional identity of the LCN list
     * (trunk_lcn_freq, its tail, lcn_freq_count, trunk_lcn_name), new at initState() and at every wholesale replacement
     * (dsd_state_trunk_lcn_replace_begin()); an append or an in-place row write keeps it, since the frequency in an
     * LCN identity catches those. lcn_avoid_rev: moves whenever what an LCN avoid list shows could change -- a flag
     * actually set or cleared, a new lcn_list_rev, a frequency or name write to an avoided row -- and is never an
     * identity. lcn_avoid_total: the avoided rows within lcn_freq_count, which unlike lcn_avoid_count never saturates;
     * both are kept by dsd_state_trunk_lcn_avoid_set()/_clear(). trunk_scan_avoid_rev: moves at each coordinator
     * rebuild of trunk_scan_avoids and at its detach, and at nothing else (no target hop, pause or resume).
     * trunk_scan_session: the coordinator's session, a trunk-scan identity's other half, kept while paused (unlike
     * scan_row_session). trunk_scan_avoids_ok: 1 unless the coordinator could not allocate the list it last tried to
     * publish. The storage helpers (reserves, frees, snapshot copies) stamp none of them. scan_avoids_complete: 1 on a
     * live state (initState()); on a UI snapshot, 1 only when every copy of the LCN tail, names and avoid flags and of
     * trunk_scan_avoids, at this hop and the one before it, held all the source had (ui_snapshot.c), so a frontend
     * never takes a list a failed allocation cut short for the whole list. */
    uint64_t state_instance;
    uint64_t lcn_list_rev;
    uint64_t lcn_avoid_rev;
    size_t lcn_avoid_total;
    uint64_t trunk_scan_avoid_rev;
    /* Moves whenever trunk_scan_entry_reasons changes, and at its release (issue #644); what the snapshot's copy keys
       on. */
    uint64_t trunk_scan_entry_rev;
    /* The target the entry match would take as on air (dsd_engine_trunk_scan_target_confirmed(), issue #644): its
       index in trunk_scan_entry_reasons' order, -1 for none (paused, or the park not landed). Published with the
       reasons, under the same trunk_scan_entry_rev. */
    int32_t trunk_scan_entry_on_air;
    uint32_t trunk_scan_session;
    uint8_t trunk_scan_avoids_ok;
    uint8_t scan_avoids_complete;
    /* Voice-gated scan (issue #381): per-visit gate memory for -Y. Arrive/sync/voice
     * anchors are monotonic seconds (-1 = unset this visit); roll_seen restarts the
     * visit on external lcn_freq_roll changes; hold_seen is lcn_scan_hold as of the
     * previous tick, so a release can restart the qualify window; phase is a
     * dsd_scan_voice_gate_phase for the status line, owned by the -Y tick or, under
     * --trunk-scan, by the coordinator (OFF on trunked targets). Rides the
     * vertex_ks_count..ui_msg snapshot range (see ui_snapshot.c static assert). */
    double scan_voice_gate_arrive_m;
    double scan_voice_gate_sync_m;
    double scan_voice_gate_voice_m;
    /* Checked content for the -Y step (issue #834 item 3): scan_y_content_seq moves with every content a protocol's
     * CRC/FEC gate passed (a PROVEN content note, dsd_frame_sync_hook_content_evidence(), whatever the skip-silent
     * setting); the -Y frame boundary turns a move into scan_y_content_m, its decode-mono time (-1.0 for none). A -Y
     * row whose frames keep coming but carry no checked content for -t leaves at a frame boundary. */
    uint32_t scan_y_content_seq;
    uint32_t scan_y_content_seen;
    double scan_y_content_m;
    /* A content verdict a protocol still holds open for the -Y step (a PARTIAL note, whatever the skip-silent setting):
     * scan_y_partial_seq moves with each, scan_y_partial_hold_ms keeps the longest hold since the -Y frame boundary last
     * read them, which turns them into scan_y_partial_until_m, the decode-mono end of the latest hold (-1.0 for none).
     * PARTIAL is never content: it only keeps the frame-boundary step waiting for its bounded hold. */
    uint32_t scan_y_partial_seq;
    uint32_t scan_y_partial_seen;
    uint32_t scan_y_partial_hold_ms;
    double scan_y_partial_until_m;
    /* A frame of a protocol with no content check for the -Y step (X2-TDMA, ProVoice, TETRA): scan_y_unchecked_seq moves
     * as processFrame() dispatches one, and the -Y frame boundary turns a move into scan_y_unchecked_m, its decode-mono
     * time (-1.0 for none). Such a frame is no content either: it only keeps the frame-boundary step from deciding on
     * a row while those frames keep coming, since their content cannot be told from noise. It moves before the handler,
     * for a first candidate too; whether the frame was a call is scan_y_call_seq's. */
    uint32_t scan_y_unchecked_seq;
    uint32_t scan_y_unchecked_seen;
    double scan_y_unchecked_m;
    /* A call heard (issue #834), for the -Y no-check status only: it moves as the call store observes a call, begun or
     * going on (dsd_call_state_observe(), which takes only checked content), and as an active call's admitted media
     * plays (dsd_call_state_update_media()), as an analog call is admitted (the
     * conventional NFM call begins once its reception ran the minimum through every gate, engine/analog_call.c), and as
     * the ProVoice decoder took a frame of a confirmed transmission on the carrier it was dispatched on, uninterrupted
     * (processFrame()). Checked content that is no call (a control channel's traffic), raw carrier, which a
     * tone-rejected transmission has too, and a sync no decoder took never move it. */
    uint32_t scan_y_call_seq;
    /* scan_y_call_seq when the receiver's stay with no -Y row landing in force began: the run's start, a -Y scan's
     * start, or the last forget of a landing (dsd_engine_scan_y_stay_begin()). The -Y no-check status is shown on such
     * a stay until it moves past it, as on a landed row's visit until a call. */
    uint32_t scan_y_stay_call_seq;
    int scan_voice_gate_roll_seen;
    uint8_t scan_voice_gate_hold_seen;
    uint8_t scan_voice_gate_phase;
    /* Per-visit cap bookkeeping for -Y (issue #507). scan_visit_since_m is the monotonic instant
     * the row on air was tuned (-1.0 = no visit anchored, so the cap cannot fire) and
     * scan_visit_roll_seen is the lcn_freq_roll this bookkeeping last saw, so an untyped `L` or
     * avoid that moves the row without a retune note re-anchors. Deliberately separate from the
     * scan_voice_gate_* anchors above: the cap applies under the voice gate and under the legacy
     * hangtime rule alike, so it must not depend on gate-only code running -- the gate tick
     * returns early with the gate off. Rides the vertex_ks_count..ui_msg range. */
    double scan_visit_since_m;
    int scan_visit_roll_seen;
    uint8_t scan_visit_rearm_pending; /**< resume a suspended visit at the next eligible tick */
    /* The earliest monotonic instant a -Y scan sitting on a row the operator avoided tries to step off it again (issue
     * #644): the departure goes ahead of the row's carrier and an operator hold, but at the step cadence (-t, at least
     * 1 s), so a step refused, or one still in flight, is not retried on every frame
     * (dsd_engine_channel_scan_departure_due()). 0.0 until the first departure. */
    double lcn_avoid_depart_m;
    /* Scan state + live timing for the Scan Timing row (issue #508). Written by the
     * --trunk-scan coordinator for its parked target, or by the -Y timing tick when trunk
     * scan is off; the two never both write it. Rides the vertex_ks_count..ui_msg range. */
    dsd_scan_timing_publication scan_timing;
    /* Received sub-audible tone (issue #522), published by the analog tap for every frontend.
     * Rides the vertex_ks_count..ui_msg range; see dsd_analog_rx_publication. */
    dsd_analog_rx_publication analog_rx;
    /* The dynamic squelch (issue #518 follow-up) as the RTL stream last showed it, for every frontend
     * (dsd_squelch_publish_status()): whether one runs (an AUTO or NOISE setting on the analog monitor), whether that is
     * the noise squelch (0: the floor tracker, under AUTO or as NOISE's stand-in), the tracker's floor's state
     * (dsd_squelch_floor_state), whether the gate is open, whether the channel plan could be designed (0: the gate
     * stays open), the floor in hundredths of a dB on rtl_squelch_level's scale (0 while learning), whether the noise
     * squelch has measured a window yet, and its quieting in hundredths of a dB. On audio input the PCM noise squelch
     * (issue #628) writes them itself on the decoder thread, with what it knows (dsd_squelch_noise_state; 0 on radio
     * input). Rides the vertex_ks_count..ui_msg range. */
    uint8_t squelch_auto_active;
    uint8_t squelch_auto_state;
    uint8_t squelch_auto_gate_open;
    uint8_t squelch_auto_plan_valid;
    int32_t squelch_auto_floor_cdb;
    uint8_t squelch_noise_active;
    uint8_t squelch_noise_measured;
    int32_t squelch_noise_quieting_cdb;
    uint8_t squelch_noise_state;
    /* 1 while EDACS plays an analog voice call (edacs_analog(), issue #625), which ends on the dynamic squelch's gate:
       the readout shows the tracker during a call and what it is for between calls. Written on the decoder thread;
       rides the vertex_ks_count..ui_msg range. */
    uint8_t squelch_edacs_call;
    /* What the TETRA decoder shows every frontend (dsd_tetra_publication), copied from its private state extension at
       the end of each burst. Rides the vertex_ks_count..ui_msg range. */
    dsd_tetra_publication tetra_pub;
    /* The system identity received on the carrier being decoded (<dsd-neo/core/received_identity.h>), which every
       frontend shows in place of decoder state that seeds, presets and other carriers also write. Decoder-thread
       owned; rides the vertex_ks_count..ui_msg range. */
    dsd_received_identity rx_id;

    /* Counts ui_msg's toasts (dsd_state_toast_publish()), so a frontend tells a toast repeated word for word within its
       second from one it has shown already (discussion #748). Rides the vertex_ks_count..ui_msg range. */
    uint32_t ui_msg_seq;
    // Transient UI message (shown briefly in ncurses printer)
    char ui_msg[128];
    /* 1 while an accepted trunking retune's drop of the access code waits for the decoder thread to apply it to rx_id
       (dsd_rxid_request_trunk_tune(), dsd_rxid_apply_trunk_tune()): the P25 watchdog's retunes run on its thread.
       One the decoder thread makes never waits. Written and read under the P25 SM tick guard, or on the decoder
       thread where no watchdog tick runs; outside every snapshot copy range (ui_snapshot.c pins it), so no frontend
       copy reads it. */
    uint8_t rx_id_trunk_tune_pending;
    /* The protocol the last frame sync named (dsd_rxid_note_sync()): rx_id's family for a protocol that sends identity,
       the protocol itself for one that sends none (D-STAR, YSF, X2-TDMA); 0 since the last dsd_rxid_reset(). A sync of
       another protocol moves rx_id's epoch even when neither sent any identity (issue #800, fail closed). Decoder
       thread; outside every snapshot copy range. */
    uint16_t rx_sync_protocol;
    /* The P25 phase the last frame sync named (1 or 2; 0 after a sync of another protocol, since the last
       dsd_rxid_reset() or since an applied trunking retune): dsd_rxid_note_sync(). Decoder thread; outside every
       snapshot copy range. */
    uint8_t rx_p25_phase;
    /* Moves with every change of P25 phase between two P25 syncs (dsd_rxid_note_sync()), never back: a part of the
       reception generation (dsd_state_reception_generation()), so a transmission of the other phase on the carrier is
       another reception for every multi-part report, sender evidence and history row, while the system the two phases
       share stays in rx_id (issue #800, fail closed). Never reset (a trunk-scan rollback restores rx_id, not this).
       Decoder thread; outside every snapshot copy range. */
    uint32_t rx_phase_seq;
    /* Moves with every accepted trunking retune the decoder thread applies to rx_id (dsd_rxid_trunk_tune()), never
       back: the other part of the reception generation that is not rx_id's epoch, which such a retune keeps (only the
       access code goes). Decoder thread; outside every snapshot copy range. */
    uint32_t rx_tune_seq;
    /* What a tune off the decoder thread (the P25 watchdog's) that left a carrier asks the decoder thread to forget of
       the DMR calls' decryption, and hold their voice for (dsd_engine_apply_dmr_leave()): 0 nothing, else
       DSD_DMR_LEAVE_* bits. The decoder thread writes those fields in its frames and in the no-carrier pass, which runs
       outside the P25 SM tick guard, so no other thread writes them. Written under the guard by the watchdog, read and
       cleared by the decoder thread under it, before each frame; outside every snapshot copy range. */
    uint8_t dmr_leave_pending;
    /* An RTL tune still in flight (issue #834) whose landing would leave the DMR calls' carrier: its request ID, or 0.
       The decoder thread applies the decryption leave once the request lands, and drops it when the request fails,
       since the receiver then stayed (dsd_engine_apply_dmr_leave()). Written and read as dmr_leave_pending is. */
    uint64_t dmr_leave_request;

    // Extension slots for module-owned per-state allocations (see core/state_ext.h).
    void* state_ext[DSD_STATE_EXT_MAX];
    dsd_state_ext_cleanup_fn state_ext_cleanup[DSD_STATE_EXT_MAX];
    /* The TETRA burst the frame sync captured at a training sequence (dsd_tetra_sync_capture): written by the
     * frame sync and read by the TETRA decoder for the same burst. Decoder-thread private; never published.
     * The rest of the TETRA decoder state lives in its state extension (src/protocol/tetra/tetra_state.h). */
    dsd_tetra_sync_capture tetra_sync;
    /* The frame sync's history from its last no-sync exit, for the next call (dsd_frame_sync_history_carry). */
    dsd_frame_sync_history_carry frame_sync_carry;

    /* The oldest dibits of the read-back the burst the frame sync just accepted is decoded from that are not the
     * stream's (DSD_ROLLING_DIBIT_FLOOR): DMR's 90 back from dmr_payload_p, X2-TDMA's 90 (data) or 144 (voice) back
     * from dibit_buf_p. Set at every DMR and X2-TDMA accept, for the symbol clock and epoch it was accepted on; a decoder
     * reads it before reading any symbol (dsd_state_sync_readback_invalid()) and decodes and publishes nothing from
     * those dibits. 0 when the whole read-back is the stream's. */
    uint16_t sync_readback_invalid;
    uint64_t sync_readback_clock;
    uint32_t sync_readback_epoch;

    /* 1 from initState() until an engine run starts on this state, which clears it (dsd_engine_run_with_lifecycle()).
     * A state an earlier run used keeps that run's decode-domain stamps, which no rebase reaches, so a run moves the
     * decode clock onto an I/Q replay's capture clock only on a fresh one (dsd_engine_decode_clock_enter_replay()). */
    uint8_t engine_fresh;
    /* 1 when initState() could not allocate a buffer decoding needs (the rolling dibit and DMR payload buffers, the
     * audio output buffers, the vocoder parameters): the state is safe to freeState() but not to run, and every
     * frontend that starts a decoder refuses (apps/dsd-cli/main.c, the Android nativeInit). */
    uint8_t init_failed;
};

// cppcheck-suppress-end uninitMemberVarNoCtor

// NOLINTEND(clang-analyzer-optin.performance.Padding)

/* Whether a frame decoder that noted @p carrier_seq when it began reading must drop what it read, as on a sync loss:
   the carrier boundary moved the carrier count meanwhile (issue #575), or an input interruption cut the frame
   (input_interrupted: a Signal search left it, or a live read gave up on a stalled input), after which getSymbol()
   stood erasures in for every symbol. Either way part of the frame is not the transmission's, so nothing of it may
   decode, play or publish. */
/**
 * The reception generation @p state is in now (issue #800): the received identity's epoch (dsd_received_identity::epoch)
 * in the low 32 bits; in the high 32, the accepted trunking retunes applied to it (rx_tune_seq) plus the P25 phase
 * changes (rx_phase_seq), both only ever moving forward, so the sum is equal only while neither moved. Equal
 * generations are one uninterrupted reception: no retune, no other system, access code or protocol, no other P25 phase
 * in between. Every position origin (dsd_position_origin), sender evidence (dsd_position_attribution) and history row
 * (dsd_event_rx_scope) compares it. 0 for NULL. Decoder thread.
 */
static inline uint64_t
dsd_state_reception_generation(const dsd_state* state) {
    if (state == NULL) {
        return 0U;
    }
    const uint64_t carrier = (uint64_t)(uint32_t)(state->rx_tune_seq + state->rx_phase_seq);
    return (carrier << 32) | (uint64_t)state->rx_id.epoch;
}

static inline int
dsd_state_frame_read_lost(const dsd_state* state, uint32_t carrier_seq) {
    return state->carrier_seq != carrier_seq || state->input_interrupted != 0;
}

/* Publish the toast just written to state->ui_msg, shown until @p expire (epoch seconds of the real-time clock): every
   writer of a toast ends here, so ui_msg_seq counts each one and a frontend tells the same text set again within its
   second from one it has shown (discussion #748). Clearing the toast and amending the one just published do not. */
static inline void
dsd_state_toast_publish(dsd_state* state, time_t expire) {
    state->ui_msg_expire = expire;
    state->ui_msg_seq++;
}

/* The NAC the P25 Phase 1 NIDs established on the carrier goes, with any NAC change held for corroboration: the next
   NID is the first on its carrier. */
static inline void
dsd_state_forget_p25p1_carrier_nac(dsd_state* state) {
    state->p25_p1_carrier_nac.valid = 0U;
    state->p25_p1_carrier_nac.candidate_valid = 0U;
}

/* The P25 Phase 1 sync anchor goes, with the sync context of a frame being decoded: the next data unit's sync is
   matched exactly, wherever it is (dsd_p25p1_sync_anchor). */
static inline void
dsd_state_forget_p25p1_sync_anchor(dsd_state* state) {
    state->p25_p1_sync_anchor.valid = 0U;
    state->p25_p1_sync_anchor.frame_valid = 0U;
    state->p25_p1_sync_candidate.valid = 0U;
}

/* Whether the last P25 Phase 1 frame was dropped behind a sync word accepted within a tolerance, until the next
   accepted sync of any protocol (dsd_p25p1_sync_anchor::frame_dropped): it synced nothing, so a scanner counts no sync
   for it (the -Y voice gate's first sync on a row). */
static inline int
dsd_state_p25p1_frame_dropped(const dsd_state* state) {
    return state != NULL && state->p25_p1_sync_anchor.frame_dropped != 0U;
}

/* The P25 Phase 2 sync anchor goes, with the sync context of a window being decoded: the next window's sync is matched
   exactly, wherever it is (dsd_p25p2_sync_anchor). A window already opened by a tolerant sync then fails its verdict. */
static inline void
dsd_state_forget_p25p2_sync_anchor(dsd_state* state) {
    state->p25_p2_sync_anchor.valid = 0U;
    state->p25_p2_sync_anchor.frame_valid = 0U;
}

/* Raise an input interruption for @p reason (dsd_input_interrupt_reason). A reason already standing that ranks higher
   is kept: a stream gap that cut a frame a Signal search then leaves still resets the decoding it cut. */
static inline void
dsd_state_raise_input_interrupt(dsd_state* state, int reason) {
    state->input_interrupted = 1;
    if (reason > state->input_interrupt_reason) {
        state->input_interrupt_reason = reason;
    }
}

/* The input ended while a frame was read: the session is stopping (@p exit_requested, which every input that ends with
   the run asks for: a symbol capture, a PCM or WAV file, stdin, UDP, an I/Q replay or an RTL read that failed), or a
   file, TCP or symbol input ended and the session goes on with Pulse (input_fallback_pending). Past the end the reader
   stood in silence or erasures, which a strict FEC check can take for a codeword, so the read counts as cut, as an
   interruption cuts it (DSD_INTERRUPT_NONE, which the engine loop clears at its next pass). For a decoder that judges
   what it read before anything of it takes effect: the P25 Phase 1 NID, a P25 Phase 2 window. */
static inline void
dsd_state_note_input_end(dsd_state* state, int exit_requested) {
    if (exit_requested || state->input_fallback_pending) {
        dsd_state_raise_input_interrupt(state, DSD_INTERRUPT_NONE);
    }
}

/* The receiver leaves a carrier: symbols read from here on are the next carrier's. A change between symbol reads (an
   input switch, a menu tune) leaves every later symbol whole; one that runs while getSymbol() reads a symbol's samples
   (an I/Q replay retune) splits that symbol, which counts as the carrier left's. The sync join histories are the
   carrier left's evidence too: an NXDN96 lock or FSW, an NXDN48 hit, a P25p1 word the hunt read on a binary profile,
   or an M17 word, does not pair with the next carrier's, and the dwell a word hint owed 4800/4 is the left carrier's
   rotation (dsd_state_forget_sync_join_histories(), which a trunk retune runs too). */
static inline void
dsd_state_forget_sync_join_histories(dsd_state* state) {
    dsd_nxdn96_sync_clear(&state->nxdn96_sync);
    dsd_sync_hit_history_clear(&state->m17_join_hits);
    state->nxdn48_hit_type = 0;
    state->nxdn48_accept_corroborated = 0U;
    state->p25p1_word_hint_seen = 0U;
    state->p25p1_word_hint_dwell_extra = 0;
    /* The frame sync's own history from its last no-sync exit is the carrier left's too, and so is the history of a
       call in progress, which may not be kept when that call ends (dsd_frame_sync_history_carry::drops). */
    state->frame_sync_carry.valid = 0U;
    state->frame_sync_carry.drops++;
}

static inline void
dsd_state_note_carrier_change(dsd_state* state) {
    state->carrier_change_symbol_clock = state->symbol_clock + (state->symbol_read_active != 0U ? 1U : 0U);
    state->carrier_change_seen = 1U;
    dsd_state_forget_sync_join_histories(state);
    /* The DMR checked-LC source names a radio of the carrier left (another system after a target switch or a move):
       no embedded GPS fix of the next reception is attributed by it (issue #800). */
    dsd_position_attribution_clear(&state->dmr_lc_attribution[0]);
    dsd_position_attribution_clear(&state->dmr_lc_attribution[1]);
}

/* Whether a frame whose sync ends on the latest symbol and that reads up to @p lookback symbols back (its sync word
   and what a decoder takes from the hunt's history or a rolling buffer before it) may hold a symbol of the carrier left:
   fewer than @p lookback whole symbols of the new carrier have been read. */
static inline int
dsd_state_carrier_settling(const dsd_state* state, uint64_t lookback) {
    if (state->carrier_change_seen == 0U) {
        return 0;
    }
    const uint64_t last_left = state->carrier_change_symbol_clock;
    return (state->symbol_clock < last_left || state->symbol_clock - last_left < lookback) ? 1 : 0;
}

/* Entries written to the rolling buffer @p buf (dibit_buf or dmr_payload_buf) at @p p since its last clear or wrap
 * (DSD_ROLLING_DIBIT_FLOOR): how far back from @p p a decoder reads real dibits. */
static inline long
dsd_state_rolling_dibits(const int* buf, const int* p) {
    if (buf == NULL || p == NULL || p < buf + DSD_ROLLING_DIBIT_FLOOR) {
        return 0;
    }
    return (long)(p - (buf + DSD_ROLLING_DIBIT_FLOOR));
}

/* Note @p invalid oldest dibits of the read-back of the burst the frame sync accepts now (dsd_state::sync_readback_invalid).
 */
static inline void
dsd_state_note_sync_readback(dsd_state* state, long invalid) {
    state->sync_readback_invalid = (uint16_t)(invalid > 0 ? (invalid < 0xFFFF ? invalid : 0xFFFF) : 0);
    state->sync_readback_clock = state->symbol_clock;
    state->sync_readback_epoch = state->symbol_clock_epoch;
}

/* For a decoder about to decode the burst the frame sync accepted, before it reads any symbol: how many of the oldest
 * dibits of its read-back are not the stream's. 0 once a symbol was read since the accept, so a decoder further on in a
 * burst loop never takes it. */
static inline unsigned int
dsd_state_sync_readback_invalid(const dsd_state* state) {
    if (state->sync_readback_clock != state->symbol_clock || state->sync_readback_epoch != state->symbol_clock_epoch) {
        return 0U;
    }
    return state->sync_readback_invalid;
}

/* The carrier's Phase 2 proofs go (issue #575, #802): the seed's (p2_cc_verified) and the NAC the latest proof named
   (p2_proven_nac). Every place that leaves the carrier, or changes the seed, runs this; p2_cc itself stays. */
static inline void
dsd_state_forget_p2_proof(dsd_state* state) {
    state->p2_cc_verified = 0U;
    state->p2_proven_nac = -1;
}

/* A checked Phase 2 proof on this carrier named @p nac (issue #802): it becomes the carrier's proven NAC, the latest
   proof winning. dsd-neo takes no NAC 0x000 or 0xFFF (a dead or stuck input decodes as either), so those, and anything
   past twelve bits, prove nothing and leave the record as it was. 1 when the record took a new value. */
static inline int
dsd_state_note_p2_proven_nac(dsd_state* state, unsigned long long nac) {
    if (nac < 0x001ULL || nac > 0xFFEULL || state->p2_proven_nac == (int)nac) {
        return 0;
    }
    state->p2_proven_nac = (int)nac;
    return 1;
}

static inline int
dsd_state_trunk_chan_valid(uint32_t channel) {
    return channel < DSD_TRUNK_CHAN_MAP_SIZE;
}

static inline int
dsd_state_trunk_chan_tracked(uint32_t channel) {
    return channel > 0U && dsd_state_trunk_chan_valid(channel);
}

static inline void
dsd_state_track_trunk_chan(dsd_state* state, uint16_t channel) {
    if (!state || !dsd_state_trunk_chan_tracked(channel)) {
        return;
    }

    uint32_t count = state->trunk_chan_map_used_count;
    if (count > DSD_TRUNK_CHAN_MAP_SIZE) {
        count = DSD_TRUNK_CHAN_MAP_SIZE;
    }

    uint32_t insert = count;
    for (uint32_t i = 0; i < count; i++) {
        if (state->trunk_chan_map_used[i] == channel) {
            state->trunk_chan_map_used_count = count;
            return;
        }
        if (state->trunk_chan_map_used[i] > channel) {
            insert = i;
            break;
        }
    }

    if (count >= DSD_TRUNK_CHAN_MAP_SIZE) {
        state->trunk_chan_map_used_count = count;
        return;
    }

    for (uint32_t i = count; i > insert; i--) {
        state->trunk_chan_map_used[i] = state->trunk_chan_map_used[i - 1];
    }
    state->trunk_chan_map_used[insert] = channel;
    state->trunk_chan_map_used_count = count + 1U;
}

static inline void
dsd_state_untrack_trunk_chan(dsd_state* state, uint16_t channel) {
    if (!state || !dsd_state_trunk_chan_tracked(channel)) {
        return;
    }

    uint32_t count = state->trunk_chan_map_used_count;
    if (count > DSD_TRUNK_CHAN_MAP_SIZE) {
        count = DSD_TRUNK_CHAN_MAP_SIZE;
    }

    for (uint32_t i = 0; i < count; i++) {
        if (state->trunk_chan_map_used[i] != channel) {
            continue;
        }
        for (uint32_t j = i + 1U; j < count; j++) {
            state->trunk_chan_map_used[j - 1U] = state->trunk_chan_map_used[j];
        }
        state->trunk_chan_map_used[count - 1U] = 0;
        state->trunk_chan_map_used_count = count - 1U;
        return;
    }
    state->trunk_chan_map_used_count = count;
}

/* Take a channel map row out of the NXDN DFA record (dsd_nxdn_dfa_learned): its next writer owns it. */
static inline void
dsd_state_nxdn_dfa_untag(dsd_state* state, uint32_t channel) {
    dsd_nxdn_dfa_learned* learned = &state->nxdn_dfa_learned;
    uint16_t count = learned->count;
    if (count > DSD_NXDN_DFA_LEARNED_MAX) {
        count = DSD_NXDN_DFA_LEARNED_MAX;
    }
    for (uint16_t i = 0; i < count; i++) {
        if (learned->chan[i] != channel) {
            continue;
        }
        learned->chan[i] = learned->chan[count - 1U];
        learned->freq[i] = learned->freq[count - 1U];
        count--;
        break;
    }
    learned->count = count;
}

/* Set one channel map row. Every writer but the NXDN DFA resolver (dsd_nxdn_dfa_learn()) sets a row it owns, so the
   row leaves the DFA record and no later parameter change drops it. */
static inline void
dsd_state_set_trunk_chan_freq(dsd_state* state, uint32_t channel, long int freq) {
    if (!state || !dsd_state_trunk_chan_valid(channel)) {
        return;
    }
    if (state->nxdn_dfa_learned.count != 0U) {
        dsd_state_nxdn_dfa_untag(state, channel);
    }

    const long int old_freq = state->trunk_chan_map[channel];
    if (old_freq == freq) {
        return;
    }

    state->trunk_chan_map[channel] = freq;
    if (!dsd_state_trunk_chan_tracked(channel)) {
        state->trunk_chan_map_seq++;
        return;
    }
    if (old_freq == 0) {
        dsd_state_track_trunk_chan(state, (uint16_t)channel);
    } else if (freq == 0) {
        dsd_state_untrack_trunk_chan(state, (uint16_t)channel);
    }
    state->trunk_chan_map_seq++;
}

/**
 * Address the scan-list LCN slot at index i. The first DSD_TRUNK_LCN_EMBEDDED slots
 * live in the embedded trunk_lcn_freq array (protocol fixed-slot writers keep
 * raw-indexing those); higher slots live in the heap tail trunk_lcn_freq_ext. Callers
 * must guarantee 0 <= i < lcn_freq_count for reads, or that the index is addressable
 * (trunk_lcn_freq_ext_capacity > i - DSD_TRUNK_LCN_EMBEDDED) for writes into the tail.
 */
static inline long int*
dsd_state_trunk_lcn_slot(dsd_state* state, int i) {
    return i < DSD_TRUNK_LCN_EMBEDDED ? &state->trunk_lcn_freq[i]
                                      : &state->trunk_lcn_freq_ext[i - DSD_TRUNK_LCN_EMBEDDED];
}

/** Const-qualified dsd_state_trunk_lcn_slot() for read-only contexts. */
static inline const long int*
dsd_state_trunk_lcn_slot_const(const dsd_state* state, int i) {
    return i < DSD_TRUNK_LCN_EMBEDDED ? &state->trunk_lcn_freq[i]
                                      : &state->trunk_lcn_freq_ext[i - DSD_TRUNK_LCN_EMBEDDED];
}

/**
 * Ensure scan-list indices 0..count_needed-1 are addressable via
 * dsd_state_trunk_lcn_slot(): grows the heap tail by doubling and zero-fills
 * the new tail; no-op when count_needed <= DSD_TRUNK_LCN_EMBEDDED. Returns 0 on
 * success, -1 on allocation failure (state left valid, contents preserved).
 */
int dsd_state_trunk_lcn_reserve(dsd_state* state, size_t count_needed);

/**
 * Free the scan-list heap tail, the per-row name, avoid and key stores and the
 * scan key swap state, and zero their pointers/capacities. The embedded
 * DSD_TRUNK_LCN_EMBEDDED slots are part of dsd_state and need no release. The
 * published trunk-scan avoid list is not an LCN store and is left alone: only
 * its owner empties it, with a new revision (dsd_state_trunk_scan_avoids_free()
 * from the trunk-scan detach, initState() or freeState()). A storage helper: it stamps no revision.
 */
void dsd_state_trunk_lcn_free(dsd_state* state);

/**
 * The next value of the process-wide revision counter (issue #672): never 0, never repeated, never reset, so a value
 * stamped on one state, list or publication is never taken by another. state_instance, lcn_list_rev, lcn_avoid_rev
 * and trunk_scan_avoid_rev are all drawn from it.
 */
uint64_t dsd_state_rev_next(void);

/**
 * Begin a wholesale replacement of the LCN list (issue #672): drop the avoid flags, which index rows that no longer
 * exist (lcn_avoid_count and lcn_avoid_total go to 0), and stamp a new lcn_list_rev and lcn_avoid_rev. The caller then
 * writes the rows, names and lcn_freq_count of the new list directly. Every writer that replaces the list calls it:
 * initState() aside (which stamps its own), the channel-map adopt and clear, the P25 CC selection's automatic anchor and
 * a trunk-scan target's list restore. A NULL state is ignored.
 */
void dsd_state_trunk_lcn_replace_begin(dsd_state* state);

/**
 * Write @p hz into LCN row @p row in place or as an append past lcn_freq_count (issue #672), growing the heap tail when
 * the row needs it; lcn_freq_count is not changed (dsd_state_trunk_lcn_count_raise()). Stamps lcn_avoid_rev only when
 * the row is avoided and its value changes. Every writer that changes one row of an existing list goes through it.
 * Returns 0, or -1 on a NULL state, a negative row or a failed allocation (nothing written).
 */
int dsd_state_trunk_lcn_freq_write(dsd_state* state, int row, long int hz);

/**
 * Raise lcn_freq_count to at least @p count (never lower it), the second half of an append (issue #672). When avoid
 * flags past the old count come into the list, lcn_avoid_count/lcn_avoid_total count them and lcn_avoid_rev is stamped.
 */
void dsd_state_trunk_lcn_count_raise(dsd_state* state, int count);

/** Usable encoded base/spacing within the portable trunk frequency range. */
int dsd_p25_iden_params_usable(long base, int spacing);

/** Whether a usable TDMA entry has zero provenance or names the current system. */
int dsd_state_p25_iden_tdma_applies(const dsd_state* state, int iden);

/** Drop an untyped FDMA fallback when TDMA applies; return 1 if dropped. No cache work. */
int dsd_state_p25_iden_reconcile(dsd_state* state, int iden);

/** Clear one identifier's channel-map range (including user channel-map rows). */
void dsd_state_p25_invalidate_iden_chan_map(dsd_state* state, int iden);

/**
 * Seed TDMA, reconcile, then seed FDMA, scoped rows before global rows in each class.
 * Typed rows may replace untyped entries; scoped rows may replace global seeds, never
 * typed OTA entries. Untyped rows wait while TDMA applies. Fills preserve the channel
 * map; replacements/drops invalidate once per identifier. Return the slots written.
 */
int dsd_state_p25_bandplan_seed(dsd_state* state);

/** Internal lifecycle variant: return writes and report replacements/drops without invalidating. */
int dsd_state_p25_bandplan_seed_mask(dsd_state* state, uint16_t* changed_idens);

/**
 * Collect usable entries, preferring typed rows over untyped rows of the same key.
 * TDMA suppresses untyped FDMA only within the exact same system scope. All candidates
 * are considered even at capacity. Add entries with no room to skipped (may be NULL).
 * Either table may be NULL. Return the new row count, never above cap.
 */
int dsd_p25_bandplan_append_tables(p25_bandplan_row_t* rows, int count, int cap, const p25_iden_entry_t* fdma,
                                   const p25_iden_entry_t* tdma, int* skipped);

/**
 * Ensure name-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing names preserved).
 */
int dsd_state_trunk_lcn_name_reserve(dsd_state* state, size_t count);

/** Free the per-row name store and zero its pointer/capacity. */
void dsd_state_trunk_lcn_name_free(dsd_state* state);

/**
 * Store the name of scan-list row @p index; an avoided row whose name changes stamps lcn_avoid_rev (issue #672).
 * The name is truncated to
 * DSD_CHANNEL_LABEL_SIZE - 1 bytes without splitting a UTF-8 character, has
 * control characters replaced with spaces (so a stray tab or CR never reaches
 * the terminal), and is trimmed of leading and trailing ASCII whitespace --
 * including whatever that substitution and truncation leave at either end. A
 * NULL or blank name clears the entry, allocating nothing when the store does
 * not already reach @p index. Returns 0 on success, -1 on allocation failure or
 * a NULL state.
 */
int dsd_state_trunk_lcn_name_set(dsd_state* state, size_t index, const char* name);
/**
 * Name of scan-list row @p index, or "" when the row is unnamed, the store is
 * shorter than @p index, or no name column was ever imported. Never NULL.
 */
const char* dsd_state_trunk_lcn_name_get(const dsd_state* state, size_t index);

/**
 * Ensure avoid-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing flags preserved).
 */
int dsd_state_trunk_lcn_avoid_reserve(dsd_state* state, size_t count);

/** Free the per-row avoid store and zero its pointer/capacity. lcn_avoid_count is not touched. */
void dsd_state_trunk_lcn_avoid_free(dsd_state* state);

/**
 * Ensure key-store indices 0..count-1 are addressable: grows by doubling and
 * zero-fills the new entries. Returns 0 on success, -1 on allocation failure
 * (state left valid, existing sets preserved).
 */
int dsd_state_trunk_lcn_keys_reserve(dsd_state* state, size_t count);

/** Free the per-row key store and zero its pointer/capacity. */
void dsd_state_trunk_lcn_keys_free(dsd_state* state);

/**
 * Move @p ks into the store at @p index, freeing any previous entry there.
 * Takes ownership of the entries pointer; the caller must not free it after a
 * successful call. Returns 0 on success, -1 on allocation failure or NULL state.
 */
int dsd_state_trunk_lcn_keys_set(dsd_state* state, size_t index, dsd_key_set* ks);

/**
 * Key set of scan-list row @p index, or NULL when the row carries no keys.
 * Decoder thread only; the pointer is invalidated by subsequent key-store growth.
 */
const dsd_key_set* dsd_state_trunk_lcn_keys_get(const dsd_state* state, size_t index);

/** Non-zero when any row in the store carries a key set. */
int dsd_state_trunk_lcn_keys_present(const dsd_state* state);

/**
 * Flag scan-list row @p index as avoided (@p avoided != 0) or put it back. Setting a
 * flag grows the store on demand; clearing a row the store does not reach allocates
 * nothing. Recounts lcn_avoid_count (saturating) and lcn_avoid_total over the rows
 * within lcn_freq_count, and stamps lcn_avoid_rev only when the flag changes. Returns 0
 * on success, -1 on allocation failure or a NULL state.
 */
int dsd_state_trunk_lcn_avoid_set(dsd_state* state, size_t index, int avoided);

/** 1 when row @p index is avoided; 0 otherwise, including past the store or with no store. */
int dsd_state_trunk_lcn_avoid_get(const dsd_state* state, size_t index);

/**
 * Put every avoided row back. Returns how many rows within lcn_freq_count were
 * avoided (lcn_avoid_count, so saturated); the store keeps its capacity.
 * lcn_avoid_count and lcn_avoid_total are zeroed, and lcn_avoid_rev is stamped when
 * any flag was set.
 */
int dsd_state_trunk_lcn_avoid_clear(dsd_state* state);

/**
 * Ensure the published trunk-scan avoid list (dsd_state::trunk_scan_avoids) can hold @p count entries, growing it by
 * doubling. Returns 0, or -1 on a NULL state or a failed allocation (the list and its count kept). A storage helper:
 * it stamps nothing.
 */
int dsd_state_trunk_scan_avoids_reserve(dsd_state* state, size_t count);

/**
 * Replace the published trunk-scan avoid list with a copy of @p count entries (@p entries may be NULL when @p count is
 * 0). On a failed allocation the list is left empty (count 0, no stale entries) and -1 returned; -1 too for a NULL
 * state. A storage helper: it stamps nothing -- the coordinator stamps trunk_scan_avoid_rev after a rebuild.
 */
int dsd_state_trunk_scan_avoids_set(dsd_state* state, const dsd_trunk_scan_avoid_entry* entries, size_t count);

/** Free the published trunk-scan avoid list and zero its pointer, count and capacity. Stamps nothing. */
void dsd_state_trunk_scan_avoids_free(dsd_state* state);

/**
 * Ensure the published trunk-scan entry reasons (dsd_state::trunk_scan_entry_reasons) can hold @p count bytes. Returns
 * 0, or -1 on a NULL state or a failed allocation (the store and its count kept). Stamps nothing.
 */
int dsd_state_trunk_scan_entry_reasons_reserve(dsd_state* state, size_t count);

/**
 * Replace the published trunk-scan entry reasons with a copy of @p count bytes (@p reasons may be NULL when @p count is
 * 0). On a failed allocation the store is left empty and -1 returned; -1 too for a NULL state. Stamps nothing.
 */
int dsd_state_trunk_scan_entry_reasons_set(dsd_state* state, const uint8_t* reasons, size_t count);

/** Free the published trunk-scan entry reasons and zero their pointer, count and capacity. Stamps nothing. */
void dsd_state_trunk_scan_entry_reasons_free(dsd_state* state);

#ifdef DSD_NEO_TEST_HOOKS
/* Let the next N allocations of the scan-list reserve helpers (the LCN tail, name, avoid and trunk-scan avoid stores)
   succeed and fail every one after; -1 (the default) disables the seam. */
void dsd_state_trunk_lcn_test_alloc_fail_after(long successful_allocations);
#endif

/** Rows below lcn_freq_count that carry a frequency and are not avoided. */
int dsd_state_trunk_lcn_usable_count(const dsd_state* state);

/**
 * First row index at or after @p from (wrapping through the list) that is not avoided.
 * A @p from outside 0..lcn_freq_count-1 starts at row 0. Placeholder (0 Hz) rows are
 * not skipped: the scanner parks on them deliberately. Returns -1 when the list is
 * empty or every row is avoided.
 */
int dsd_state_trunk_lcn_next_unavoided(const dsd_state* state, int from);

/**
 * Record scan-list row @p row as the one the last accepted step selected (issue #666), with its frequency, and drop
 * any backward-retry row. Written by exactly the events that move lcn_freq_roll past a row the receiver was put on: a
 * typed row's commit, an untyped row's install, a manual untyped step that tuned, a P25 hunt probe of a -T channel map
 * row whose tune was accepted. A row outside the list or a 0 Hz placeholder (a park, not a tune) records nothing.
 */
void dsd_state_lcn_on_air_note(dsd_state* state, int row);

/**
 * A step's tune failed hard (refused, either direction, manual or timed, a P25 hunt probe of a -T channel-map row
 * included). A recorded row that still describes the list stays: the receiver is still on it. With none, the row heard
 * becomes none, not the row before lcn_freq_roll, which the failure may have moved past the row it never tuned, until
 * a row is recorded or the records are reset (dsd_state_lcn_nav_reset(): a list loaded or replaced).
 */
void dsd_state_lcn_on_air_note_refused(dsd_state* state);

/** Forget the recorded row (dsd_state_lcn_on_air_note()). */
void dsd_state_lcn_on_air_clear(dsd_state* state);

/**
 * The recorded row while it still describes the list: inside lcn_freq_count, not 0 Hz, and holding the frequency it
 * held when it was recorded. -1 otherwise, and for a NULL state.
 */
int dsd_state_lcn_on_air_row(const dsd_state* state);

/**
 * The scan-list row heard: the recorded row (dsd_state_lcn_on_air_row()), else, before any step recorded one, the row
 * before lcn_freq_roll when it exists and is not 0 Hz; -1 when neither, and after a hard-failed step with no row
 * recorded (dsd_state_lcn_on_air_note_refused()). Unlike roll - 1 it does not move when a step skips, wraps, fails,
 * waits on its tune, or parks on a placeholder.
 */
int dsd_state_lcn_heard_row(const dsd_state* state);

/** Record @p row, with its frequency, as the row a hard-failed backward step tried; same validity rule as the
 * on-air row, so a 0 Hz or out-of-list row records nothing. */
void dsd_state_lcn_back_retry_note(dsd_state* state, int row);

/** Forget the backward-retry row. */
void dsd_state_lcn_back_retry_clear(dsd_state* state);

/** The backward-retry row while it still describes the list (as dsd_state_lcn_on_air_row()), else -1. */
int dsd_state_lcn_back_retry_row(const dsd_state* state);

/** Forget both the on-air and the backward-retry rows: the list or its session changed under them. */
void dsd_state_lcn_nav_reset(dsd_state* state);

/**
 * Whether the scan list is operator-supplied rather than learned over the air.
 *
 * A `-C`/`-Y` channel map, or a per-target chan_csv under trunk scan, is
 * positional: index i is LCN i+1, and an unparseable row deliberately stores 0
 * to keep that numbering. Protocol site broadcasts must therefore neither write
 * into such a list nor lower lcn_freq_count to the handful of slots they know
 * about. Trunk scan rejects a global chan_in_file at init and seeds slot 0 with
 * the target's park frequency, so under -Y a count above 1 is the only evidence
 * a per-target map was imported.
 */
int dsd_state_trunk_lcn_user_list_present(const dsd_opts* opts, const dsd_state* state);

/**
 * Whether a single-system trunked session may hunt its channel map for a control channel it has never decoded
 * (issue #703): trunking on outside -Y and --trunk-scan, off any granted voice channel, no input switch pending its
 * carrier boundary, not an I/Q replay (which defers every retune), a tuner the trunking hooks move (an RTL-family
 * input or rigctl), a user channel map with a nonzero row, and no protocol proven yet (owner unknown). Which machine
 * hunts is decided by the caller.
 */
int dsd_state_trunk_cold_start_eligible(const dsd_opts* opts, const dsd_state* state);

/**
 * Whether a single-system trunked NXDN session may hunt its channel map for a control channel: every condition of
 * dsd_state_trunk_cold_start_eligible() except the owner, which may be unknown (a startup hunt) or NXDN (recovery of
 * a lost control channel). Whether NXDN may own the trunk is the caller's (dsd_trunk_nxdn_recovery_allowed()).
 */
int dsd_state_trunk_nxdn_hunt_eligible(const dsd_opts* opts, const dsd_state* state);

/**
 * Whether a single-system trunked DMR session may hunt its channel map for a control channel: every condition of
 * dsd_state_trunk_cold_start_eligible() except the owner, which may be unknown (a startup hunt) or DMR (validated DMR
 * content named the protocol without confirming a control channel here). Whether the DMR machine has confirmed one is
 * the caller's (dmr_trunk_sm.c).
 */
int dsd_state_trunk_dmr_hunt_eligible(const dsd_opts* opts, const dsd_state* state);

static inline int
dsd_state_minmax_window_size(int requested) {
    if (requested < 1) {
        return 1;
    }
    if (requested > 1024) {
        return 1024;
    }
    return requested;
}

static inline void
dsd_state_invalidate_minmax_sums(dsd_state* state) {
    if (!state) {
        return;
    }
    state->minmax_sum_window = 0;
}

static inline void
dsd_state_recompute_minmax_sums(dsd_state* state, int requested_window) {
    if (!state) {
        return;
    }

    const int window = dsd_state_minmax_window_size(requested_window);
    double min_sum = 0.0;
    double max_sum = 0.0;
    for (int i = 0; i < window; i++) {
        min_sum += (double)state->minbuf[i];
        max_sum += (double)state->maxbuf[i];
    }

    state->minbuf_sum = min_sum;
    state->maxbuf_sum = max_sum;
    state->minmax_sum_window = window;
    if (state->midx < 0 || state->midx >= window) {
        state->midx = 0;
    }
}

static inline void
dsd_state_push_minmax_window(dsd_state* state, int requested_window, float min_value, float max_value) {
    if (!state) {
        return;
    }

    const int window = dsd_state_minmax_window_size(requested_window);
    if (state->minmax_sum_window != window) {
        dsd_state_recompute_minmax_sums(state, window);
    }

    int idx = state->midx;
    if (idx < 0 || idx >= window) {
        idx = 0;
    }

    state->minbuf_sum += (double)min_value - (double)state->minbuf[idx];
    state->maxbuf_sum += (double)max_value - (double)state->maxbuf[idx];
    state->minbuf[idx] = min_value;
    state->maxbuf[idx] = max_value;

    idx++;
    state->midx = (idx >= window) ? 0 : idx;
    state->min = (float)(state->minbuf_sum / (double)window);
    state->max = (float)(state->maxbuf_sum / (double)window);
}

/**
 * @brief Rescale symbol timing state between two effective PCM rates.
 *
 * This helper updates only timing-related state. Callers that also need analog
 * filter coefficients rebuilt should do that separately.
 *
 * @param state Decoder state to update.
 * @param old_rate_hz Previous effective PCM rate.
 * @param new_rate_hz New effective PCM rate.
 */
static inline void
dsd_state_rescale_symbol_timing(dsd_state* state, int old_rate_hz, int new_rate_hz) {
    if (!state) {
        return;
    }

    if (old_rate_hz <= 0) {
        old_rate_hz = 48000;
    }
    if (new_rate_hz <= 0) {
        new_rate_hz = old_rate_hz;
    }
    if (old_rate_hz == new_rate_hz) {
        return;
    }

    int old_sps = state->samplesPerSymbol > 0 ? state->samplesPerSymbol : 10;
    long long scaled = (long long)old_sps * (long long)new_rate_hz;
    int new_sps = (int)((scaled + (old_rate_hz / 2)) / old_rate_hz);
    if (new_sps < 2) {
        new_sps = 2;
    } else if (new_sps > 64) {
        new_sps = 64;
    }

    int new_center = (new_sps - 1) / 2;
    if (new_sps > 2) {
        int min_c = 1;
        int max_c = new_sps - 2;
        long long ratio_num = state->symbolCenter;
        long long ratio_den = old_sps;
        if ((ratio_num * 20LL) < ratio_den) {
            ratio_num = 1;
            ratio_den = 20;
        } else if ((ratio_num * 20LL) > (19LL * ratio_den)) {
            ratio_num = 19;
            ratio_den = 20;
        }
        const long long center_scaled = ratio_num * (long long)new_sps;
        new_center = (int)((center_scaled + (ratio_den / 2LL)) / ratio_den);
        if (new_center < min_c) {
            new_center = min_c;
        } else if (new_center > max_c) {
            new_center = max_c;
        }
    }

    state->samplesPerSymbol = new_sps;
    state->symbolCenter = new_center;
    state->jitter = -1;
}
#endif /* DSD_NEO_INCLUDE_DSD_NEO_CORE_STATE_H_H */

"""Compare the original IC-705 file player and IF DSP commands during receive."""
from hashlib import sha256
import json
from pathlib import Path
import struct
import sys
import wave

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / ".analysis/ic705-emulator/deps")]
from tools.emulate_705 import RAM, SCRATCH, arm, call, machine, uc
from tools.replay_705_aprs_fm import SQL_KNOB,DSP_STATUS,DSP_NOISE,SQL_SETTINGS,SQL_STEP,SQL_PUBLISH,SQL_STATE
from tools.replay_705_aprs_task import e140_rom
from tools.build_705_dmr_station import OUT
from tools.decode_705_main import decode_main
from tools.emulate_705 import BASE
from tools.verify_705_ftx_rx import symbols
from tools.probe_705_cw_menu import MODE_UI_A, MODE_VFO_A
from tools.probe_705_rx_audio import DMAC


def replay(region, page, pcm, candidate=False):
    home = (ROOT / f".analysis/dmr-ui/{region}/rtx-home-ram.bin").read_bytes()
    cpu = machine()
    cpu.mem_write(RAM, home)
    if candidate:
        folder = OUT / region
        dat = (folder / f"705{region}140.dat").read_bytes()
        meta = json.loads((folder / "package.json").read_text())
        assert sha256(dat).hexdigest() == meta["sha256"]
        main = bytes(decode_main(dat)[1])
        assert sha256(main).hexdigest() == meta["main_sha256"]
        cpu.mem_write(BASE, main)
        sy = symbols(folder / "station.elf")
        cpu.mem_write(sy["__work_start"], bytes(sy["__work_end"] - sy["__work_start"]))
    for address in [0xfcfe0000, 0xfcff0000, DMAC, 0xe8010000, 0xe8000000, 0xe8030000]:
        cpu.mem_map(address, 0x10000)
    cpu.reg_write(arm.UC_ARM_REG_C1_C0_2, 0xf00000)
    cpu.reg_write(arm.UC_ARM_REG_FPEXC, 0x40000000)
    delta = 0xe4 if region == "E" else 0

    def native(address, *args):
        return call(cpu, address + delta, *args, timeout_us=0, instruction_limit=400000)

    cpu.mem_write(0x20380172, b"\x03")
    for address in (MODE_VFO_A, MODE_UI_A):
        cpu.mem_write(address, b"\x70")
    cpu.mem_write(0x203e84bf + 10, struct.pack("<H", page))
    cpu.mem_write(SCRATCH, b"RX-test.wav\0")
    cpu.mem_write(DSP_STATUS,b"\x40")
    cpu.mem_write(SQL_KNOB,b"\x64")
    native(SQL_SETTINGS)
    native(0x2011ae24, 0x204987c0)
    queued = []

    def on_enqueue(c, pc, size, data):
        queued.append(c.reg_read(arm.UC_ARM_REG_R0))

    enqueue = 0x20118c9c + delta
    cpu.hook_add(uc.UC_HOOK_CODE, on_enqueue, begin=enqueue, end=enqueue)

    carrier = True
    cpu.mem_write(0x203e1b78, b"\1")
    def refresh():
        queued.clear()

        cpu.mem_write(DSP_NOISE,struct.pack("<H", 0 if carrier else 65535))
        native(SQL_STEP)
        call(cpu,e140_rom(SQL_PUBLISH) if region=="E" else SQL_PUBLISH)
        native(0x200d49f4)
        native(0x2011e1c0, 0)
        return queued.copy()

    refresh()
    def control_image():
        return [f"{word:08x}" for word in struct.unpack("<27I", cpu.mem_read(0x204987c0, 108))]

    stages = {"idle": refresh()}
    idle_image = control_image()
    assert not stages["idle"]
    if candidate:
        images = {}
        def observe(name):
            stages[name] = refresh()
            images[name] = control_image()
            assert cpu.mem_read(0x203db47d, 1) == b"\0"
        for enabled, signal, name in [(False, False, "fm_closed"), (False, True, "fm_open"),
                                      (True, True, "dmr_carrier"), (True, False, "dmr_quiet"),
                                      (True, True, "dmr_again"), (False, True, "exit_carrier"),
                                      (False, False, "exit_quiet")]:
            carrier = signal
            cpu.mem_write(sy["dmr_guard_active"], bytes([enabled]))
            observe(name)
            assert cpu.mem_read(SQL_STATE, 1) == bytes([signal])
        return dict(dat_sha256=meta["sha256"], images=images, commands=stages)
    cpu.mem_write(SCRATCH + 64,b"20261123\0")
    cpu.mem_write(SCRATCH + 128,b"20261123_081129.wav\0")
    native(0x200f71f0,SCRATCH + 64,SCRATCH + 128,SCRATCH + 128)
    assert cpu.mem_read(0x203db47d,1) == b"\1"
    stages["start"] = refresh()
    # Begin at the disk-read completion boundary. The file bytes are available,
    # while the two busy flags prevent another asynchronous disk request.
    native(0x200c0098)
    cpu.mem_write(0x20380619, b"\5")
    cpu.mem_write(0x203db784 + 8, struct.pack("<IIH", len(pcm), 0, 0))
    cpu.mem_write(0x20403740 + 0x251c4, pcm)
    cpu.mem_write(0x20380640, b"\1\1")
    native(0x200c01b8)
    assert cpu.mem_read(0x2038061d, 1) == b"\1"
    played = bytearray()
    bank = 0
    for _ in range(len(pcm) // 36):
        native(0x200c0a8c)
        native(0x201101cc)
        assert (native(0x200ff4c4), native(0x200ff6ac)) == (3, 0)
        for _ in range(3):
            cpu.mem_write(DMAC + 0x124, struct.pack("<I", 0x41 if bank else 0xc1))
            native(0x200ffd48)
            bank_base = 0x20400b60 if bank else 0x20400a40
            slots = struct.unpack("<72i", cpu.mem_read(bank_base, 288))
            played.extend(struct.pack("<6h", *(sample >> 16 for sample in slots[::12])))
            bank ^= 1
    assert played == pcm
    stages["buffered_playback"] = refresh()
    playing_image = control_image()
    for name, action in [("pause", 0x200bc51c), ("resume", 0x200bc548), ("stop", 0x200bc714)]:
        native(action)
        stages[name] = refresh()
    stop_image = control_image()
    assert cpu.mem_read(0x203db47d, 1) == b"\0"
    native(0x201006c8)
    stages["audio_init_while_stopped"] = refresh()
    assert cpu.mem_read(0x203db47d, 1) == b"\0"
    assert stages["audio_init_while_stopped"] == [0x45800000]
    assert stages["start"] == stages["resume"]
    assert stages["pause"] == stages["stop"]

    # Exercise each captured word through the original queue dispatcher and
    # ready interrupt in isolation. A modeled ready pin permits the write.
    wire = bytearray()

    def on_serial_write(c, kind, address, size, value, data):
        assert size == 1
        wire.append(value)

    cpu.hook_add(uc.UC_HOOK_MEM_WRITE, on_serial_write, begin=0xe800e004, end=0xe800e004)
    for word in dict.fromkeys(word for words in stages.values() for word in words):
        wire.clear()
        cpu.mem_write(0x20380b58, b"\1")
        cpu.mem_write(0x204988e0, struct.pack("<II", 1, word))
        cpu.mem_write(0x204988e0 + 592, b"\1\0")
        native(0x2011edc4)
        native(0x20118d84)
        assert wire == word.to_bytes(4, "big"), (hex(word), wire.hex())
    return {
        "home_ram_sha256": sha256(home).hexdigest(),
        "control_image": {"idle": idle_image, "playing": playing_image, "stop": stop_image},
        "pcm_samples": len(played) // 2,
        "ssi0_playback_sha256": sha256(played).hexdigest(),
        "control_words": {name: [f"{word:08x}" for word in words] for name, words in stages.items()},
        "each_distinct_word_checked_at_rspi3_data_register": True,
    }


if __name__ == "__main__":
    source = ROOT / ".analysis/dmr-rx3/final/J/dmr-received-field.wav"
    with wave.open(str(source), "rb") as wav:
        assert wav.getparams()[:3] == (1, 2, 8000)
        data = wav.readframes(wav.getnframes())
    # Start inside speech, away from leading silence. Each player record holds 18 samples.
    start = next(i for i in range(0, len(data) - 7200, 36)
                 if max(abs(s) for s in struct.unpack_from("<18h", data, i)) > 1000)
    pcm = data[start:start + 7200]
    results = {region: {hex(page): replay(region, page, pcm) for page in (0, 0x98, 0xd7, 0xa7)}
               for region in ("J", "E")}
    for page, japanese in results["J"].items():
        assert japanese["control_words"] == results["E"][page]["control_words"]

    for region, pages in results.items():
        reference = pages["0x98"]["control_image"]["playing"]
        candidate = replay(region, 0, pcm, candidate=True)
        images = candidate["images"]
        assert images["fm_open"] == pages["0x0"]["control_image"]["idle"]
        assert images["exit_carrier"] == images["fm_open"]
        assert images["exit_quiet"] == images["fm_closed"]
        assert images["dmr_carrier"] == images["dmr_again"] == reference
        assert images["dmr_quiet"] == reference
        assert [(i, int(x,16) ^ int(y,16)) for i,(x,y) in enumerate(zip(images["fm_open"], reference)) if x != y] == [(1, 0x800)]
        pages["candidate"] = candidate
    report = dict(scope="Stock selected-file handler, buffered SD read completion, original playback and SSIF0 DMA. Actual native FM squelch calculations use a supplied noise metric. RSPI3 serializer tested with a modeled ready pin. Candidate monitor guard set at the component boundary; UI and field audio validated separately. No IF DSP or physical speaker simulated.", pcm_sha256=sha256(pcm).hexdigest(), regions=results)
    target = OUT / "factory-player-wire.json"
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(target.name, "carrier, quiet, return to FM and playback reference passed in both regions")

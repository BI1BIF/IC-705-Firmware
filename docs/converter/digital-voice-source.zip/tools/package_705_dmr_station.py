"""Assemble the tested firmware and card resource, verify every archived byte."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import wave
from zipfile import ZipFile, ZIP_DEFLATED, ZIP_STORED

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/".analysis/digital-rx12/final"
STUDY=ROOT/".analysis/dmr-if-study"
LIB=STUDY/"mbelib-neo"
DEST=OUT/"field-test"
LABEL="IC-705-Digital-RX12"

def source_bundle():
    dest=DEST/(LABEL+"-source.zip")
    archive=OUT/"mbelib-source.zip"
    rev="071f478d1736206d1c39b6edb5cfe0f0c7454233"
    subprocess.run(["git","-C",LIB,"archive","--format=zip","--prefix=mbelib-neo/",
                    "-o",archive,rev],check=True)
    pffft=next((STUDY/"arm-build/_deps").rglob("archive.tar"))
    assert sha256(pffft.read_bytes()).hexdigest()=="c35ca6cff0032fac89fbec1acced75868caac0a121d947f8931f325ceae17925"
    with ZipFile(dest,"w",ZIP_DEFLATED) as z:
        z.write(archive,"upstream/mbelib-neo-"+rev+".zip",ZIP_STORED)
        z.write(pffft,"upstream/pffft-b7ed3cdb8655426a77aa26f8c0f5154205427f45.tar.gz",ZIP_STORED)
        dsd=STUDY/"dsd-neo"
        for p in [dsd/"LICENSE",dsd/"COPYRIGHT",*dsd.joinpath("include").rglob("*.h"),
                  *[dsd/"src/fec"/(s+".c") for s in ("bptc","fec","rs-12-9")]]:
            z.write(p,"upstream/dsd-neo/"+p.relative_to(dsd).as_posix())
        for p in [*(ROOT/"samples").glob("dmr-*"),*(ROOT/"tools").glob("*dmr*.py")]:
            if p.is_file(): z.write(p,p.relative_to(ROOT).as_posix())
        z.write(ROOT/"tools/fixtures/dmr-mobile.c","tools/fixtures/dmr-mobile.c")
        z.writestr("BUILD.txt","""This snapshot accompanies IC-705 Digital RX12 private receive firmware.
Target compiler: Arm GNU Toolchain 14.2.Rel1, arm-none-eabi.
mbelib-neo 071f478d1736206d1c39b6edb5cfe0f0c7454233, dsd-neo 56cc1378a27d4f89f3bb309232b731e7d533ad4c.
In the project workspace extract upstreams under .analysis/dmr-if-study. The bundled PFFFT tarball is the pinned dependency expected under mbelib-neo/third_party.
For mbelib-neo configure CMake with Ninja, CMAKE_SYSTEM_NAME=Linux, CMAKE_SYSTEM_PROCESSOR=arm, CMAKE_C_COMPILER=arm-none-eabi-gcc, CMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY, CMAKE_BUILD_TYPE=MinSizeRel.
CMAKE_C_FLAGS=-mcpu=cortex-a9 -marm -mfpu=vfpv3-d16 -mfloat-abi=softfp -ffunction-sections -fdata-sections
Disable MBELIB_ENABLE_SIMD, MBELIB_ENABLE_NATIVE, MBELIB_ENABLE_LTO, MBELIB_ENABLE_FAST_MATH, MBELIB_BUILD_TESTS, MBELIB_BUILD_EXAMPLES, MBELIB_BUILD_TOOLS. Build the static libmbe-neo.a in arm-build. The station builder checks the upstream git revision.
Run py -3.14 tools/build_705_dmr_station.py from the IC-705 research workspace with the public v1.4.0 regional baselines. The SD image includes mbelib-neo speech routines, PFFFT and static Arm toolchain C/math runtime functions. Refer to the component notices included with their sources.
""")
    return dest

def package(region,src):
    folder=OUT/region
    name=f"705{region}140.dat"
    meta=json.loads((folder/"package.json").read_text())
    digest=meta["sha256"]
    if sha256((folder/name).read_bytes()).hexdigest() != digest:
        raise ValueError(f"{region}140: DAT hash does not match package metadata")
    for evidence in ("siblings","upgrade","upgrade-rx11","restore","ptt","station-air","station-air-hp200","station-air-hp300","station-air-field"):
        assert json.loads((folder/f"{evidence}.json").read_text())["dat_sha256"]==digest
    for evidence,runs in (("rx-led",2),("rx-led-retune",3)):
        led=json.loads((folder/f"{evidence}.json").read_text())
        assert led["dat_sha256"]==digest and len(led["lit_intervals_ms"])==runs
        assert led["preference_off_and_tx_red"] and led["stock_carrier_independent"]
    ui=json.loads((folder/"station-ui/results.json").read_text())
    assert ui["dat"]==digest and ui["rx_monitor_follows_dmr_with_carrier_and_without"]
    assert ui["mode_beep_after_selection"] and ui["first_dmr_beep_on_off_and_retry"]
    assert ui["exit_keeps_all_three_modes"] and set(ui["caller_row_bounds"])=={
        "caller-row","mini-scope","full-scope","expanded-scope","expanded-long"}
    assert ui["deferred_mode_then_tx_refusal"] and ui["aprs_wait_timeout_cancel_recovery"]
    assert set(ui["startup_failures_and_cleanup"])=={
        "radio_alloc","make_thread","factory_fm_available"}
    field=json.loads((folder/"station-air-field.json").read_text())
    assert field["panel_audio_samples"]==[83520,83520] and field["dmr_monitor_checked_under_open_squelch"]
    gain=field["playback_gain"]
    assert gain["compressed_samples"]==0 and 6.01<gain["rms_gain_db"]<6.03
    assert gain["after_peak"]==2*gain["before_peak"]
    for fixture,minimum in (("p25p1_c4fm_vc",14400),("ysf",45600)):
        dma=json.loads((folder/(fixture+"-dma.json")).read_text())
        assert dma["dat_sha256"]==digest and dma["samples"]>=minimum
        assert dma["native_dma_matches_card_gain"] and dma["worker_retired"]
        info=json.loads((OUT/(fixture+".json")).read_text())
        assert info["card_sha256"]==meta["card_sha256"] and info["rows"] and info["stack_bytes"]<=12288
    types=json.loads((OUT/"call-types.json").read_text())
    assert {"group","private","all","protected","vd1","vd2","vw"}<=types.keys()
    assert all(v["card_sha256"]==meta["card_sha256"] for v in types.values())
    assert types["protected"]["samples"]==0
    with wave.open(str(folder / "dmr-received-field.wav"), "rb") as wav:
        pcm = wav.readframes(wav.getnframes())
    first, second = field["playback_runs_at_8khz"]
    assert 0 < first[0] < first[1] < second[0] < second[1] < len(pcm) // 2
    for lo, hi in ((0, first[0]), (first[1], second[0]), (second[1], len(pcm)//2)):
        assert not any(pcm[lo*2:hi*2])
    assert ui["old_rx5_card_refused"] and ui["native_pool_refused_32k_started_16k"]
    assert (folder/"DMRRX.BIN").read_bytes()==(OUT/"J/DMRRX.BIN").read_bytes()
    assert (folder/"DMRRX.BIN").read_bytes()==(ROOT/".analysis/digital-rx11/final"/region/"DMRRX.BIN").read_bytes()
    for fixture in ("dmr","ysf","p25p1_c4fm_vc"):
        tuning=json.loads((folder/f"retune-{fixture}.json").read_text())
        assert tuning["dat_sha256"]==digest and tuning["card_sha256"]==meta["card_sha256"]
        assert tuning["single_worker"] and tuning["muted_off_channel"] and tuning["fine_tuning_samples"]>=2400
    late=json.loads((OUT/"dmr-late.json").read_text())
    assert set(late)=={"group","private","privacy","damaged"} and all(v["card_sha256"]==meta["card_sha256"] for v in late.values())
    assert not late["privacy"]["samples"] and not late["damaged"]["samples"]
    expected={"IC-705/"+name:digest,"IC-705/DMRRX.BIN":meta["card_sha256"]}
    title="日版 J140" if region=="J" else "欧／美版 E140"
    instructions=f"""IC-705 Digital RX12 数字接收私测包 · {title}
基于本地区公开整包 v1.4.0 和 Icom 1.40，含 CW、SSTV、FT8/FT4、APRS。

装卡
从 RX10 或 RX11 升级只需更新 {name}，保留卡上的 DMRRX.BIN。首次安装或从 RX9 及更早版本升级时，将本包 IC-705 目录中的 {name} 和 DMRRX.BIN 一起复制到卡上同名目录。按 SET → SD Card → Firmware Update 备份并选择 {name[:-4]} 更新。重启后保留卡上的 BIN。

本次优先复测
在 SET → Display 中打开 RX LED。用手台连续说几秒，观察 705 的 TX/RX 绿灯：收到有效 DMR 语音后应持续点亮，松开 PTT 或调离频道后应熄灭，回到仍在通话的频道可重新点亮。关闭原厂 RX LED 后，同一段语音应正常播放且绿灯熄灭。切回普通 FM 可检查载波指示。

测 P25 常规频道
先调到正在使用的 P25 Phase 1 常规明文语音频点。点左上角模式，点 DV。每切一次会回到接收画面。重新打开 MODE 并点同一 DV 键，依次经过 DMR、C4FM、P25，下一次回到原厂 DV。左上角显示 P25 后让对方从头发一次短呼。
来电时核对频率下方的呼叫类型、三位十六进制 NAC、来源 ID 和目标。组呼与全呼标 TG，个呼标 TO。听语音开头、结尾与空闲静噪。实体 EXIT 只处理原厂页面返回。要结束数字接收，请从 MODE 明确选 FM 或其他工作模式。
组呼一声、个呼两声、全呼三声，在首段语音上混音。C4FM 显示 DN／VW、DG-ID，收到有效源呼号时加 RX。协议未明确指示呼叫类型时省略类型和提示音。DMR 显示色码，直接模式能判定的时隙才显示。
本轮范围是单频明文接收。P25 Phase 1 常规 C4FM 调制，收到有效语音链路控制单元后才开声。C4FM 支持 V/D1、V/D2、全速率语音。响度沿用 RX7 增益曲线，实机清晰度、连续通话与面板响应待验。

Icom 1.40 原厂更新操作说明 https://www.icomjapan.com/support/firmware_driver/4422/

SHA-256
{expected['IC-705/'+name]}  {name}
{expected['IC-705/DMRRX.BIN']}  DMRRX.BIN
"""
    dest=DEST/f"{LABEL}-{region}140.zip"
    with ZipFile(dest,"w",ZIP_DEFLATED) as z:
        z.write(folder/name,"IC-705/"+name)
        z.write(folder/"DMRRX.BIN","IC-705/DMRRX.BIN")
        z.writestr("实机测试说明.txt",instructions.encode("utf-8-sig"))
        z.write(folder/"station-ui/mode.png","MODE入口.png")
        z.write(folder/"station-ui/p25-caller-row.png","P25来电显示.png")
        z.write(folder/"station-ui/expanded-scope.png","展开频谱来电显示.png")
        z.write(ROOT/"docs/converter/ftx-notices.txt","源码与许可/ftx-notices.txt")
        z.write(src,"源码与许可/"+src.name,ZIP_STORED)
    with ZipFile(dest) as z:
        assert z.testzip() is None and all(sha256(z.read(p)).hexdigest()==h for p,h in expected.items())
    return dict(file=dest.name,zip_sha256=sha256(dest.read_bytes()).hexdigest(),members=expected)

if __name__=="__main__":
    for region in "JE":
        folder = OUT / region
        stress = json.loads((folder / "freeze-stress.json").read_text())
        digest = sha256((folder / f"705{region}140.dat").read_bytes()).hexdigest()
        if (stress["dat_sha256"] != digest or not stress["stack_sentinel_and_lower_guard_intact"]
                or stress["stack_size"] != 16384 or stress["calls"] < 12
                or stress["stack_size"] - stress["observed_stack_writes_span"] < 4096):
            raise SystemExit(f"{region}: field recording stack regression has not passed for this firmware")
    DEST.mkdir(parents=True,exist_ok=True)
    src=source_bundle()
    manifests=[package(r,src) for r in "JE"]
    (DEST/"manifest.json").write_text(json.dumps(manifests,indent=2)+"\n",encoding="utf8")
    print(json.dumps(manifests,indent=2))

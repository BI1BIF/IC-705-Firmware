from pathlib import Path
from struct import iter_unpack
import sys,json
lab=Path(__file__).resolve().parent
root=lab.parents[1]
stage=root/'.analysis/release-v1.5.0-rc/staging'
sys.path[:0]=[str(stage),str(root/'.analysis/ic705-emulator/deps'),str(root/'.analysis/ftx-tools')]
from tools import build_705_dmr_station as station
assert station.ROOT==stage
r=sys.argv[1]
from tools import build_705_dmr_ui as ui
ui.ROOT=root/'.analysis/release-v1.5.2/staging'
old=len(sys.argv)>2
station.OUT=root/'.analysis/release-v1.5.2/verified' if old else lab/'final'
station.FT_OUT=root/'.analysis/j140-ftx-tx2j'
c=station.OUT/'core'
p=json.loads((c/'payload.json').read_text())
p.update(image=(c/'payload.bin').read_bytes(),relocs=[i for i, in iter_unpack('<H',(c/'reloc.u16').read_bytes())])
station.build(r,p,output=lab/('previous' if old else 'base'),aprs_base=root/'.analysis/aprs-popup-history/direction-final'/r,ft_timezone=True)




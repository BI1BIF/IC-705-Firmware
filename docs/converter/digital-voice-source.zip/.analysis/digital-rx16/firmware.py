from hashlib import sha256,md5
import json,subprocess,sys
from pathlib import Path
from shutil import copyfile
from struct import pack_into,unpack_from
lab=Path(__file__).resolve().parent
root=lab.parents[1]
sys.path.insert(0,str(root))
from tools.build_705_dmr_station import ELFFile,FIRST_OFFSET,BASE,BOOT_SIZE,load_a,with_pc_main,checked_group_a,symbols
TARGETS={'J':'ae9e6e9f5e2eefaf43cdf327a65c4569b3dbc98c8295e3ff6f7c20d19c601670','E':'9d4454d328213c7b4cb5636f7696c6a50f6746150094559701b089e7cd6ad894'}
def section(path):
    with path.open('rb') as src:
        text=ELFFile(src).get_section_by_name('.code')
        return text['sh_addr'],text.data()
def build(region):
    release=root/'.analysis/release-v1.5.0-rc'
    original=lab/'previous'/region
    source=root/'.analysis/release-v1.5.3/verified'/region
    out=lab/'final'/region
    updated=lab/'base'/region
    copyfile(updated/'station.elf',out/'station.elf')
    name=f'705{region}140.dat'
    dat=bytearray((source/name).read_bytes())
    meta=json.loads((source/'package.json').read_bytes())
    assert sha256(dat).hexdigest()==meta['sha256']==TARGETS[region]
    main,flash=load_a(bytes(dat),meta['main_sha256'])
    def read_base(folder):
        m=json.loads((folder/'package.json').read_bytes())
        return load_a((folder/name).read_bytes(),m['main_sha256'])[0]
    old,new=read_base(original),read_base(updated)
    assert len(old)==len(new)<=len(main)
    main=bytearray(main)
    assert section(original/'station.elf')==section(source/'station.elf')
    differences=[i for i,(a,b) in enumerate(zip(old,new)) if a!=b]
    assert differences and all(main[i]==old[i] for i in differences)
    for i in differences: main[i]=new[i]
    main=bytes(main)
    meta['guard']=json.loads((updated/'package.json').read_bytes())['guard']
    meta['resident_bytes']=len(section(out/'station.elf')[1])
    print('Changed main bytes:',len(differences),flush=True)
    env=bytearray(flash)
    pack_into('<I',env,BOOT_SIZE,FIRST_OFFSET-BOOT_SIZE-8)
    changed=with_pc_main(env,main,match_depth=32,lazy=True)
    end=BOOT_SIZE+8+unpack_from('<I',changed,BOOT_SIZE)[0]
    assert end<=FIRST_OFFSET and changed[end:]==flash[end:]
    _,g=checked_group_a(bytes(dat))
    start,stop=g['offset'],g['end_exclusive']
    for i in range(BOOT_SIZE,end+1): dat[start+i]=changed[i]^((changed[i-1]+start+i-0x19)&255)
    dat[stop:stop+16]=md5(dat[start:stop],usedforsecurity=False).digest()
    digest=sha256(main).hexdigest()
    assert load_a(bytes(dat),digest)==(main,changed)
    (out/name).write_bytes(dat)
    (out/'package.json').write_text(json.dumps(meta|dict(baseline='v1.5.3',speech_gain_halves=[3,8,4],baseline_sha256=TARGETS[region],sha256=sha256(dat).hexdigest(),main_sha256=digest,flash_end=end,card_sha256=sha256((out/'DMRRX.BIN').read_bytes()).hexdigest()),indent=2))
    for f in ('manager.elf','aprs-task.elf'):copyfile(source/f,out/f)
build(sys.argv[1])






"""Relink the RX14 badge and install its resident section in the verified field DAT."""
from hashlib import md5, sha256
from pathlib import Path
from shutil import copyfile
from struct import pack_into, unpack_from
import sys, json, subprocess

lab = Path(__file__).resolve().parent
root = lab.parents[1]
sys.path[:0] = [str(root), str(root/'.analysis/ic705-emulator/deps'), str(root/'.analysis/ftx-tools')]
from tools.build_705_dmr_station import (BASE, BOOT_SIZE, FIRST_OFFSET, ELFFile, checked_group_a,
    load_a, symbols, with_pc_main)
from tools.build_705_dmr_ui import compile_ui

def section(elf):
    with elf.open('rb') as f:
        s = ELFFile(f).get_section_by_name('.code')
        return s['sh_addr'] - BASE, s.data()

r = sys.argv[1]
ref = lab.parent/'digital-rx14'
base = ref/'final'/r
objects = ref/'base'/r
out = lab/r
obj = compile_ui(out)
elf = out/'station.elf'
subprocess.run(['arm-none-eabi-ld', '-T', objects/'station.ld', obj,
    *[objects/n for n in ('dmr-station.c.o','dmr-resource.c.o','dmr-station.S.o')], '-o', elf], check=True)
at, old = section(base/'station.elf')
offset, new = section(elf)
assert at == offset and len(old) == len(new) and b'YSF\0' in new and b'C4FM\0' not in new
for key, address in symbols(base/'station.elf').items():
    if key in ('__work_start','__work_end','dmr_mode_text','dmr_rx_set_enabled'):
        assert symbols(elf)[key] == address
name = f'705{r}140.dat'
meta = json.loads((base/'package.json').read_bytes())
dat = bytearray((base/name).read_bytes())
assert sha256(dat).hexdigest() == meta['sha256']
prior, flash = load_a(bytes(dat), meta['main_sha256'])
assert prior[at:at+len(old)] == old
main = prior[:at] + new + prior[at+len(old):]
env = bytearray(flash)
pack_into('<I', env, BOOT_SIZE, FIRST_OFFSET-BOOT_SIZE-8)
changed = with_pc_main(env, main, match_depth=32, lazy=True)
end = BOOT_SIZE+8+unpack_from('<I',changed,BOOT_SIZE)[0]
assert end <= FIRST_OFFSET and changed[end:] == flash[end:]
_, group = checked_group_a(bytes(dat))
start, stop = group['offset'], group['end_exclusive']
for i in range(BOOT_SIZE,end+1):
    dat[start+i] = changed[i]^((changed[i-1]+start+i-0x19)&255)
dat[stop:stop+16] = md5(dat[start:stop],usedforsecurity=False).digest()
digest = sha256(main).hexdigest()
assert load_a(bytes(dat), digest) == (main, changed)
(out/name).write_bytes(dat)
for n in ('DMRRX.BIN', 'manager.elf', 'aprs-task.elf', 'dmr-layout.h'):
    copyfile(base/n,out/n)
(out/'package.json').write_text(json.dumps(meta | dict(sha256=sha256(dat).hexdigest(),
    main_sha256=digest, flash_end=end, parent_rx14_sha256=meta['sha256']), indent=2))

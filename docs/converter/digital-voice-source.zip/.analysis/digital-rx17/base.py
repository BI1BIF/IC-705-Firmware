from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
from shutil import copyfile
from struct import iter_unpack
import json,sys

lab=Path(__file__).resolve().parent
root=lab.parents[1]
stage=root/'.analysis/release-v1.5.0-rc/staging'
rx16=lab.parent/'digital-rx16'
sys.path[:0]=[str(stage),str(root/'.analysis/ic705-emulator/deps'),str(root/'.analysis/ftx-tools')]
from tools import build_705_dmr_station as station
assert station.ROOT==stage
spec=spec_from_file_location('working_dmr_ui',root/'tools/build_705_dmr_ui.py')
ui=module_from_spec(spec)
spec.loader.exec_module(ui)
station.compile_ui=ui.compile_ui
station.ui_imports=ui.ui_imports
station.OUT=rx16/'final'
station.FT_OUT=root/'.analysis/j140-ftx-tx2j'
core=station.OUT/'core'
payload=json.loads((core/'payload.json').read_text())
payload.update(image=(core/'payload.bin').read_bytes(),
               relocs=[i for i, in iter_unpack('<H',(core/'reloc.u16').read_bytes())])
for r in sys.argv[1:]:
    updated=lab/'base'
    station.build(r,payload,output=updated,aprs_base=root/'.analysis/aprs-popup-history/direction-final'/r,ft_timezone=True)
    out=lab/'final'/r
    out.mkdir(parents=True,exist_ok=True)
    assert (updated/r/'DMRRX.BIN').read_bytes()==(station.OUT/r/'DMRRX.BIN').read_bytes()
    for name in ('DMRRX.BIN','dmr-layout.h'):
        copyfile(updated/r/name,out/name)

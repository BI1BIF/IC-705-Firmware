from pathlib import Path
import sys
lab=Path(__file__).resolve().parent
sys.path.insert(0,str(lab.parents[1]))
from tools.build_705_dmr_station import build_payload,resource
dst=lab/'candidate'
p=build_payload(dst/'core')
for region in 'JE':
    (dst/region).mkdir(exist_ok=True)
    resource(p,dst/region,dst/'core')


将 IC-705/DMRRX.BIN 复制到 SD 卡同名路径，日版和欧／美版通用。
Copy IC-705/DMRRX.BIN to the same path on the SD card for either region.
如有同名旧文件，请用这一版覆盖。使用数字接收时请留卡。
Replace any older file of the same name. Keep the card inserted during digital reception.
SHA-256 009e238346ac65445c9ea0136642d14f3f60d0101bca3e268667459ce81060df

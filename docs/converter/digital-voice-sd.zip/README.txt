IC-705 v1.5.1 · J140 / E140
把 IC-705/DMRRX.BIN 复制到 SD 卡的同名路径，覆盖旧文件。使用数字接收时请留卡。
Copy IC-705/DMRRX.BIN to the same path on the SD card. Replace the older file and leave the card inserted for digital reception.
SHA-256 54d735c73d0ed842159bc27b807d5f0e6e3f525c4d8fc5694f1ef6b47980a57e

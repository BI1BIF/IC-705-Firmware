IC-705 v1.5.2 · J140 / E140
把 IC-705/DMRRX.BIN 复制到 SD 卡的同名路径，覆盖旧文件。使用数字接收时请留卡。
Copy IC-705/DMRRX.BIN to the same path on the SD card. Replace the older file and leave the card inserted for digital reception.
SHA-256 2fa0b83cf38f76d170487dc9d162de4fa082492240e6f7d1469fd298c1088b0a

IC-705 v1.5.3 · J140 / E140
把 IC-705/DMRRX.BIN 复制到 SD 卡的同名路径，覆盖旧文件。使用数字接收时请留卡。
Copy IC-705/DMRRX.BIN to the same path on the SD card. Replace the older file and leave the card inserted for digital reception.
SHA-256 2f92a424fd26d07b7e9299e42f2b2a8de315eec7c2974554b9ba77e85fa0b359

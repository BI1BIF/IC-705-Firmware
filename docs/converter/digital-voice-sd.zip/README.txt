IC-705 v1.6.0 · J140 / E140
请将 IC-705/DMRRX.BIN 复制到 SD 卡同一路径，覆盖旧文件。使用数字语音接收时请留卡。
Copy IC-705/DMRRX.BIN to the same path on the SD card and replace the old file. Leave the card inserted for digital reception.
SHA-256 48bef243d0ba678a4626fb66b4508148749474a23fa65b14bfe81dbf9675bbd0
